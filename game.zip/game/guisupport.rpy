## gui.scale is used by screens.rpy. (The SDK template version of this file also
## regenerated every GUI image on launch, overwriting tools/make_gui.py output.)
init -100 python in gui:

    def scale(n):
        return int(n)
