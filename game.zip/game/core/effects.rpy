## Effects: transitions, weather, overlays, colour grades, positions ##########

# Transitions -----------------------------------------------------------------
define dissolve_slow = Dissolve(1.2)
define dissolve_fast = Dissolve(0.25)
define fade_slow = Fade(1.0, 0.6, 1.2)
define fade_long = Fade(1.6, 1.2, 1.6)
define flash = Fade(0.06, 0.0, 0.6, color="#ffffff")
define flash_red = Fade(0.06, 0.0, 0.9, color="#4a0a0d")
define flash_ice = Fade(0.08, 0.0, 0.7, color="#c9d9ea")
define wipe_down = CropMove(0.8, "wipedown")
define iris_in = CropMove(1.0, "irisin")

# Sprite positions (sprites are bottom-anchored) ------------------------------
transform far_left:
    xalign 0.08 yalign 1.0
transform left:
    xalign 0.22 yalign 1.0
transform midleft:
    xalign 0.36 yalign 1.0
transform center:
    xalign 0.5 yalign 1.0
transform midright:
    xalign 0.64 yalign 1.0
transform right:
    xalign 0.78 yalign 1.0
transform far_right:
    xalign 0.92 yalign 1.0

# Sprite modifiers ------------------------------------------------------------
transform dimmed:
    matrixcolor BrightnessMatrix(-0.25) * SaturationMatrix(0.7)
transform silhouette:
    matrixcolor TintMatrix("#0a0f18") * BrightnessMatrix(-0.6)
transform breathe:
    ease 2.4 yoffset 4
    ease 2.4 yoffset 0
    repeat
transform shake:
    linear 0.05 xoffset -14
    linear 0.05 xoffset 12
    linear 0.05 xoffset -8
    linear 0.05 xoffset 5
    linear 0.05 xoffset 0
transform tremble:
    linear 0.04 xoffset -2
    linear 0.04 xoffset 2
    repeat
transform slow_zoom:
    subpixel True
    zoom 1.0
    linear 30.0 zoom 1.08
transform slow_pan_right:
    subpixel True
    xalign 0.0 zoom 1.1
    linear 25.0 xalign 1.0

# Colour grades for backgrounds and CGs ---------------------------------------
# Flashbacks / memory: drained, cold, faintly overexposed.
transform memory:
    matrixcolor SaturationMatrix(0.15) * TintMatrix("#b9c8da") * BrightnessMatrix(0.04)
# Night chill: deepen blues further.
transform night:
    matrixcolor TintMatrix("#8ea6c8") * BrightnessMatrix(-0.12)
# Red danger tint for violence beats.
transform bloodtint:
    matrixcolor TintMatrix("#d08080") * SaturationMatrix(0.6)

# Weather ---------------------------------------------------------------------
image snow light = Fixed(
    SnowBlossom("fx/flake_s.png", count=70, border=50, xspeed=(-15, 20), yspeed=(40, 90), start=0, fast=True),
    SnowBlossom("fx/flake_m.png", count=20, border=50, xspeed=(-20, 25), yspeed=(70, 130), start=0, fast=True),
)
image snow heavy = Fixed(
    SnowBlossom("fx/flake_s.png", count=160, border=50, xspeed=(-40, 40), yspeed=(80, 160), start=0, fast=True),
    SnowBlossom("fx/flake_m.png", count=60, border=50, xspeed=(-50, 50), yspeed=(120, 220), start=0, fast=True),
    SnowBlossom("fx/flake_b.png", count=10, border=80, xspeed=(-60, 60), yspeed=(200, 320), start=0, fast=True),
)
image snow storm = Fixed(
    SnowBlossom("fx/flake_s.png", count=260, border=80, xspeed=(160, 420), yspeed=(140, 260), start=0, fast=True),
    SnowBlossom("fx/flake_m.png", count=90, border=80, xspeed=(220, 520), yspeed=(180, 320), start=0, fast=True),
    SnowBlossom("fx/flake_b.png", count=18, border=120, xspeed=(300, 600), yspeed=(260, 420), start=0, fast=True),
)
image rain = Transform(Movie(play="movies/rain.webm", size=(1920, 1080)), blend="add", alpha=0.55)
image fog = Transform(Movie(play="movies/fog.webm", size=(1920, 1080)), blend="add", alpha=0.32)
image vignette = "fx/vignette.png"
image vignette red = "fx/vignette_red.png"

# Solid cards -----------------------------------------------------------------
image black = Solid("#000000")
image white = Solid("#ffffff")
image ink = Solid("#05080e")
