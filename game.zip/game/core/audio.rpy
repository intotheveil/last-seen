## Audio ######################################################################
##
## Channels: music (built-in), sound (built-in, one-shots),
## ambient (looping bed, e.g. wind), ambient2 (second looping bed).

init python:
    renpy.music.register_channel("ambient", "sfx", loop=True)
    renpy.music.register_channel("ambient2", "sfx", loop=True)

# Music: the Last Seen score (18 cues, docs/soundtrack_list.md), delivered 2026-10-11 ----------------
define audio.m_theme = "audio/music/theme.ogg"             # 1  main theme: title, credits
define audio.m_flame = "audio/music/flame.ogg"             # 2  the 2003 prologue, the undercroft, the burial
define audio.m_city = "audio/music/city.ogg"               # 3  Amanda in the city, the park, the office
define audio.m_janet = "audio/music/janet.ogg"             # 4  Janet, the sisters, memories of each other
define audio.m_village = "audio/music/village.ogg"         # 5  Driftwood Bay by day and dusk
define audio.m_council = "audio/music/council.ogg"         # 6  the council, Markus's cold ostinato, the storm nights
define audio.m_road = "audio/music/road.ogg"               # 7  the coast road, every drive
define audio.m_welcome = "audio/music/welcome.ogg"         # 8  the parents' hearth
define audio.m_dogs = "audio/music/dogs.ogg"               # 9  the dogs, the beach, every chase
define audio.m_psalm = "audio/music/psalm.ogg"             # 10 the tavern, the butcher
define audio.m_mist = "audio/music/mist.ogg"               # 11 the fog, the mimic, dread in the open
define audio.m_cell = "audio/music/cell.ogg"               # 12 the undercroft cells
define audio.m_book = "audio/music/book.ogg"               # 13 the Book of Custodes Lucis
define audio.m_medication = "audio/music/medication.ogg"   # 14 Markus and the syringe
define audio.m_pact = "audio/music/pact.ogg"               # 15 the abomination, the pact, the possession
define audio.m_tree = "audio/music/tree.ogg"               # 16 the Tree, the sermon, the fight
define audio.m_apotheosis = "audio/music/apotheosis.ogg"   # 17 Markus eats the Fruit
define audio.m_circle = "audio/music/circle.ogg"           # 18 the circle holds, loss, the epilogue

# Stingers (short, one-shot) --------------------------------------------------
define audio.sting_chapter = "audio/sfx/sting_chapter.ogg"   # every chapter card (5 s)
define audio.sting_word = "audio/sfx/sting_word.ogg"         # the seal's knock: the Key of Hecate, the Book (3 s)
define audio.sting_note = "audio/sfx/sting_note.ogg"         # "Notebook updated" (1.5 s)
define audio.sting_reveal = "audio/sfx/sting_reveal.ogg"     # the mimic's face, "Sisterly blood" (6 s)

define audio.sfx_wind = "audio/sfx/wind.ogg"            # loop on ambient
define audio.sfx_storm = "audio/sfx/storm.ogg"          # loop on ambient
define audio.sfx_rain = "audio/sfx/rain.ogg"            # loop on ambient
define audio.sfx_engine = "audio/sfx/engine.ogg"        # loop on ambient2 (car interior)
define audio.sfx_crowd = "audio/sfx/crowd.ogg"          # loop on ambient2 (mob, square)
define audio.sfx_static = "audio/sfx/static.ogg"        # one-shot: radio crackle
define audio.sfx_phone = "audio/sfx/phone_ring.ogg"     # one-shot: phone ring
define audio.sfx_heartbeat = "audio/sfx/heartbeat_one.ogg"  # one-shot (loop it on ambient2 for tension)
define audio.sfx_thud = "audio/sfx/thud.ogg"            # one-shot: impact, door, fall
define audio.sfx_tinnitus = "audio/sfx/tinnitus.ogg"    # one-shot: shock
define audio.sfx_beep = "audio/sfx/beep.ogg"            # one-shot: monitor, phone beep
