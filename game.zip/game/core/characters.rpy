## Last Seen — characters. Variables per docs/cast.md (writers use these names only).
## A Character with image="tag" gets an automatic side portrait (game/images/side/side <tag> <expr>.webp)
## when its sprite isn't on screen (config.side_image_only_not_showing).

define narrator = Character(None, what_color="#d3dce7")
define ath = Character(None, what_italic=True, what_color="#a9bbd0")          # Amanda's thoughts
define jth = Character(None, what_italic=True, what_color="#c9b0c4")          # Janet's thoughts
define mth = Character(None, what_italic=True, what_color="#b0a9a0")          # Markus's thoughts
define th = ath                                                                # alias: the POV character's thought
define note_voice = Character(None, what_font="fonts/CormorantGaramond-Italic.ttf",
                              what_color="#c9d6e6", what_size=36)              # written words: texts, the Book, the stamp
define mn = Character(None, what_font="fonts/CormorantGaramond-Italic.ttf", what_color="#c9a46a",
                      what_size=30, what_xpos=120)                             # margin voice (unused until mechanics)

# Main cast -------------------------------------------------------------------
define am  = Character("Amanda",  image="amanda", who_color="#9fb8d4")
define jn  = Character("Janet",   image="janet",  who_color="#d4a9c4")
define mk  = Character("Markus",  image="markus", who_color="#b8a08a")
define mky = Character("Markus",  image="markusy", who_color="#b8a08a")   # the boy, 2003 (ch01 only)
define kal = Character("Kalinos", image="kalinos", who_color="#a89a7a")
define mi  = Character("Michael", image="michael", who_color="#8f9aa6")
define ab  = Character("The abomination", image="abomination", who_color="#7fa89a",
                       what_font="fonts/CormorantGaramond-Italic.ttf", what_size=38)
define mim = Character("The thing in the mist", image="mimic", who_color="#7fa89a",
                       what_font="fonts/CormorantGaramond-Italic.ttf", what_size=38)

# Driftwood Bay ----------------------------------------------------------------
define sf  = Character("Sofia", who_color="#d8c9b0")                            # CHILD: voice only, never drawn
define mfa = Character("Markus's father", image="father", who_color="#a0998a")
define mmo = Character("Markus's mother", image="mother", who_color="#a8a09a")
define jon = Character("Jonathan Morales", image="jonathan", who_color="#9a9a8a")
define jac = Character("Jacob", who_color="#9a9a8a")
define eld = Character("Elder", who_color="#8a8a80")
define cu  = Character("Cultist", who_color="#8a8a80")
define cw  = Character("Cultist", who_color="#8a8a80")
define ac  = Character("Acolyte", who_color="#8a8a80")
define ow  = Character("Old woman", who_color="#9a9a8a")
define bu  = Character("The butcher", image="butcher", who_color="#a08a7a")     # no words; mumbling only
define bv  = Character("A voice", who_color="#8a8a80")                          # the beach, unseen
define om  = Character("Old man", image="oldman", who_color="#9a9a8a")
define gl  = Character("The girl", image="girl", who_color="#c9c0b0")           # CHILD, silent, benign only

# City ---------------------------------------------------------------------------
define my  = Character("Myriam",  image="myriam", who_color="#d4c0a9")
define fr  = Character("Friend", who_color="#b0b0a0")
define je  = Character("Jenny",   image="jenny",  who_color="#d4c9a9")
define la  = Character("Lara",    image="lara",   who_color="#b0c4d4")
define he  = Character("Helen",   image="helen",  who_color="#c4b0b0")
define ceo = Character("The CEO", who_color="#a0a0a0")
define sup = Character("Supervisor", who_color="#a0a0a0")
define dr  = Character("The drunk", image="drunk", who_color="#a89a8a")
define yw  = Character("Young woman", who_color="#b0b0b0")
define mo  = Character("Mother", who_color="#b0b0b0")
define kd  = Character("Child", who_color="#b0b0b0")
define gd  = Character("Metro staff", who_color="#a0a0a0")
define cab = Character("Driver", who_color="#a0a0a0")
define det = Character("Detective", who_color="#a0a0a0")
define phone = Character("On the phone", who_color="#7fa0a8", what_font="fonts/CormorantGaramond.ttf")   # a voice on the line
