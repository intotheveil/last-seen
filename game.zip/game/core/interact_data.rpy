## Interactivity data (tables only). Empty for now: Last Seen is story first; the mechanics
## (tells, reads, the board) are designed after the adaptation exists. The engine code in
## systems.rpy tolerates empty tables.
define TELLS = {}
define TIER_LOW = 0.30
define TIER_TOP = 0.75
define SECOND_READ_EPIGRAPH = {1: "Read it again.", 2: "Read it again.", 3: "Read it again.", "all": "Read it again."}
define READS = {}
define SUSPECTS = []
define CLUES = {}
define TELL_CARD = {}
define STRIKE_AT_RECEIPT = []
define REINK_TO_ALICE = []
define PIN_PROMPTS = {}
define BOARD_REVEAL_SOME = ""
define BOARD_REVEAL_NONE = ""
