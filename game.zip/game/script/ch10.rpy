## Chapter 10 — "A Cradle, Not a Prison"
## Source: docs/manuscript/ch06.txt l.3–166. Janet POV. Beats 29–32 (docs/horror_beats.md).
## Rulings #8 (Janet in undergarments after the stripping, never "naked") and #12 (the fourth man is Jonathan).

label ch10:
    call chapter_card(10, "Beneath the church")

    scene black with fade_slow
    "Janet opened her eyes slowly, lids heavy, vision blurred and tinged with red. For a moment she thought she was still dreaming, still trapped in the fragments of nightmare. But the cold against her skin told her otherwise."

    scene bg cell_janet with dissolve_slow
    show vignette
    play music m_driftwood fadein 3.0
    call place("Beneath the church — the same night")
    "Her head throbbed with a dull, pulsing ache. When she tried to move, she realized her hands were numb, wrists bound by iron cuffs. She tugged weakly. Chains rattled, a hollow metallic echo spreading into the silence."
    "The place was dark, but not completely. Thin shafts of light bled from somewhere above, faint streaks on stone walls slick with moisture. Water dripped in slow intervals. The air was damp, heavy, with a faint smell of rot and rust."
    jth "It feels like a dungeon."
    "Her back pressed against cold stone, the chill sinking into her bones. Her clothes were damp, clinging to her skin, and when she shifted, pain flared at her side. She didn't need to look to know she was still bleeding."
    "She swallowed hard, her throat dry, her lips cracked. Panic threatened to tighten her chest until she suffocated. She tried to still herself. To listen. Nothing. No voices. No footsteps. Only the dripping water and the faint whisper of chains when she moved."
    jn "Amanda…"
    "The sound was so small it was almost lost in the damp air. She pulled harder at the chains, desperation bubbling up, but the cuffs didn't budge. All it earned her was the echo of her own struggle, bouncing off the stone walls like mockery."
    "She pressed her forehead against the damp stone behind her and shut her eyes, tears pricking. She wanted to scream, to demand someone answer. Fear held her back."

    "Time stretched, measured only by the steady drip of water. Her head slumped against the wall, her wrists burning where the iron bit into them. Then she heard it."
    "Footsteps. Slow, deliberate, echoing across stone. More than one pair. One shuffled, one pressed heavy into the floor, another lighter but steady. Men's voices murmured, low and indistinct — decisions being made before she was even in earshot."
    jth "If they think I'm unconscious, maybe they'll…"
    "She lowered her eyes, breathing through her nose, forcing herself to be still. The shadows lengthened. Four men stepped into the thin shafts of light."
    show markus cold at midleft with dissolve
    show kalinos smirk at center with dissolve
    show jonathan neutral at midright with dissolve
    "Her heart lurched. Markus was among them. His face was grim, his jaw set, his eyes fixed on her with an expression she didn't recognize. Not the warmth she'd come to trust. He looked at her the way one might look at an artifact — valuable, yes, but separate. Other."
    "Beside him the priest moved with a heavy, deliberate pace. His frame was stooped with age, but there was nothing weak about the way he carried himself. His eyes were pale and clouded, yet sharp, assessing her as if measuring a vessel."
    "Another man — older, perhaps in his seventies, his back ramrod straight, shoulders squared, lips pressed into a line. Even in the dim light his bearing spoke of discipline, of command."
    jth "Military. Though I don't know why I think so."
    "The fourth was younger, closer to Markus's age. Tall, broad, intimidating in his silence. He leaned against the wall by the door, but his posture was deceptive: his body was taut, coiled, watching her with eyes that didn't blink often."
    "The four of them regarded her without speaking. Their silence was worse than threats. They didn't see her as a woman chained before them. They saw her as something else."
    "At last Markus turned. He exchanged a glance with the older man — a nod, slight but decisive. Without a word, both left the chamber, their footsteps retreating up the stone corridor. The dungeon seemed colder once they were gone."
    hide markus with dissolve
    hide jonathan with dissolve
    show michael neutral at right with dissolve
    "The priest lingered, his shadow stretching toward her. His hand, thin and mottled with age, hovered near her face as if he wanted to touch her but held back. His lips moved, whispering something under his breath — a prayer, a chant, too faint to grasp."
    "The tall man leaned against the wall, arms crossed, watching. His silence was deliberate. Predatory. Her wrists strained unconsciously against the chains. The clink of iron betrayed her, sharp in the silence."
    kal "Child. Do you know where you are?"

    menu:
        "Answer him.":
            "Her lips parted. No sound came. Her throat was raw, fear tightening every word before it could form."
        "Say nothing.":
            "She kept her lips pressed shut. It cost her nothing; her throat was too raw to have given him anything anyway."

    "The tall man smirked faintly, his eyes gleaming as though her silence amused him. The priest leaned closer, his breath damp with age, his pale gaze sweeping down to the blood still matted at her temple."
    kal "This place… it is not a prison. It is a cradle."
    play sound sting_word
    kal "And you are not a prisoner. You are… chosen."
    "Her stomach turned. She pulled at the chains again, a tremor running through her limbs. The tall man's smirk widened into something colder, and he pushed off the wall, boots striking sharp against the stone as he stepped forward to loom beside the priest."
    "Two sets of eyes bore into her — one pale and reverent, one sharp and hungry. She clenched her teeth and held their gaze even as fear quaked in her chest."
    jth "I won't speak. I won't give them that."
    "The priest loomed close, his stoop somehow making him appear taller. She forced herself to meet his gaze, and saw him clearly. Skin stretched taut over bone, hollow eyes sunk in shadow. Lips thin, stretched too wide, the smirk fixed there as if carved into his skull."
    "The longer she stared, the more unnatural it became. Her silence seemed to needle him. The smirk didn't fade, but the pale eyes narrowed, hardening."
    stop music fadeout 2.0
    kal "Michael. Strip her."
    "He stepped back, hands clasped behind his spine, leaving the words to hang. Michael moved at once. His expression didn't change. No malice. No hesitation. His face was a mask, drained of anything human. He stepped toward her with calm, deliberate strides."
    jn "No!"
    "She jerked back, chains rattling as she pressed against the cold stone wall. Her wrists screamed as she strained against the cuffs, but the iron didn't budge."
    jn "Stay away from me! Don't touch me!"
    "Michael didn't stop."
    jn "Please! Don't — don't you dare!"

    scene black with fade
    "He reached her, his shadow falling over hers. His hands moved with quiet precision. He took her coat first, slipping the collar down from her shoulders as though she were nothing more than a mannequin. She twisted and fought, but his grip was iron, steady, unshakable."
    jn "Stop! You can't — let me go!"
    "He didn't answer. He didn't even blink. His hands moved to the next layer, the sweater, then the rest, working around her resistance with detached efficiency. The chains rattled louder, each movement echoing through the chamber as if her desperation were broadcast back to her."
    "The cold air sank against her skin, sharp, humiliating. She turned her head away, sobs tearing free. Then he stepped back with the same quiet precision. His face hadn't shifted, not once. As if he had been tasked with dusting shelves, not dismantling a human being."
    "The priest stepped close. His thin hand rose, trembling faintly with age, and hovered near her cheek. He didn't touch her. It was enough to make her flinch violently."
    kal "Yes. The vessel must be humbled. And the flesh… revealed."

    scene bg cell_janet with fade
    show vignette
    show kalinos smirk at center with dissolve
    show michael neutral at right with dissolve
    "She collapsed against the wall, her chest heaving, her body shaking with cold and fury. Left in her undergarments, she pulled her knees in as close as the chains allowed, trying to fold herself, to keep any shred of dignity she could."
    "The priest had watched it all. That smirk never faltered. He tilted his head slightly, pale eyes gleaming with satisfaction, as though her protests were the very music he had been waiting to hear. He turned away at last, clasping his hands once more."
    "The chains rattled faintly as she tried to shrink further into herself, her shoulders trembling, the cold biting across her bare arms. She felt hollow. Emptied."
    "Then footsteps echoed again down the stone corridor. Heavy. Certain. Markus."
    show markus cold at left with dissolve
    "He stepped in with the same quiet authority as before. But it wasn't him — not the man who had laughed with her in bars, who had called her late at night with soft words and promises of tomorrow. His face was harder now, sculpted into something severe, his eyes dark and cold."
    "He didn't look at her with recognition. He looked at her the way the priest did, the way Michael did — as though she were something set on display. An object to be judged, measured, used."
    "Hatred burned through her, sharp and blinding. She wanted to scream, to curse him, to claw at his eyes, to make him feel even a fraction of her terror. And beneath that fury, confusion tangled like a knot."
    jth "How can this be him? The man I trusted, the man I let into my life. The man who asked me to come see where he grew up, who spoke of futures as if they were real."
    jth "I want explanations. I want blood. I want him to be Markus again."
    "Her throat closed. The weight of it all pressed her down, heavier than the chains. She clenched her jaw until it hurt. She wouldn't give him that satisfaction. She wouldn't collapse before them. But the loneliness hit her harder than anything else."
    "It felt the same as when her parents had died — that first night in a stranger's house, fostered into a family that wasn't hers, lying awake with the ceiling pressing down and the silence screaming around her. That same hollow, aching emptiness opened inside her chest now."
    play music m_emily_reprise fadein 3.0
    "And with it came the memory of Amanda. Amanda, who had stepped into the role of everything Janet had lost — mother, father, sister, protector, anchor. Amanda, who had always been there, fierce and unyielding, shielding her from the world when Janet couldn't stand on her own."
    "Tears finally broke free, slipping hot down her cheeks. Because Amanda wasn't here now. Amanda couldn't break through these walls, couldn't tear away the chains, couldn't pull her out of this nightmare. She was alone. Utterly helpless. Utterly humiliated."
    "Markus remained silent, his presence heavier than words. The priest lingered at his side, smirk unchanged, and Michael stood in the shadows, still as stone. Together they filled the room, but Janet had never felt more abandoned. More small."
    "She lifted her head finally, eyes red, and stared at Markus. If there was a plea in her gaze, she couldn't stop it. If there was hatred, it was carved deep. All he gave back was that same unfamiliar face. Distant. Cold."
    "She closed her eyes. A sob slipped free, sharp and broken, echoing against the wet stone. She had never been so alone."

    stop music fadeout 2.0
    "The priest turned toward Markus with that same uncanny smirk. They exchanged a few quick, hushed words. She couldn't make them out, but she caught the faint rise of Markus's grin. A small, deliberate smile, sharp and knowing."
    "The priest's pale eyes glinted, his bony hand clutching at his robe as if containing some private triumph. Then he threw his head back and laughed. The sound was spasmodic, uneven — like a cough fighting to be joy. It scraped against the stone walls and crawled under her skin."
    hide kalinos with dissolve
    "When the echoes faded the priest shuffled away, his laughter lingering long after his steps dissolved into silence. Markus hadn't moved. He turned his head slightly toward Michael. A simple nod. No words. Just that subtle dip of his chin."
    hide michael with dissolve
    "Michael understood. He stepped into the shadows and vanished down the corridor, his boots striking once, twice, then gone. And Janet was alone. Alone with Markus."
    show markus cold at center with dissolve
    "He stepped closer, the air shifting with his presence. The faint lantern light cut across his figure, but his face remained hidden, half-devoured by shadow. She strained to find any trace of the man she knew. The silence stretched, unbearable."

    menu:
        "Why?":
            jn "Why?"
            "The word cracked, fragile in the damp air. No reply."
        "What is this?":
            jn "What is this?"
            "The words cracked, fragile in the damp air. No reply."

    jn "Why am I here? What are you doing? Markus… what is this?"
    "Still nothing. He stood above her, unmoving, watching."
    jn "Why am I chained? Why are they — why are you letting them — You brought me here! You said it was just a trip, you —"
    jn "Talk to me! Please. Just — say something."
    "The tears spilled, hot streaks cutting down her cheeks. Markus remained silent. His face was hidden in shadow, but she thought she saw his lips twitch — not a smile, not a frown, just a shift. It was enough to unravel her. Her grief ignited into rage."
    "Her body surged against the chains, metal scraping skin raw, shoulders straining until it felt like her joints would snap."
    jn "Answer me! You bastard! Don't you dare stand there like I'm nothing — like I'm not even worth your words!"
    jn "You liar! You coward! You filthy piece of —"
    "Her scream broke into an animalistic growl, guttural, feral, tearing out of her throat as if she could bite him from where she stood. But Markus didn't move. Didn't flinch. His shadow stretched long, swallowing hers, his silence heavier than her chains."
    "The fight drained out of her in jagged sobs. She slumped against the stone, the iron cuffs biting harder as her weight pulled down on her wrists. Her eyes lifted once more to him, blurred with tears."
    jn "Why won't you look at me?"
    "Still no answer. The silence wrapped around her, suffocating, until it felt like the whole chamber was complicit in his cruelty. Markus loomed above, unreadable, untouchable, the man she thought she loved buried under shadows that refused to part."

    "For a heartbeat, silence held. Then, slowly, his head tilted — an ironic nod, slight but unmistakable. His lips curved into a small, mocking smile. A smile that told her her plea was laughable."
    mk "You should be honored. Honored you are here."
    mk "Of course, you aren't. And you never will be. You'll never understand what this means."
    "A quiet chuckle, humorless, sharp. He stepped closer. She tried to recoil, but the shackles rattled, holding her in place."

    scene cg join_you_soon with dissolve_slow
    window hide
    pause 2.0
    window auto
    "His hand shot forward, sudden and strong, clamping around her chin. The grip was iron, bruising, yanking her face upward toward his. She jolted helplessly, dragged forward by the sheer force of it."
    jth "I don't remember him being this strong."
    "Their faces were inches apart. She could see him now — the hardness of his jaw, the stillness of his expression. His eyes bore into hers with a detached superiority, cold, clinical, as though she were no more than a specimen under glass."
    "Fear crawled up her throat. She wanted to scream, but his grip held her still, her words trapped behind the iron clamp of his hand. And then, suddenly, it changed."
    play music m_emily fadein 2.0
    "His face softened. The shadows shifted. The stern lines melted away, his eyes warming, kind, almost tender. It was him — the Markus she knew, the Markus she had fallen for."
    jn "Markus…"
    "Barely a whisper. Choked. Desperate. A plea. His grip remained firm, but his tone changed. Softer now, gentle, laced with the affection she remembered."
    mk "Don't worry. Amanda will join you soon. You won't be alone."
    stop music
    "Her eyes widened, hope and horror twisting together violently inside her. And then his lips twitched. The warmth vanished. His chest rumbled with laughter — cruel, jagged, mocking. The sound ripped through her like claws."
    play sound sfx_thud
    with hpunch
    "With a sudden shove he pushed her chin back, forcing her head to snap against the cold stone wall. She gasped at the impact, pain flaring as she crumpled forward again, her wrists yanked taut by the chains."

    scene bg cell_janet with dissolve
    show vignette
    show markus cold at center with dissolve
    "Markus stepped back, his shadow stretching across her once more, his face unreadable again — hovering between the mask of the man she loved and the monster in his place. Her sobs broke free, ragged and sharp. Fear hollowed her out, but beneath it something else burned: betrayal."
    jth "The man I trusted, the man I thought I loved — he's gone. Or worse: maybe he was always this."

    show markus cold at left
    show michael neutral at right with dissolve
    "His laughter still rang in her ears when the sound of heavy steps filled the chamber. She lifted her head weakly. Michael entered, his massive frame filling the doorway, his face as blank as ever. But what he carried made her stomach twist violently."
    play sound sfx_thud
    call mature_show("kalinos_corpse")
    "The priest's body dangled from his grip, limp and broken, head lolled to one side. The old man's thin frame looked even more fragile now, his skin pale, his mouth frozen in that hideous smirk."
    "Michael dropped him onto the stone floor with a wet thud. The corpse sprawled at the doorway, a dark heap, arms bent beneath it, the echo of the impact reverberating off the walls."
    call mature_hide
    "She gagged, bile rising in her throat. Her chains rattled as she recoiled, pressing herself hard against the wall. The metallic taste of blood from biting her tongue filled her mouth."
    mi "It's done."
    show markus fervent
    "For a heartbeat, silence hung. Then Markus laughed. The sound was sharp, delighted, genuine. He clapped his hands once, twice, the sound echoing like applause in a theater."
    mk "Magnificent. Absolutely magnificent."
    "She stared at him through tear-blurred eyes, unable to reconcile the man she'd once trusted with the one grinning before her now. Markus turned to Michael, his posture alive with an energy she had never seen in him, his voice warm with excitement, as if speaking of a celebration."
    mk "Come on. Let's feed it."
    jth "Feed it."
    "The words sent ice slicing down her spine. She didn't understand. Didn't want to. Michael nodded once, silent, obedient. He bent and hoisted the priest's corpse back into his arms with the same ease one might lift a sack of grain."
    jn "What are you doing?"
    "Her voice cracked, dissolving into sobs. Markus didn't look at her. He only spared her a glance, his grin still painted across his face. To him she wasn't a person anymore. She was a vessel, an object, a thing to be prepared."
    hide markus with dissolve
    hide michael with dissolve
    "The two men turned, the corpse slung between them, and walked toward the doorway. Their footsteps echoed, fading into the corridor, carrying the weight of death with them."
    play sound sfx_thud
    "The door shut behind them with a hollow thud, sealing her once more in silence. Alone with the cold stone, the dripping water, and the image of Markus's smile burned into her mind."

    play music m_emily_reprise fadein 3.0
    "Her chest heaved, the chains rattling as her body trembled. Every nerve screamed to collapse, to sink into despair. But Markus's words twisted in her head."
    "{i}Amanda will join you soon. You won't be alone.{/i}"
    "Amanda. Her sister. Her anchor. Her savior."

    menu:
        "Hold on to her.":
            jth "Amanda will come. Amanda has always come. She was the one who stepped in when the world tried to break me, who held me steady when everything else was chaos."
            "If anyone could tear through this nightmare, it was Amanda. But the hope fractured, splintered by terror."
        "Hear what he actually said.":
            "She reached for the thought — Amanda would come, Amanda had always come, the one who held her steady when everything else was chaos — and the words he had used slid in between."

    jth "Join you."
    "Not rescue. Not save. Markus hadn't said Amanda would free her. He had said Amanda would join her. Chained. Broken. Humiliated. Her stomach churned. She shook her head violently, as if she could scatter the words from her mind."
    jn "No. No, Amanda… you won't come here. You can't."
    jth "She'll fight. She's strong. Stronger than me. She won't get caught. She won't."
    "Her tears blurred everything. She squeezed her eyes shut, pulling hard against the chains until her wrists burned. But the voice in her head mocked her, cruel and relentless."
    jth "She will. They'll drag her here like they dragged you. She'll be in these chains beside you. And then you'll both be nothing."
    jn "No!"
    "Her voice echoed, raw with fury and fear. She convulsed with sobs, but still she pulled at the cuffs, bruising herself against the iron. Her mind swung back and forth. Amanda would save her. Amanda would fall with her. Amanda was unbreakable. Amanda was already doomed."
    jn "Please don't come."
    jn "Please… don't let them take you too."

    stop music fadeout 3.0
    jump ch11
