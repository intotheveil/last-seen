## Chapter 13 — "Keep Your Fire"
## Source: docs/manuscript/ch08.txt l.140–278. POV: Markus (the gate, the memory), Janet (the chain),
## Amanda (the church, the undercroft, Michael). Beats 41–46 per docs/horror_beats.md.
label ch13:
    call chapter_card(13, "The clearing — the gate redrawn")

    # --- Markus: the gate redrawn --------------------------------------------------
    scene bg tree_clearing_ritual with fade_slow
    show vignette
    play ambient sfx_storm fadein 2.0
    play music m_george fadein 2.0
    call place("The clearing above the church — the storm")

    "The storm had thickened the air, thunder rolling low across the hills. Markus hauled Janet through mud and roots until the trees thinned."
    "The ritual site opened like a wound in the forest: a wide circle of blackened earth where nothing grew. The great Tree loomed at its center, its bark veined with scars, its crown twisting into the clouds."
    show janet chained at far_left, dimmed with dissolve
    "Janet collapsed when he released the chain, her body curling at the base of a stone marker. Her breaths came in shallow gasps, her arms streaked with mud, her skin blotched with cold and fear."
    "Markus paid her no mind. He knelt in the circle's heart and spread out the cloth bundle. Chalk sticks, blades, old iron compasses. His instruments of precision."
    "With obsessive care he redrew the sigils etched into the soil, repairing broken lines, pressing the symbols deep into the damp earth. Every stroke of chalk steadied him. Each line whispered to him of control."
    "Behind him Janet whimpered softly, but the sound barely touched him. He paused only once, lifting his head toward the looming Tree."
    "The chalk scratched in uneven arcs and stopped. The stub trembled between his fingers. This was the first time the lines belonged to him, and his hand knew it."
    mth "Excitement. And under it, something colder. Nerves. Fear."

    stop music fadeout 2.0
    scene bg undercroft_circle at memory with dissolve_slow
    play music m_funeral fadein 3.0

    "He clenched his jaw and forced himself to remember. Kalinos's voice, brittle as old paper, rose from the back of his mind."
    kal "Look closer, boy. Not every circle is the same. This—"
    "Markus had been only ten, hunched on cold flagstones, watching the priest's bony finger trace symbols into the soot."
    kal "This is not ornament. This is a gate."
    "The outer ring took shape beneath his fingertip even now as he recalled it. Kalinos's cracked nail had scratched the words into the dust."
    play sound sting_word
    note_voice "ΚΛΕΙΣ ΕΚΑΤΗΣ ΦΥΛΑΞ"
    "The Key of Hecate. Guard."
    kal "Hecate opens. She alone commands the crossing between living, dead, and divine. Without her, nothing passes. With her, everything can."
    "The priest had leaned so near that the boy could smell the wine on his breath. Markus shifted the chalk to the hexagram at the center, his lips almost moving with the echo of the old man's words."
    kal "The Seal of Solomon. The lock. Not Christian, not Greek — older. It binds what we call, keeps it from breaking us. The triangles hold the star, and the spirals keep it awake."
    "He remembered asking once, child-curious, what happened if you forgot the spirals."
    "Kalinos's answer had been a backhand so sharp Markus's teeth cut his lip. Then the hiss, low in his ear."
    kal "Then you are food for it."
    "The serpents had been the part that haunted him longest: two chalk lines twined around the Key, looping into an infinity."
    kal "They bind the center. The sigil breathes through them. Do not draw one without the other."
    kal "And at the four corners, the names. Michael. Uriel. Raphael. Gabriel. Guardians. You will write them, for without them the vessel tears open, and all of us with it."

    scene bg tree_clearing_ritual with dissolve_slow
    show vignette
    show janet chained at far_left, dimmed
    "Markus pressed harder. The chalk snapped. He hissed between his teeth, snatched another stub and drew faster. Thunder rolled above, shaking the ground. He smirked."
    "He tightened the circle with one last stroke, smearing chalk into the damp stone. His breath came shallow, uneven. For all his preparation, for all his power, one thought slid in unbidden — cold and sharp."
    stop music fadeout 1.5
    mth "Sofia."
    "He had been only ten when he saw her. The chosen vessel. Or rather, the victim. She hadn't gone to the altar willingly. They had dragged her, and she had begged, and no one listened."
    "They forced the Fruit into her mouth. At first there had been silence. Hope. The elders' eyes glistened; Kalinos's hand trembled as if this might finally be the one."
    "Then came the sound. The tearing. He swallowed hard, but the memory unfurled regardless — the smell of iron and bile and burning wax, and the word that came after it."
    mth "Failure."
    "What if the blood wasn't enough? He had spent years pouring it into himself, drop by drop, reshaping what he was. He was stronger now, veins humming with something more than human."
    mth "But what if it isn't enough? What if the ritual chews me up the same way — leaves me a screaming carcass on the stone?"
    "His grin faltered. Just for a moment. He clenched his forearm, fingers digging into the muscle, as if brute pressure could prove its worth."
    "The chalk crumbled in his hand."
    hide janet with dissolve_fast
    "The sound of chains broke the silence — too close, impossibly close. Behind him, the stone marker stood empty. He turned—"

    # --- Janet: the chain ------------------------------------------------------------
    play music m_route_nine fadein 1.0
    show markus cold at center with dissolve_fast
    "Janet lunged from the shadows, the iron biting into her palms as she looped the chain around his throat. A ragged grunt tore from her chest, half scream, half sob, as she wrenched backward with all her strength."
    "Her knees drove hard into his spine, anchoring her, tears hot on her face. She dragged the chain tighter, tighter, until the links cut into her skin."
    "Markus's body jerked under her — twitching, convulsing with the air choking out of him. And yet his hands never rose. His arms stayed limp at his sides."
    jth "As if he's surrendered to it. As if he wants this."
    "The thought almost froze her. Rage drove her on. She clenched harder, teeth grinding, pulling until her vision blurred with tears and fury."
    jn "Die, Markus. Die. {i}Die.{/i}"
    "For a fleeting moment, he almost let go. Such an end was… fitting. Almost merciful. Almost human. But mercy had no place in him. Ambition, venomous and endless, rose through him like fire, and his lips curled into a smirk even as the chain cut deeper."
    show markus fervent at center
    "Slowly, impossibly, he pushed. Muscles in his neck bulged, tendons straining. Inch by inch he forced his head forward, every motion deliberate, defiant."
    "Janet's scream ripped across the clearing as she threw everything left in her into one final, desperate pull. The chain cut her palms raw. The links sang with tension."
    "But still he moved. He rose, dragging her with him, as though her effort was nothing but air. Her scream warped into a sob of disbelief. His voice came shredded through the constriction, bubbling, triumphant."
    mk fervent "Harder… come on… harder."
    "She poured everything into a last savage pull, but it was like trying to strangle stone. The more she fought, the more he rose."

    scene black with flash_red
    play sound sfx_thud
    "He jerked upward. The chain snapped her forward, her face into his shoulder blade. Pain burst through her nose, hot and metallic, and her grip faltered."
    "He twisted, fast and brutal, ripping the chain from her bleeding hands. The links tore skin as they slid free."
    play sound sfx_thud
    "Then the chain came back in a sharp arc. The sound cracked across the clearing — iron on flesh."
    "She was on her side, choking on her own breath, hands clutching her face. Tears and blood mixed as she coughed. The humiliation was rawer than the pain."

    scene bg tree_clearing_ritual with fade
    show vignette
    show markus cold at center with dissolve
    "Markus stood above her, dragging the chain through his hands, each link ringing like a tolling bell. His throat bore deep red grooves, already darkening into bruises, but his grin only widened."
    "He crouched low, bringing his face level with hers, forcing her to look at him. His breath stank of iron and rot."
    mk cold "You thought this would end with you victorious? That you'd choke a god with your little hands?"
    "His tone was smooth, almost affectionate. Almost. He pressed the chain along her jaw, iron cold against her bruised skin."
    mk "You are nothing but a vessel. A body to be used. A throat to scream when I decide you scream."
    "She wanted to spit at him, to deny him this satisfaction. Her body betrayed her, curling tighter under his gaze."

    scene black with fade
    "His fist closed in her hair and yanked her upright. Her scalp burned as he dragged her across the stones like she weighed nothing, her knees scraping raw. She clawed at his hand. He ignored it."
    play sound sfx_thud
    "When he dropped her again, it was at the edge of the seal he had drawn. The chalk lines glowed faint in the torchlight, symbols ready to drink her blood."

    scene bg tree_clearing_ritual with fade
    show vignette
    show markus fervent at center
    "Janet coughed, swallowing the taste of iron. She raised her head just enough to look at him, hate still sparking behind the tears."
    "Markus laughed — a deep, cruel laugh that rolled back off the trees."
    mk fervent "Good. Keep your fire."
    mk "I want to watch it go out."
    hide markus with dissolve
    stop music fadeout 2.0

    # --- Amanda: the church, the undercroft -------------------------------------------
    scene bg church_nave with fade_slow
    show vignette
    play music m_judgment fadein 3.0
    call place("The church — the bells still tolling")

    "Amanda pushed the heavy doors inward, their hinges groaning like old bones. The echo rolled through the nave, swallowed by the hollow belly of the church. She let the hood fall back, wet hair clinging to her cheeks."
    "The air was thicker here — warmer than the storm, yet stale, as though no true prayer had been spoken for decades. Incense lingered in the walls, tangled with damp stone and the sour bite of mildew."
    "The stained glass stared back like dull eyes. No saints, no holy scenes — just panes of red and green twisted together like veins beneath skin. Rain streaked them until the whole nave seemed submerged."
    "Then she saw the marks. Faint circles carved into stone, spirals scratched under the arches, burned into wood. Once seen, they were everywhere."
    $ note("Circles carved into every stone of the church. Spirals under the arches. Once seen, they were everywhere.")
    "The muffled toll of the bells seeped through the walls, every strike a reminder: time was running short. Soon this place would no longer be empty."
    "A scream split the silence. A woman's voice — raw, shrill, then cut off."
    "It had come from behind her. To her right, hidden between two columns, a narrow stairway yawned like a wound in the stone, its steps vanishing into black."

    menu:
        "Janet—":
            "Her mouth opened on the name. She shut it before the sound could leave. Whatever had made that scream stop was still down there, and the only thing she had to answer it was the knife."
        "Go down. Quiet.":
            "Her body resisted. Her feet moved anyway."

    scene bg church_stair with dissolve
    show vignette
    "Knife slick in her palm, she edged into the stairwell. The air grew colder, stagnant, carrying mold, wax, and beneath it the metallic tang of blood. The stone under her hand was slick with condensation, damp like sweat."
    "The stairwell narrowed, rough steps worn deep by countless feet. Another scream echoed below, shorter, choked. She nearly turned back. The thought of Janet, bound and screaming, drove her onward."
    "At last, faint light flickered below. The archway at the bottom was etched with deep circles, gouged violently into the stone."
    "She tightened her grip on the knife and stepped into the undercroft."

    scene bg undercroft_corridor with dissolve_slow
    show vignette
    "Amanda killed her flashlight before her boot touched the floor. Darkness closed in, suffocating, but she welcomed it. Better to vanish than be seen."
    "The undercroft spread like the bowels of something long dead. Corridors cut from raw stone twisted sharply, ceilings dripping. Niches opened in the walls, stacked with bones like firewood, skulls staring out with hollow eyes."
    "The air reeked — mold and rust, iron and rot, clinging thick to her tongue. A rat skittered past, swollen and mangy. Then only the drips from the ceiling, and the faint hum of chanting vibrating through the walls."
    "Deeper still, alcoves: skeletons shackled upright, jaws frozen in silent screams, robes decayed to threads. She forced her gaze forward, jaw clenched."
    $ note("Skeletons shackled upright in the undercroft, robes rotted to threads. They have been doing this for centuries.")
    "The floor dipped into pools of black water that mirrored her in jagged shards. Her boots splashed, too loud, too exposed. She froze. Only the water dripping back answered."
    play sound sfx_thud
    "Then — a sound. A door. Heavy wood, iron hinges grinding. Somewhere ahead, a hollow thud as it closed."
    "She crouched low, knife raised, pulse hammering. Footsteps? Chains? Then silence."
    "She moved on, guided by a faint draft carrying smoke, fresher than the rot. Lightning flickered through cracks above; skulls glared from the walls. Another rat darted from the bones, and she flinched, back pressed to stone, until the silence came back."

    scene bg undercroft_door with dissolve
    show vignette
    "Finally, she found it. A heavy door, iron-bound, damp wood swollen with centuries. Symbols carved deep, circles intersecting, lines scored over and over until the wood seemed to bleed splinters. Torchlight flickered under the crack at its base."

    menu:
        "Put an ear to the wood.":
            "She crouched low, heart in her throat, and pressed her ear against the door. Silence. Not the silence of an empty room. The silence of something holding its breath."
        "Don't wait. Go in.":
            "Waiting had never saved anyone. She set her palm to the swollen wood."

    "She entered."

    scene bg cell_abomination with dissolve
    show vignette
    stop music fadeout 1.0
    show michael neutral at center with dissolve
    "Her breath caught in her throat as the man stepped into full torchlight. He was massive, shoulders squared beneath a soaked shirt clinging to muscle, his bald skull shining with sweat and rain."
    "His eyes were small, pale, deliberate. Eyes that didn't blink often. Eyes that weighed rather than looked."
    mi "He was right, again."
    $ note("'He was right, again.' Markus knew I would come. He has known all night.")
    "Her gaze flicked past him — and the scream clawed its way into her lungs and never came out."
    ath "Another one."

    scene cg profane_crucifix with dissolve_slow
    window hide
    pause 2.0
    window auto
    "The abomination dwarfed the thing she'd seen in the fog. It hung at the far wall like some profane crucifix, its gaunt frame stretched out by more than a dozen chains sunk deep into the stone."
    "Its skin was a parchment veil over a body too long, too hollow, the ribcage rising and falling with slow, deliberate breaths. The head tilted ever so slightly, hollow eyes glimmering in the torchlight."
    "It wasn't thrashing. It wasn't growling. It was watching. Watching her."

    scene bg cell_abomination with dissolve
    show vignette
    show abomination chained at far_right, dimmed
    show michael neutral at midleft
    "Every instinct screamed to flee, but her body locked. She forced herself to look away, to anchor on the man instead."
    am hard "Where is Janet?"
    "Michael halted. For a moment his face remained blank, carved from stone, as though he was weighing her voice like a coin in his palm."
    mi "I'm going to take you to her."
    "Not reassurance. Not threat. Just fact. Her hand twitched at her side, fingers brushing the knife handle hidden in her waistband."
    am hard "And that—"
    "She nodded toward the chained horror. Her voice cracked under the weight of it, but she forced herself to go on."
    am "What the hell is that thing? What are you doing here? Are you with Markus?"
    "Michael's jaw clenched. He said nothing. He started forward again, each step deliberate, each one pressing her closer to the corner. He didn't need to run, didn't need to threaten. He was a wall of inevitability."
    ath "He's larger. Faster. Stronger. No chance in a straight fight. None. And if he gets his hands on me, it's over."
    "The abomination rattled one chain, faint but deliberate, the sound scraping the silence like a blade against bone. Even restrained, it seemed part of the exchange — as though it, too, was waiting to see what she would do."
    show michael neutral at center
    with hpunch
    "His hand shot out with sudden, brutal speed. His fingers clamped around her wrist like iron, wrenching her upward with such force her feet left the ground. The knife in her other hand wavered uselessly in the air between them."
    "She gasped, teeth clenched, kicking against the stone floor. He didn't flinch. His grip wasn't merely strong. It was absolute. A wall of flesh and bone holding her like a child's toy."
    show abomination chained at far_right
    "From the far side of the chamber came a voice — low, resonant, yet fractured at its edges, as though a thousand mouths whispered the words in imperfect unison. Human and not. Clean, and corroded."
    ab "Kill him…"
    "Her head whipped toward the chains. The sound hadn't come from lungs or throat. It vibrated through the stone, through the marrow of her bones."
    "Its mouth spread wide, too wide, skin stretching until its lips tore into a rictus grin that split nearly ear to ear."
    ab "Kill him… and I shall talk with you."
    $ note("Kill him… and I shall talk with you.")
    "Michael froze. His grip didn't loosen, but his head turned toward the chained horror. His pale eyes twitched — the first true crack of doubt she had seen in him. The command hung in the air like smoke."
    ath "It isn't offering help. It's baiting me."
    "The creature leaned into its chains, metal groaning, breath hissing like steam from a furnace. Michael growled low in his chest and forced her closer. He would drag her to Markus. Throw her at the feet of the cult. And then—"
    ath "Janet."
    "She had killed already — the butcher in the tavern. She had justified it because she had no choice. This was different. This wasn't defense, not yet. This was murder on command. A pact with something she could barely look at."
    ath "He'll kill you anyway. Markus will kill you anyway. And Janet dies with you."
    "She wanted to vomit. She wanted to scream. She wanted to run."
    "Instead, she moved. Her free hand dropped and found the hilt of the little knife at her waistband."

    scene black with flash_red
    play sound sfx_thud
    "Before she could think again, before she could hesitate, she ripped it up and drove it into Michael's throat."
    "A wet crunch, then heat."
    "He gurgled, the sound obscene, thick with fluid. His fingers spasmed; the iron hold turned weak, then looser still. She tore herself free, stumbling backward, her arm finally hers again."
    "He staggered once, lips parting as if to speak. Only a bubbling choke came. His eyes locked on hers — not with hatred, but something closer to betrayal."
    play sound sfx_thud
    "Then his knees buckled. The weight of him hit the ground like a felled tree."

    scene bg cell_abomination with fade
    show vignette
    show abomination chained at far_right
    play sound sfx_tinnitus
    call mature_show("michael_corpse")
    "His body twitched once, the knife still jutting from his throat, and collapsed into stillness."
    "Amanda stood frozen, chest heaving, blood flecked across her cheek and hands. Her vision tunneled. The air stank of iron and smoke, heavy with the taste of death."
    call mature_hide
    "And then — the sound."
    "From the chains came a noise that curdled her marrow. Laughter. No — something between a chuckle and a death rattle, guttural and hollow. The abomination leaned forward against its restraints, the grin still split wide across its face."
    play sound sfx_heartbeat
    "The chamber fell silent but for the drip of Michael's blood onto stone, the hiss of the abomination's breath, and her own ragged heartbeat."

    jump ch14
