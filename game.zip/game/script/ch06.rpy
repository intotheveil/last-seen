## Chapter 6 — "Coffee, and the Road"  (ch04.txt l.236–386; Janet POV)
label ch06:
    call chapter_card(6, "Janet — nine-oh-two")

    scene bg janet_bedroom with fade_slow
    play music m_emily fadein 2.0
    call place("Janet's flat — the same morning")

    "Janet's eyes fluttered open to sunlight already spilling across the room. She stretched long and slow, arms overhead, her t-shirt ridden up in the night, her cotton shorts clinging softly to her thighs. The careless comfort of youth, the kind of ease that didn't need to be posed."
    "Eventually the murmur of voices from the other side of the apartment pulled her fully awake. Bare feet on cool floorboards. A small yawn. She brushed tangled hair from her eyes and tied it loosely with an elastic from the nightstand."

    scene bg janet_kitchen with dissolve
    show jenny neutral at left with dissolve
    show lara worried at right with dissolve
    "The kitchen smelled of toasted bread and coffee, the light bouncing off the white tiles almost too clean for morning. Two of her roommates were already at the table, bowls of cereal half-finished, a plate of sliced fruit pushed between them."
    je "Morning."
    "A little wave, a voice still rough with sleep. Janet's smile came easily. She slipped into the chair opposite, poured herself a cup from the pot, and inhaled the rich bitterness before taking her first sip."
    "Jenny was, as always, composed in her own chaotic way — tall and thin, long legs folded beneath her chair, lips glossed, eyeliner precise, blonde hair rising in fuzzy strands like static."
    "Lara looked younger than she was, perched low over her bowl: small, pale, narrow eyes magnified by round glasses, owl-like, ears lined with piercings. She chewed quietly, always quietly, as if trying not to take up space."
    je "So. What's your plan today? Don't tell me you're just going to laze around all day while looking smug."
    "Half challenge, half tease, a slice of toast pinched between her fingers."
    jn "Actually, I'm meeting Markus later. He invited me to go with him on a trip."
    "Lara's spoon clattered against her bowl."
    la "A trip? Since when? You didn't say anything about that yesterday."
    jn "Since last night. He called me when I stepped outside for air. Something came up — he's going to visit his family, in the countryside. He asked if I wanted to come."
    je "The countryside, huh? That's serious. You don't just invite someone to tag along for a trip like that unless you want them to… see something."
    la "How long are you going to be gone? Because we were supposed to—"
    "She stopped herself, adjusting her glasses as if to buy time."
    la "Never mind. It just feels… sudden."
    "Janet reached across and touched Lara's wrist lightly, the gesture small but steady."
    jn "Don't worry. It's not like I'm disappearing. Just a couple of days. He wants me to see where he grew up, that's all."
    je "That's all? Please. You're practically being ushered into the next level. Meet-the-family country edition. Tell me you packed something nicer than those shorts."
    jn "Don't get ahead of yourselves. It's just a trip, nothing more."
    je "Mm-hmm. I give it a week before he drops the 'future plans' talk on you."
    "Lara blushed faintly and ducked her head."
    la "I… I think it sounds nice. Markus makes you happy. That's… obvious."
    "Something flickered across Janet's expression then — softer, less guarded."
    jn "He does."
    "Her voice had dropped lower, honest in a way that wasn't for show. For a moment the room settled: Lara's spoon scraping the bowl, the muted hum of city traffic beyond the window."
    je "Fine, but you owe us. I expect souvenirs. Something homemade. I don't care if it's a jar of jam, a scarf, or a bottle of strong country liquor. If I'm stuck in this city while you're off on your little countryside getaway, I at least deserve proof."
    la "Jenny, it's not some exotic vacation. It's just his hometown."
    je "Exactly. All the more reason to bring back something memorable. Rustic charm, you know?"
    jn "You two are impossible."
    "Jenny stretched her long legs under the table until her foot nudged Janet's shin."
    je "True. But admit it, you'd be bored without us."
    "Janet didn't deny it. She just lifted her mug, a smile hovering at the edge of her lips, her eyes sparkling with that unreadable, secret light."
    play sound sfx_beep
    "Her phone buzzed against the kitchen table, the screen lighting up with Markus's name. She tapped it open, her lips curving into an instinctive smile as she read."
    note_voice "Good morning, beautiful. I'll pick you up in about thirty minutes, I bought you fresh croissants for the road."
    "Her pulse fluttered, warmth rising in her chest. She set the phone down gently and pushed back from her chair."
    jn "I have to go get ready. Markus will be here soon."
    "Jenny whistled under her breath, exchanging a glance with Lara."
    je "Country getaway starts now."
    "Lara gave her an encouraging nod, eyes bright behind her glasses. Then, in a more serious tone:"
    la "By the way — how is his treatment going?"
    jn "Well, there are days… Difficult days for him. His medication seems to have some side effects time to time, but he is fine. He is doing better and he is always positive."
    "She said it caring, smiling. Silence lingered in the room for a few minutes."
    hide jenny with dissolve
    hide lara with dissolve
    "Janet drained the last of her coffee in a single, practiced sip and rose. Unhurried, elegant, even here in the familiarity of home, her bare feet light on the floorboards as she crossed to her room."

    scene bg janet_bedroom with dissolve
    "The soft clutter of her space: the faint scent of her perfume, clothes folded in neat stacks, a half-burned candle on the windowsill. She slid the closet door open with a quiet rasp. Rows of clothes — casual, chic, playful."

    menu:
        "The dark jeans and the cream sweater.":
            "Fitted dark jeans that hugged her long legs but carried a modest simplicity. For the top, a cream-colored knit sweater, soft and warm against the skin, with a neckline that revealed just enough without demanding attention."
        "Something Jenny would approve of.":
            "Her hand drifted to the short things, the bright things, and drifted back. Not for his parents' doorstep. Fitted dark jeans, modest and simple; a cream knit sweater, soft and warm, the neckline revealing just enough without demanding attention."

    "She laid them across the bed and tapped her lip. Autumn was restless this year, the wind colder than usual. From the back of the closet she pulled a light trench coat in muted beige — practical, but cut to flatter her figure."
    "At the mirror she inspected herself critically. Fingers through her hair; a loose strand tugged into place. Her nails were still perfect, the deep burgundy polish catching the light, toes painted the same. No salon fixes to rush."
    "She wanted to be flawless, not for vanity nor for Markus, but for the satisfaction of being in full control of her image."
    "Her clothes fell away piece by piece. The jeans slid snug against her hips, the sweater draped in that balance between modesty and allure. She rolled her shoulders beneath the coat and smiled faintly at the reflection."
    extend " Casual, yes. But it carried the quiet power of someone who knew how to turn ordinary into something magnetic."
    "On the nightstand she reached for her small cosmetics bag — and her hand hesitated at the edge of a photo frame lying there."
    "She lifted it slowly. Her and Amanda, side by side, smiles caught in a candid moment. Amanda looked more serious, her pride quiet and steady, while Janet's joy had been all sparkle and warmth. Her chest softened at the sight, an ache mixed with affection."
    jth "Mandy."
    "A genuine smile, deeper than the playful smirks she showed the world. She set the photo down carefully, as if not to disturb the memory it carried, took up the cosmetics bag, and went to finish in the bathroom."

    scene bg janet_hall with dissolve
    "The corridor was dimmer, the morning light reaching only so far. Lara lay stretched on the sofa, scrolling idly across her phone, its glow lighting her pale features. She looked up and gave Janet a small smile, more habit than intention, before returning to the screen."
    "From down the hall, drawers opening and closing: Jenny had already disappeared into her room. Janet's heels clicked softly to the bathroom. She closed the door with a quiet firmness, shutting out the fragments of her roommates' lives."

    scene bg janet_street with fade
    stop music fadeout 1.0
    play ambient2 sfx_crowd fadein 2.0
    call place("The street — 9:02")
    "Minutes later the building's main door swung open and Janet emerged, the muted beige of her coat catching the light."
    "The city greeted her all at once: a hum of motion and sound, footsteps on pavement, voices in overlapping streams, horns punctuating the morning rush. Janet didn't shrink from it."
    "Shoulders squared, chin lifted, her movements unhurried yet commanding. She walked as though the street belonged to her, as though the crowd existed only to part around her."
    "Heads turned. Some lingered; others darted back, embarrassed to be caught staring. She didn't need to notice to know — her beauty carried its own gravity, and she was entirely aware of it."
    "Her gaze drifted across the avenue and landed on the car parked just ahead. Familiar, dark-colored, the low growl of its engine idling softly as if in anticipation. The corner of her mouth curved upward."
    jth "Markus."
    "Her stride quickened slightly, never losing its elegance. Even here, among people hurrying with their own unseen burdens, she carried herself like a figure apart. Untouchable."
    "Markus leaned across the driver's side as she approached, his hand shifting to unlatch the passenger door. Her smile deepened."
    "She crossed the final stretch of pavement with unshakable poise, each step a declaration — of confidence, of beauty, of the certainty that the day ahead would belong to her."

    scene bg markus_car_city with dissolve
    stop ambient2 fadeout 1.5
    play ambient2 sfx_engine fadein 2.0
    play music m_long_road fadein 2.0
    show markus neutral at right with dissolve
    "Markus slid a paper bag across the console as soon as her seatbelt clicked into place. The bag crackled, warm grease spots seeping faintly through the thin paper."
    mk "Still warm."
    "A half-smile, one hand steady on the wheel. Janet's eyes lit up."
    jn "Ah, bless you."
    "She leaned over and kissed his cheek quickly, a soft brush of lips, before pouncing on the bag with both hands."
    jn "Don't tell me you waited in line for these?"
    mk "Ten minutes. Not even. You were late, so I had time."
    "His gaze stayed on the rearview mirror as he eased into the stream of traffic."
    jn "Excuse me? I was exactly on time."
    "Mock outrage. She tore the bag open, and the buttery scent of warm croissants filled the cabin."
    mk "You said nine."
    jn "It's nine-oh-two. Don't be dramatic."
    "Through a mouthful, already biting into the first croissant like she hadn't eaten in days. He chuckled under his breath, shaking his head. She licked a smear of chocolate from her finger and glanced at him sidelong."
    jn "Mmm. These are perfect. But next time, bring me one of those — what do they call them? Bretzels? The German things."
    mk "Pretzels. But you mean the soft kind, not the crunchy ones in a bag."
    jn "Yes, the bread ones! Big, chewy, with the salt crystals. That's my dream breakfast. Croissant in one hand, pretzel in the other, coffee balanced on my knee. Bliss."
    mk "You're insatiable."
    jn "Guilty."
    "She leaned forward and turned the radio up a notch. Outside, the city was beginning to hum: a wide boulevard of apartment blocks, laundry swaying from balconies like banners of domestic life, cafés crowded on the corners, delivery bikes weaving recklessly between lanes."
    jn "You know what I love about mornings like this?"
    mk "What's that?"
    jn "Everything looks like it has a pulse. Look at that bakery — line out the door already. Look at that woman balancing three coffee cups like she's in a circus act. It's chaotic but alive. The city wakes up and suddenly everyone's part of the same machine."
    mk "Romantic description for gridlock traffic."
    "He eased the car into the next lane as a taxi cut in front of them. She laughed, tossing him a crooked smile."
    jn "You're just grumpy because you hate mornings. Admit it."
    mk "I don't hate mornings."
    jn "Oh please. You're silent until your first coffee, and even then, words come out like rationed tokens. It's like you have to pay per sentence until noon."
    "Markus smirked but didn't argue, which Janet took as victory. She tossed the last bite into her mouth, wiped her hands on a napkin, and leaned back against the headrest."
    jn "Fine. Then I'll do the talking. You just drive and nod occasionally. Deal?"
    mk "Deal."
    "For the next stretch of road she held true to her promise. The broken washing machine that flooded her bathroom floor. The neighbor's endless renovations upstairs. The podcast that explained why pigeons bob their heads when they walk."
    extend " Markus listened, sometimes with a smile tugging at his mouth, sometimes with a short comment that nudged her along."
    "By the outer ring road their rhythm had found its groove. She teased him about his loyalty to Crete, insisting the Cyclades had better beaches. He countered with his grandmother's cooking, which could apparently defeat entire nations in a single bite."
    "She gasped dramatically, clutching her chest."
    jn "Are you seriously telling me you'd trade turquoise water and white sand for a plate of lamb?"
    mk "Yes."
    "She burst into laughter."
    "Traffic grew denser past the high-rises and the industrial stretch — trucks, graffiti-tagged walls, cranes above half-built towers. The city was loud, restless, alive, and Janet narrated it all like a tour guide."
    jn "Look, the florist is already open. And there's that man with the violin again — he's always on this corner! Doesn't he get tired?"
    "Markus only hummed in response, his attention fixed on the road. She didn't mind. Filling silence was her specialty."
    "The sun climbed higher, streaking the windshield with light. Janet lowered the visor and turned to study his profile in the glow. Calm, even content, his features softened by the rhythm of driving. A sudden swell of affection, impulsive and unfiltered."
    jn "You know, we're good at this."
    mk "At what?"
    jn "At… us. Driving together, talking, laughing. Just being."
    "He glanced at her, the corners of his lips twitching upward."
    mk "We've managed thirty minutes without a fight. That's promising."
    "She smacked his arm lightly, laughing again."
    jn "You're impossible."
    "The city faded in the rearview mirror. For Janet the drive so far was perfect — pastries, jokes, and the quiet certainty that the day ahead belonged to them alone."

    scene bg markus_car_country with dissolve_slow
    show markus neutral at right
    call place("The coast road — late morning")
    "The road unspooled ahead, long and quiet now, the hum of the tires steady against the tarmac. Fields, olive groves, a blur of roadside shrines with their tiny flickering lamps. The rhythm of it soothed her, even as she tried to keep the conversation alive."

    menu:
        "Ask about the little chapels by the road.":
            jn "Those little chapels — who keeps the lamps lit?"
            mk "Whoever passes."
        "Ask whether his parents still keep animals.":
            jn "Do your parents still keep animals? Goats, chickens?"
            mk "A dog."

    "His answers came in that steady, measured way of his — never dismissive, never unkind, just sparse. A word here, a phrase there. She teased him once or twice, nudging his arm, but he only smiled faintly and kept his eyes on the road."
    "It was enough. The silence between them wasn't heavy, not really. The music he'd chosen played low, a steady current filling the spaces. Outside, the land grew wilder, the neat geometry of the city replaced by hills rolling in green waves and pines shifting under the wind."
    "Janet's head grew heavier against the seat. She stifled a small yawn behind her wrist, laughing softly at herself."
    jn "Mind if I close my eyes for a bit? Didn't sleep much last night."
    "Markus glanced at her, and for the first time since they'd left the city his expression softened into something close to tender."
    mk "Of course. Rest. I'll wake you if you miss anything worth seeing."
    "She smiled, grateful, and curled into her seat, the crumpled croissant bag rustling in her lap. Outside, the trees blurred into vertical streaks, shadows sliding across her reflection in the glass. The music pressed on, a lull that soon pulled her under."
    "Within minutes her breathing slowed. Janet drifted into sleep, the countryside rolling past, while Markus drove on without pause, his hands steady on the wheel, eyes fixed ahead."

    hide markus with dissolve
    stop music fadeout 3.0
    stop ambient2 fadeout 3.0
    scene black with fade_slow
    play music m_alice fadein 4.0
    "The motion of the car lulled her, every curve and bend a rhythm her body couldn't resist. The music was steady, faceless, hypnotic — too polished to invite thought, too constant to ignore. Her lashes fluttered, once, twice. Darkness drew her under."
    "When her eyes opened, she was smaller."
    "Her legs dangled above the backseat floor, shoes tapping against vinyl. A child again. The air smelled of warm dust and fabric, her mother's lilac perfume wrapping around her like a memory she wanted to hold but couldn't. Her father's hands gripped the wheel, knuckles white."
    "A song played faintly, wrong in its brightness — a pop refrain that belonged to summer afternoons, not to this night. It pressed against her chest like a second heartbeat, like the music Markus had left behind moments before. The two times bled together."
    "Her mother turned and spoke. Janet couldn't hear the words — only the motion of lips, the smile, the reassurance. The old road… late again… it will be fine. She had seen this before. She knew what came next."
    play sound sfx_tinnitus
    "The screech of tires split the silence, metal shrieking against asphalt. Janet braced, small fists gripping the seatbelt as the world lurched — but this time it didn't end. The impact never came. The moment stretched like melted glass, holding her in place, refusing her release."
    "Her father's hands shifted. They grew broader, darker, until it wasn't her father at all. It was Markus behind the wheel, his jaw rigid, eyes fixed on the endless road."
    "And her mother wasn't in the passenger seat anymore. Amanda sat there instead, hair falling loose around her shoulders, hands folded neatly in her lap, eyes hidden in shadow."
    "\"Amanda?\" A child's whisper, too thin to be heard. Amanda did not answer."

    scene cg windshield with dissolve_slow
    window hide
    pause 2.0
    window auto
    "The windshield cracked. Not from impact, but from within. Spiderwebs of glass spread, each shard catching light — and in each shard Janet saw Amanda's face."
    "Dozens of them: smiling, crying, blank, screaming. Faces layered over each other, like broken reflections in a hall of mirrors."
    "The car spun but didn't crash. It plunged into a forest that hadn't been there seconds ago. Trees towered like black pillars, clawing the windows with branches that screeched like nails on stone. Insects battered the glass — thick clouds of wings buzzing like whispers."
    "Among the whispers came a voice. Not hers. Not Markus's. Not Amanda's. Low, ancient, stretched like something pulled too thin."
    "\"Amaaaandaaa…\""
    "The forest seemed to bow inward at the sound, as if the voice was not calling from outside, but from the earth itself. Janet's throat locked. She tried to scream, but her mouth only released the shriek of tires — endless, grinding, mechanical and inhuman."
    "Amanda turned her head at last. Slowly. Too slowly. When she faced Janet, her eyes were mirrors. Not eyes at all, but twin pools of dark glass, reflecting Janet's terrified face back at her."

    scene black with flash_red
    play sound sfx_thud
    "Glass shattered. The car dissolved. Her parents sat before her again, broken and ruined, blood dripping steadily onto their clothes. Their jaws hung loose, their bones bent wrong."
    "And then they moved."
    play sound sfx_heartbeat
    "A twitch. A spasm. A slow lift of the head. Their eyes opened — not with the dull glaze of death, but with something white and alien burning in the sockets. Their mouths opened together, growls spilling out, guttural and dragging, like rocks grinding deep underground."
    "The seatbelt cut into her ribs, digging deeper the harder she pulled. It wasn't holding her safe. It was binding her, pinning her in place for them to reach."
    "Her father's broken jaw cracked wider. Her mother's arms jerked forward, fingers spasming like claws. The air reeked of blood and soil, heavy as stone pressing her chest."
    "Janet thrashed, heart hammering, lungs clawing for breath. The car closed in, smaller and smaller, until she couldn't move at all."
    play sound sfx_thud
    "Then the door burst open."
    "Cold air knifed into her lungs, sirens split the night, and red-and-blue light pulsed against her vision. Paramedics swarmed her, voices sharp, hands pressing. She blinked, dazed, but her eyes locked on Amanda."
    "Amanda stood just beyond the chaos, wrapped in her own arms. Her face trembled with held-back tears — but she smiled. That smile."
    "At first it was fragile, protective. Then it stretched. Too wide. Too thin. Teeth gleamed too sharp beneath lips cracked with strain. The smile didn't comfort. It threatened."
    "The sirens pulsed faster. In each flash of red, Amanda's face looked soaked in blood. In each wash of blue, her skin went corpse-pale. The smile never broke. Her lips moved — not in Amanda's voice, but in something layered, a chorus of guttural growls."
    "\"Stay with me.\""
    "Janet's pulse spiked. She knew, with the same raw certainty as death itself, that if she took Amanda's hand — if she believed that smile — she would never wake again."
    "The sirens grew louder, unbearable. The flashing light stretched until it swallowed everything. And Janet screamed herself awake."

    scene bg village_lot_day with flash
    stop music fadeout 1.0
    play ambient sfx_wind fadein 3.0
    call place("Driftwood Bay — half past twelve")
    "Her chest heaved, breath shallow and ragged. The car was still. Parked."
    "She blinked fast, disoriented, until her vision cleared enough to take in the empty lot around them — cracked asphalt, weeds pushing through the seams, the silence of countryside that had long forgotten bustle."
    "Through the windshield she spotted Markus. He stood a few meters away, hands in his pockets, face tipped toward the pale afternoon sky as though the clouds were speaking only to him. The music inside the car had gone quiet."
    "For a fleeting second the stillness soothed her, made the nightmare feel distant, like fog receding. She cracked the door open and called softly."
    jn "Markus?"
    show markus neutral at center with dissolve
    "He turned immediately, that faint, reassuring smile on his lips."
    mk "Hey. You're awake. I didn't want to disturb you. You looked peaceful."
    "Gentle, almost apologetic. Janet leaned against the frame, forcing a smile."
    jn "Peaceful's not the word. Weird dream. Bad one. But it's gone now."
    "She wrinkled her nose in mock severity."
    jn "What I do need is a hug. That's your job, right?"
    "He chuckled under his breath, spreading his hands in surrender."
    mk "Of course."
    play sound sfx_beep
    "He took a step toward her, warmth in his face — but then his phone buzzed sharp in his pocket. He paused, grimaced with a fleeting sorry expression, and pulled it out."
    mk "Just a second."
    "Janet exhaled, half a laugh, and shrugged. Fine. She reached into her bag. Her own phone lit up with a glow that grounded her, and she thumbed a quick message to Amanda."
    note_voice "Arrived safe. Everything's fine. Don't worry."
    "The message lingered, undelivered. No signal."
    jn "Figures…"
    "A tiny frown creased her forehead. Maybe a call would push through if she tried. She tapped Amanda's number and held the phone up as she stepped out of the car. The air outside was cooler, carrying the resin-scent of pines, the long sigh of wind over the hills."
    mk "Signal's spotty here. It'll come back once we're closer to the square."
    "He slipped his phone back into his pocket. Hers stayed stubborn on No Service. She tried to laugh it off."
    jn "Guess we're really off the map."
    "He offered his hand. She took it, and together they walked from the cracked lot toward the narrow street that wound between the houses."
    hide markus with dissolve

    # ART-REQUEST: village_lane_day — the lane under a pale afternoon sky, every shutter closed, no one about
    scene bg village_lane_dusk with dissolve_slow
    play music m_greyvale fadein 2.0
    "At first glance the village looked postcard-simple: whitewashed walls dulled by sea-air, wooden shutters painted in flaking blues and greens, a string of laundry stiff in the wind. But the longer Janet stared, the more the details felt wrong."
    "The shutters were closed though daylight still lingered. Doors locked tight, curtains pulled — as if the whole place had agreed on an early curfew."
    "Their footsteps struck against the cobbles, unnervingly loud, echoing back at them with no competing sound. No chatter. No television hum. No radios through open windows."
    "Two figures sat beneath the crooked streetlamp ahead — old men in caps, faces leathery and expressionless, smoking pipes that had gone cold, gray ash long settled."
    "Neither blinked as Janet and Markus passed. Their eyes tracked her instead, heavy as weights across her shoulders. Markus squeezed her hand lightly, steering her on without comment."

    menu:
        "Nod to the woman sweeping her doorstep.":
            "Across the street a woman in black stood sweeping her doorstep, the broom scraping in slow, deliberate strokes. Janet managed a small nod."
            "The woman's gaze flicked up only long enough to acknowledge her, then dropped again, the sweeping never pausing. The strokes moved nothing, Janet noticed. The step was already clean."
        "Keep your eyes on Markus.":
            "She forced a smile up at him, but her eyes strayed anyway to the opposite side of the street, where a woman in black stood sweeping her doorstep in slow, deliberate strokes."
            "Janet managed a small nod. The woman's gaze flicked up only long enough to acknowledge her, then dropped again, the sweeping never pausing."

    "Her skin prickled. The silence felt like listening — as though every shuttered window had someone pressed behind it, waiting, watching."
    "They passed a tavern with chairs stacked and chained, a faded sign swinging gently in the wind. From within came a muffled clink — glass on glass — but the door was shut, the faintest seam of light visible beneath it."
    jn "Doesn't anyone go out here?"
    "Markus gave a soft chuckle."
    mk "Winters are quiet. You'll see. Summer's different."
    "The words did nothing to ease the weight in her chest. The air smelled faintly of salt and woodsmoke — but underneath, she thought, something metallic, something that tightened her throat. She pulled her phone out again. Still No Service."
    "The village road bent inward, drawing them between houses where the sea's breeze could no longer reach. The air thickened. With each step, Janet felt the uncanny quiet press closer, as if the place were exhaling around her, drawing her further in."

    jump ch07
