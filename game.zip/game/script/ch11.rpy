## Chapter 11 — "Wardens of Light"
## Source: docs/manuscript/ch07.txt l.3–233. Amanda POV throughout.
label ch11:
    call chapter_card(11, "A house with the bed made")

    scene bg garden_yard with fade_slow
    show fog
    show vignette
    play ambient sfx_wind fadein 2.0
    call place("Driftwood Bay — a garden behind a gate")

    "Amanda pressed herself against the garden wall, chest heaving, every breath a knife in her ribs. The real knife was still in her shoulder, radiating like fire, every movement a shock down the nerves of her arm."
    "A small garden, weeds through cracked flagstones. A stone path to a narrow house, shutters drawn, no light bleeding through. The mist curled low over the yard, but she saw no dogs. No movement."
    ath "Shelter. Somewhere to stop the bleeding before it finishes me."
    "The door was solid wood with an iron latch. Her gaze went to the side window, its glass dulled with dust. She picked a fist-sized stone from the path, steadied her shaking hand against her hip, and hurled it."
    play sound sfx_thud
    "The glass shattered with a sharp, crystalline scream. She glanced back into the mist. No sound followed. No voices."
    "She draped her coat over the jagged frame — the movement tore a cry from her throat, bitten down hard — and dragged herself through, one leg, then the other. Her boots crunched glass. She stood braced against the wall, gasping."

    scene bg empty_house_kitchen with dissolve
    show vignette
    stop ambient fadeout 1.5
    "The air inside was cold and stale, but stiller. The silence wrapped around her like a blanket, fragile and thin. Enough."
    "She flicked the phone's flashlight back on. A kitchen. Old, but not abandoned: chairs tucked in, utensils on hooks, pots lined up on the counter, a dish towel folded by the sink."
    "She froze, listening. Nothing."
    "She moved room by room, the knife handle jutting from her shoulder like a grotesque flag. A sitting area. A small hallway. A bedroom with the bed made, a quilt folded at the foot. All neat. All untouched. Empty."
    am "Thank God."
    "Her knees buckled. She slid down the wall to the floor, hand pressed to her shoulder, tears slipping hot down her cheeks."
    ath "Janet."
    "She forced her breath to steady and made the beam sweep the room again, slower, for anything useful. The cupboards. She hauled herself up by the counter and opened them one by one."
    "A jar of flour hardened to a lump. Chipped plates and a clay jug. Then a bottle of clear liquid, half full, with a cork stopper. She twisted it open and the smell hit her. Tsipouro. Harsh, local alcohol."
    ath "It will do."
    "A drawer by the stove: cloth strips, frayed but clean. Another: a paring knife, still sharp, and rust-speckled scissors. Stale bread in a tin, rock-hard. At the back of a cupboard, a handful of dried figs."

    menu:
        "Eat them. Now.":
            "Her hand closed on the figs and stopped halfway to her mouth."
            ath "Janet loves figs. She must be starving too. She comes first."
        "Pocket them. Janet loves figs.":
            ath "She must be starving too. I need to find her."
            "Mechanically she put the figs in her pocket, saving them for her sister. She comes first."

    "At the sink a ceramic pitcher held well water. She drank greedily. She didn't care if it was clean. It was life."
    "She set everything on the table: the tsipouro, the towels, the scissors, the bread. Her eyes landed on the knife still jutting from her shoulder. It had to come out."
    "Her hand hovered above the hilt, shaking. She bit her lip, braced her body against the chair, and wrapped her good hand around the handle."
    am "One… two…"

    scene black with fade
    play sound sfx_tinnitus
    "On three she yanked."
    "White-hot pain exploded through her. She screamed into her clenched teeth, strangled, almost animal, as the blade slid free with a sickening pull. Blood surged hot and thick down her chest. She almost blacked out."
    play sound sfx_thud
    "She slammed the knife onto the table, pressed a towel to the wound, pulled the cork with her teeth and poured. The alcohol hit the torn flesh like fire. She howled, clutching the table, the world spinning."
    "Her screams broke into sobs, then into ragged breaths."

    scene bg empty_house_kitchen with dissolve_slow
    show vignette
    call mature_show("shoulder_wound")
    "She wrapped a second towel tight around her shoulder, pulling until her fingers went white. The fabric soaked through almost at once, but the pressure slowed the bleeding."
    call mature_hide
    "When the dizziness ebbed she turned to the rest. The dog's scratches. Bruises along her ribs. Cuts across her palms from the glass. She soaked cloth in tsipouro and pressed it to each one."
    ath "Pain means I'm still alive."
    "She slumped into the chair and tore at the bread with her teeth. Each swallow was gravel. She ate one fig, the sweetness foreign and overwhelming after hours of blood and bile. One. The rest stayed in her pocket."
    "She drank until her stomach cramped. Her whole body throbbed. Her arm burned. But she was alive. Amanda pressed her forehead to the table and closed her eyes."

    scene black with dissolve_slow
    play music m_grief fadein 3.0
    "And then it hit her — a memory, unbidden but merciful, crashing through the pain."
    "The smell of lilies. The hollow toll of church bells. The coffin lowering into the ground, ropes creaking under its weight."
    "Janet had been beside her, sobbing so hard her small body shook. Amanda, fourteen, had gripped her sister's hand, fragile and clammy, as if it might slip away if she let go."
    "She had knelt and turned Janet's tear-streaked face toward her. \"Hey. Look at me.\" Janet's eyes had lifted, broken, pleading. Amanda had squeezed her hand tighter, her voice steady."
    "\"Don't worry. You have me.\""
    $ note("Don't worry. You have me.")
    "The memory flashed forward. Janet smiling through tears, years later. Scraped knees patched. Standing guard in the chaos of another foster home. Cooking late so Janet could have something warm after school."
    "Protecting. Providing. Always. No one had come for them then. No one had stepped in to carry the weight. Amanda had done it, because she had to. Because she promised."

    scene bg empty_house_kitchen with dissolve_slow
    show vignette
    stop music fadeout 3.0
    "Her eyes opened, hard, burning through the blur of exhaustion."
    ath "No one is coming for me now. No one is going to help. I did this. Alone. And I'll keep doing it. Until I find her."
    "Every muscle screamed for rest. She knew the truth as surely as her own heartbeat: if she stopped now, she might not rise again. She wiped her mouth, set her jaw, pushed herself from the table and staggered toward the door."
    "Her hand brushed the wall for balance. The beam of her light caught on something in the corner of the room. She froze."

    scene bg empty_house_seal with dissolve
    show vignette
    "A square of cloth, yellowed with age, pinned neatly to the plaster. Ceremonial, not decorative. Carefully placed. Reverent in its stillness."
    "On it, a symbol. A circle in thick black ink. Inside it a star of interlocking triangles, old and crooked. At its center a twisted staff coiled by two serpents, ending not in a spearhead but in a heavy iron key."
    "Around the border, Greek letters circled endlessly, bold and jagged."
    play sound sting_word
    note_voice "ΚΛΕΙΣ ΕΚΑΤΗΣ ΦΥΛΑΞ"
    "Key of Hecate, Guard. And bound at the four quarters, the names of the Archangels, set there as wardens."
    $ note("ΚΛΕΙΣ ΕΚΑΤΗΣ ΦΥΛΑΞ — Key of Hecate, Guard. Serpents, a key, four angels. Pinned to the wall of an empty house.")
    "Amanda stepped closer. The snakes seemed almost alive in the pale glow, mouths open, fangs bared, watching her. She didn't understand it, but she felt its weight. A symbol of faith, or fear. Something meant to protect, or to warn."
    ath "There was no mark like this in the tavern."
    ath "Is this whole village under the same banner? A cult playing at a community? Do they worship that thing in the mist? Or are they trying to keep it away — bind it, cage it?"
    "The memory of its grin flashed through her. Hollow eyes glowing, teeth stretched too wide. She shivered."

    menu:
        "Tear it down.":
            "Her bloodied hand went to the pin and stopped there. Whatever this was, it had held for longer than she had been alive, and she did not know what it held. She let it go."
        "Leave it where it is.":
            "She kept her hands off it. Whatever it held, or held back, she would not be the one to find out tonight."

    ath "No. Whatever this is, it isn't enough."
    ath "If this village worships monsters… if this symbol is their shield… then Janet is in more danger than I imagined."
    "Amanda gripped the doorframe with her bloodied hand, pulled the door open, and stepped back into the mist."

    scene bg village_lane_fog with fade
    show fog
    show vignette
    play music m_judgment fadein 3.0
    play ambient sfx_wind fadein 2.0
    "The cold wrapped tighter around her. For a moment her heart lurched, expecting the same suffocating wall of white. But something was different. The fog here was thinner."
    "She turned toward the street she had come from. The creature's direction. Even at a distance the haze still roiled there like a storm, coiling around the stones and houses as if it belonged to them."
    ath "It isn't the village. It isn't the weather. It's that thing. The mist was spilling out of its body, poisoning everything around it. What I saw was real."
    "Opposite the creature's path the air was clearer. Rooftops. Trees. Streets that finally had edges. She turned and walked, and the further she went the lighter the mist became, peeling back like smoke in wind. Not safe. But she could breathe."
    play sound sfx_beep
    "Her phone buzzed in her palm. Low battery. A thin red line."
    am "Of course."
    "A cloudy night. A village with no lights. If the phone died she would be blind. Blind and bleeding in a place that had already tried to devour her more than once. No stars. No moon. A ceiling of heavy, swollen clouds."
    am "Not now. Not yet."
    "She pressed on, boots sharp against the cobblestones. Minutes dragged. Shuttered houses, dark windows, silent gardens. Empty. Lifeless. And then the road widened."

    scene bg village_square_fog with dissolve
    show fog
    show vignette
    "Her light swept a small square. Thin trees and benches emerged through the thinning mist, damp leaves scattered across the earth. The center of the village. Something she could recognize."
    "But fragile: benches empty, trees skeletal, no cars, no people. Only wind in the branches and the heavy smell of woodsmoke from unseen fireplaces."
    "She pressed her good hand to the rough bark of a tree and leaned her forehead there. Just a second. Just a breath."
    with flash
    "The sky split open. Lightning tore across the heavens, blinding white — every bench, every wall, every tree outlined in electric fire."
    play sound sfx_thud
    "The thunder followed a heartbeat later, cracking so violently it rattled her chest."

    scene bg village_square_storm with dissolve_fast
    show rain
    show vignette
    play ambient sfx_storm fadein 1.0
    "Rain began to fall, hesitant at first, fat drops on leaves, on her face, cooling the sweat and blood on her skin. She blinked through the wet blur of the park."
    "Movement."
    show markus neutral at far_right, dimmed with dissolve
    "On the far side of the square someone was walking. A lone figure, steady and deliberate, unhurried, the rain streaking his silhouette. Something in the posture, the stride. Familiar. Too familiar."
    "Her body moved before her mind caught up. She left the tree, crouching low, slipping along the edge of the path. The rain masked her steps, the storm covered her breathing."
    ath "It could be him. Markus."
    "The name clawed at her throat. She wanted to shout, to run to him. Fear rooted her. She had to be sure. Inch by inch she drew closer, the rain in sheets now, her phone's light pressed dimmed against her side."
    "The way he carried his shoulders. The length of his stride. Yes. It was Markus."
    "She gripped the sharp stone so hard it bit through her blood-slicked palm. The pain grounded her. She stayed low, weaving between trees and benches."
    ath "He's mine."
    "The man reached a garden gate. The latch clicked. He climbed a short flight of stone steps, pulled a key from his coat, and the door creaked open."
    hide markus with dissolve
    am "Fuck!"
    "A few steps more and she could have had him before he slipped inside."

    scene bg markus_house_ext with dissolve
    show rain
    show vignette
    call place("Markus's house — the storm")
    "The door shut, muffling the rain. Her hand clenched tighter around the stone. She forced herself through the gate and toward the slick stone steps. This was it."
    play sound sfx_thud
    "As she set her foot on the first step, her body betrayed her. Her knees buckled. She collapsed forward, palms scraping wet stone. The rock slipped from her grip and rolled into the dark grass."
    am "No… no, not now—"

    menu:
        "Get up. Now.":
            "She tried. Her arms quivered uselessly beneath her, her legs hollow, emptied of strength. The pain in her shoulder surged hot and electric. She did not get up."
        "Stay down. Hide.":
            "Her legs were hollow, emptied of strength. The pain in her shoulder surged hot and electric. There was nothing to decide. Her body had decided."

    "Panic set in fast. The garden was too open, too exposed. If Markus looked out, if anyone saw her sprawled there, she was finished."
    "She dragged herself sideways into the wet grass, mud smearing her arms, a wounded animal trying to vanish into shadow, until she reached the overgrown bushes by the wall and collapsed into them."
    "She forced her face into the crook of her elbow to muffle her breathing. Every sound was magnified: the rain on the tiles, the thunder, the faint hum of light inside the house."
    "Somewhere inside, a floorboard creaked. Amanda froze. Markus was in there, just beyond the wall, in the glow of that lamplight. So close she could almost hear him moving."
    "The minutes stretched into something unmeasurable. The adrenaline left; the cold took its place, a bone-deep chill through her soaked clothes. Her teeth chattered and she smothered the sound against her sleeve."
    "Her eyelids grew heavy. Each shiver drained more of her will, until the thought of letting the rain wash her into nothing didn't feel so terrible."
    "But then — the sound of a latch. A door opening."

    scene cg hidden_rain with dissolve_slow
    window hide
    pause 2.0
    window auto
    "Through the dripping leaves she saw the front door swing inward, spilling a sliver of warm light into the rain. Markus stepped out."
    "Tall, broad-shouldered, moving with purpose, his coat pulled tight, head lowered against the storm. His stride was quick. Almost urgent."
    "He locked the door behind him with a sharp turn of the key and slipped it into his pocket without hesitation, as though nothing in the world could touch him."
    "Amanda bit the inside of her cheek until she tasted blood. Every nerve screamed to rise, to lunge, to end this. Her body would not obey. All she could do was watch."
    "He strode down the steps, out through the gate, and the rain swallowed him. His figure blurred into the storm until only the echo of his steps remained."
    ath "He was right there. I could have reached him. I could have—"
    ath "No. Not yet."
    "She stayed still, shivering violently, until the last of his footsteps disappeared into the night."

    scene bg markus_house_ext with dissolve
    show rain
    show vignette
    "When they were gone she forced herself to move. Her limbs were wet sand. She dragged herself from the bushes to the door and closed a trembling hand around the handle. Locked."
    am "Of course."
    "She pressed her forehead to the wood. She couldn't just wait. Markus had left for a reason, and she might never get another chance."
    "The windows were sealed behind thick wooden shutters, the kind her grandmother's house once had. She tested one. Solid. Another. The wood groaned but held. At the third, the wood was soft, swollen with weather, the hinges rusted."
    "A small shed by the wall. The door stuck, then jerked open with a squeal. Damp and rust. Old tools, most useless with age. Near the back, under a coil of wire, a small pick with a dull but intact head."
    "She set it against the rotted hinge and pushed. It slipped, scraping wood, jolting her bad shoulder. She bit her lip until it split. She tried again, leaning her whole weight into it."
    am "Come on… come on…"
    play sound sfx_thud
    "The hinge groaned, then snapped with a brittle crack. The second gave quicker. With one last shove the shutter sagged open and slapped back against the wall. She froze, listening. Nothing but the storm."
    "She struck the glass with the tool. A shallow star. Again, harder. The pane cracked and fell inward. The hole was just big enough. Jacket over the jagged edge, teeth gritted, she hauled herself through and dropped to the floor inside."
    "She was in."

    scene bg markus_living with dissolve
    show vignette
    stop music fadeout 2.0
    "Damp wood and old smoke, the smell of a place where windows were rarely opened. She crouched, ears straining. Only rain on the shutters and the low groan of the storm. No footsteps. No voices."
    "Small, almost austere. A single armchair. A bare wooden table with a stack of folded newspapers. A handful of books on shelves, arranged neatly, almost obsessively straight. Old furniture, well kept. Functional."
    ath "The order is too rigid. Nothing casual. Nothing lived-in. As if he built a place to rest, but not to live."
    with flash
    "Lightning struck, and the far wall showed her what was carved into the plaster. Circles intertwined, lines and spirals etched deep. At its heart a crude hexagram, warped at the tips. The cloth in that empty house. The same lines. The same weight."
    ath "Markus isn't just part of this. He believes in it. He carried it here, inside his home."
    "Her stomach lurched, hollow and sharp. Something faintly sweet pulled her toward the small kitchen."

    scene bg markus_kitchen with dissolve
    show vignette
    "Plain, tidy to the point of sterility. On the counter a small bowl of fruit: dull-skinned apples, two oranges speckled with age. She grabbed an apple and bit. The juice nearly made her moan."
    "She ate to the core, then tore the peel from an orange, juice running sticky between her fingers. It wasn't enough, but it was something. Something human in this nightmare."
    "A knife block beside the sink. She pulled one free — small, but sharp — and slid it into her waistband under her coat. Food in her stomach. A weapon at her side. And on the desk in the other room, something she had seen on the way in."

    scene bg markus_living with dissolve
    show vignette
    play music m_nineteen fadein 3.0
    "A book. Its cover cracked leather, its spine worn, its pages yellowed with age. She reached out."
    ath "What the hell have I stumbled into?"
    "The binding cracked like brittle bone when she opened it. Dust scattered, carrying a smell so old it made her gag: mildew, smoke, and beneath it something coppery, like dried blood."
    "The first page was inked in Latin and Greek, its heading in large, ornate letters."
    play sound sting_word
    note_voice "Custodes Lucis. Wardens of Light."
    $ note("Custodes Lucis. Wardens of Light. The book on Markus's desk.")
    "Amanda whispered it aloud. The name felt dragged from another century. Lines in many hands, layered across ages, bound by the same fevered devotion. The words told not of a village, but of a covenant."
    "It began in the 1400s. A man calling himself Aenean Salvatorem — the Fallen Savior. Tall, pale, eyes like glass. He had carried a sack into their square. Two dozen severed heads spilled across the dirt. Not their own, but their enemies'."
    "He declared himself protector, light, savior. At first, prayers. Then animals. Then humans."
    "The book described it without shame: sacrifices rewarded by fertile fields and peace. But the savior was flawed. He did not age, yet sickness gnawed his body until it killed him. He died with instructions, his promise written in blood."
    note_voice "I will return through you."
    $ note("I will return through you. From his grave, a tree grew.")
    "From his grave, a tree grew."
    "The entries after became frenzied. The Sacred Tree. The Fruit of Light. Each decade one fruit. Each time a vessel — beaten, starved, forced to consume it."
    "Some died instantly. Others twisted into shapes unholy: jaws splitting, bones stretching, voices shrieking. Survivors were hailed as miracles, proof His flame had entered them. Every failure was devotion."
    note_voice "Each vessel brings Him nearer. Each offering feeds the roots."
    "Amanda snapped it shut, clutching it to her chest as though it might vanish. Answers. Proof. Janet was tied to all of this. But her hand betrayed her. She needed to know. For Janet."

    scene cg custodes_lucis with dissolve_slow
    window hide
    pause 2.0
    window auto
    "Later pages held drawings. A body sketched tall and wasted, skin translucent, every vein exposed. Notes crowded the margins in Greek, Latin, German. Anatomy — but not human."
    note_voice "Cutis tenuis — thin skin. Veins exposed. Pulmones alteri — auxiliary lungs. Poison breath."
    "And in a shaky script beneath:"
    note_voice "The mist is Him."
    "Her throat tightened. The fog. Janet's cries distorted. The weight in her chest. More sketches: a jaw unhinged too wide, jagged teeth. Hands with clawed fingers."
    note_voice "Glows faint with divine blood. Sees best in dark. Strength in jaws, forearms. Rest wasted, fragile but lethal."
    ath "It isn't a monster. It's a failure."
    "The fruit had meant a god reborn. Instead it spawned half-things, unstable and ravenous. Cannibals. Hunters. Mimics."
    note_voice "It repeats voices. It wears faces. Not illusion but memory — what it sees, it keeps."
    "The whimpering figure in the mist. Janet's voice breaking. The face unraveling. Not hallucination. The creature. A final drawing: a black, tumor-like organ."
    note_voice "Cor Nigrum — the Black Organ. Source of mimicry, transformation, poison. Eats the host alive."
    "Amanda gagged, hand to mouth. The notes grew darker. These creatures were no accidents. They were the pattern. Most died. Some fled. Some still roamed."
    "The village was not a sanctuary. It was a cage."
    $ note("The village was not a sanctuary. It was a cage.")
    "Janet wasn't missing. She was in the hands of people who had fed girls like her into this nightmare for centuries. She pressed her forehead to the cracked leather, breath ragged. The final section stopped her cold."
    "A circle, complex, twisting, alive with shifting lines. Beneath it:"
    play sound sting_word
    note_voice "Το Κλειδί της Εκάτης. The Key of Hecate."
    "Hecate, goddess of crossroads and gates, opener and closer. The cult had twisted her key into something darker."
    "At the center, serpents knotted into a loop. Around them a hexagram, its points warped like hooks. The outer ring inscribed in Greek: ΚΛΕΙΣ ΕΚΑΤΗΣ ΦΥΛΑΞ — Key of Hecate, Guard. And at the edges, names. Michael. Uriel. Raphael. Gabriel. Angels bound as wardens."
    "Beneath, a trembling hand had written:"
    play sound sting_word
    note_voice "Hecate opens. The Seal locks. The angels guard. The vessel is bound until His return."
    $ note("Hecate opens. The Seal locks. The angels guard. The vessel is bound until His return.")
    ath "This isn't superstition. It's a lock. A gate. A warning."
    "Somewhere in this village they had carved it on stone, on doors, on altars. Not to keep outsiders away. To keep something in."
    ath "Janet. If they mean to use her, they won't do it in some hidden shack. It will be the church. The heart of the village."

    scene bg markus_living with dissolve
    show vignette
    play sound sfx_thud
    "Thunder cracked overhead and rolled through the small house like cannon fire. In the same moment her phone buzzed against the table."
    play sound sfx_beep
    "She snatched it up in both hands. The screen flashed red for a moment and went black. The battery was spent. The last thread tying her to the outside world had gone silent."
    "The lights flickered, buzzing weakly as the storm battered the lines. Once, twice. Then steadied, dimmer than before."
    "Her wet clothes clung like ice. Her eyelids were slower with each blink. If she stayed, if she let herself stop, she would not get up again."
    stop music fadeout 2.0
    "Amanda pushed herself upright. She pulled her coat tight and shoved the book into her bag. Her hand brushed the knife at her side. A sliver of steel. Small. Enough."
    "At the door she pressed her palm to the handle, closed her eyes for a heartbeat, and exhaled. Then she stepped outside."

    scene bg village_lane_storm with fade
    show rain
    show vignette
    play music m_square fadein 2.0
    "The rain hit her like a wall. The storm swallowed her at once, deafening, blinding, and pushing her forward."
    with flash
    "She lifted her chin, teeth clenched, and let the lightning guide her eyes toward the looming silhouette she knew would be there. The church."
    "Amanda set her shoulders, ignoring the ache, the cold, the fatigue dragging at her body. She started walking."

    jump ch12
