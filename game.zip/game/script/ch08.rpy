## Chapter 8 — "Nothing Good Down This Road"
## Source: docs/manuscript/ch05.txt l.60–229 (Amanda POV). Rulings #10 (dusk on the cliff road,
## full dark in the village).
## Beats: 18 the smashed phone (STANDARD, CG smashed_phone) · 19 the dogs (STANDARD, lane_fence_dog) ·
## 20 the pit bull (STANDARD before and after; BLACK FRAME + SOUND for the bite and the beating;
## MATURE SLOT dog_bite on the aftermath only) · 21 the belt (STANDARD, CG the_belt).
## CHILD rule: the road girl is a staring child in a cotton dress, nowhere near any violence.

label ch08:
    call chapter_card(8, "The coast road — dusk")

    ## the valley
    scene bg burned_hills_road with fade_slow
    play ambient2 sfx_engine fadein 2.0
    play music m_snow_road fadein 2.0
    call place("The coast road — three hours out")
    "The kilometers slipped by under her wheels, the daylight bleeding steadily toward dusk. The sun hung low, a pale orange disk pressing against a bank of clouds, streaking the hillsides in uneven washes of gold and shadow."
    "The highway had emptied long ago, until hers was the only car moving through the valley. The trees rose taller with each turn, closing in. Hills jutted up in jagged lines, like the broken teeth of some ancient beast."
    ath "Almost there. Keep the pace."

    scene bg amanda_car_dusk with dissolve
    play sound sfx_static
    "The radio crackled. Interference from a passing car, she thought — but there were no other cars. The static rose in uneven bursts, drowning the soft music she'd left on for company."
    "She twisted the dial. The static only deepened, a thin shriek under the noise, before collapsing into silence. She snapped the radio off. The quiet was worse."

    menu:
        "Try Janet again.":
            "She grabbed the phone from the passenger seat. Janet: straight to voicemail. She hung up before the beep and tried Markus. Voicemail."
            "Once more — and no service at all. She dialed again anyway, once, twice, until the lack of signal became undeniable. Each failed attempt scraped at her nerves. She kept her breathing steady."
        "Don't. Both hands on the wheel.":
            "She left the phone where it lay on the passenger seat, screen dark, and set both hands against the wheel. There would be no bars out here. She knew it. She wanted to try anyway, and didn't."

    ath "Dead zones. Old roads. Nothing unusual."
    ath "Janet is fine. Markus is with her. This isn't the first time reception has failed me, and it won't be the last. Don't invent shadows where there are none."
    "The road narrowed, twisting along the edge of the forest. Shadows pooled between the trees. The clouds thickened, dimming the last streaks of daylight until the sky turned a dull, heavy gray."
    ath "I'll see her. I'll tell her off for letting her phone die. She'll smile like she always does, and that will be the end of it."
    "Her stomach stayed knotted, but her grip on the wheel never faltered."

    ## the cliff road
    scene bg cliff_road_dusk with dissolve_slow
    play ambient sfx_wind fadein 3.0
    "The last stretch tightened into a single lane, the white divider lines vanishing until there was nothing but cracked asphalt squeezed between the land and the sea. She eased off the gas."
    "On her left the hill rose steep and unforgiving, its face scarred by dark streaks where past rains had dragged soil and stone across the road. Her headlights caught boulders the size of her chest shoved haphazardly against the guardrail."
    "To her right, no such safety. The land dropped away in a sharp cliff, straight into the restless sea. One wrong turn of the wheel and the car would be nothing more than another offering to the waves."
    "The sun was little more than a dull ember pressed against the horizon. No other headlights ahead or behind. She was alone here, suspended between hill and sea, in a stretch of road that felt cut from the world."
    "The phone lay on the passenger seat, screen dead. Janet's silence pressed harder now, sharpened by this remoteness. The city was not far behind her, and yet it might as well have been a continent away."
    play sound sfx_static
    "A gust rattled the car, and for a second the radio hissed — that thin static breaking through, like some ghost signal rising out of the cliffs. She clicked it off, throat dry. Eyes forward."
    "The light was fading fast, a bruised orange pressed thin behind a ceiling of gray. Her headlights threw long cones down the asphalt, catching nothing but trees, rocks, the occasional glimmer of sea."
    "That was why the figures stood out so sharply."
    stop music fadeout 2.0
    play music m_judgment fadein 3.0
    show oldman grin at midleft with dissolve
    show girl stare at left with dissolve
    "A man. Thin, stooped a little, one hand raised. In the other, a dented metal gas can swung against his leg. At his side, small as a shadow, a girl held his sleeve — head bowed, hair dark and stringy against the pale of her dress."
    ath "Out here? On this stretch of road? It doesn't make sense."

    menu:
        "Keep driving. No time.":
            "Her first instinct, and she meant to follow it. But as the car drew closer her eyes locked on the girl — the slight frame, the way she clung silently to the man's coat — and Amanda found her foot easing off the accelerator anyway."
        "Slow down. There's a child.":
            "Her gut had already knotted at the sight of them. But the girl — the slight frame, the way she clung silently to the man's coat — made the decision before Amanda did. Her foot eased off the accelerator."

    "She pulled toward the edge, gravel crunching beneath her tires, and lowered the window a crack. Her voice came sharper than she intended."
    am "I'm in a hurry. What do you need?"
    "The man stepped into her headlights. About seventy, maybe older, skin creased and spotted with age, gray stubble on the jaw, the top of his head shining where the hair had long since thinned away."
    "His coat was long and heavy, its cuffs darkened by old stains that rain alone couldn't have made. His mouth stretched into an oddly firm grin that didn't reach the washed-out gray of his eyes."
    om "Just a lift, if you'd be so kind. Our car ran out of petrol, and the little one's tired. The station's a good few kilometers behind us."
    "Warm, polite — but something practiced in the way he shaped the words, like a phrase recited often."
    "The girl was maybe eight or nine, though the thinness of her arms and legs made her seem younger. A pale cotton dress patterned faintly with flowers, more suited to summer than the chill creeping through the dusk. Both hands gripped his sleeve; her face stayed hidden."
    ath "If it were just him, I'd hit the gas without a second thought. But the girl…"
    am "Fine. Get in. But make it quick."
    "The man's smile broadened."
    om "Much obliged."
    hide oldman with dissolve
    hide girl with dissolve

    scene bg amanda_car_dusk with dissolve
    "He opened the rear door with a deliberate motion, set the gas can on the floor, and lowered himself onto the seat with surprising steadiness for his age. His coat slumped against the upholstery, carrying the faint smell of metal and something sour beneath it."
    "The girl climbed in next, quiet as air, and folded her hands neatly in her lap. She still hadn't looked at Amanda. Strands of wet hair curtained her face."
    "When the door clicked shut, silence filled the car. Outside, twilight deepened another shade, the first true darkness of night gathering in the trees and on the sea."
    am "Seatbelts."
    "Neither moved. The man only leaned back, his pale eyes catching hers in the mirror, and gave a small nod of thanks."
    "The car rolled back into motion, gravel spitting from the tires. No one spoke."
    "The man sat with his shoulders squared, hands folded atop the gas can between his boots. The grin had not faded. It wasn't wide, not grotesque, but it stayed, fixed at the corners of his mouth as though time itself couldn't wear it down."
    "The girl was another matter."
    show girl stare at center with dissolve_slow
    "Amanda checked the mirror once, twice, and found those eyes locked on her each time. Wide, unblinking, a child's face tilted just enough that the dark hair slipped aside and left her gaze unobstructed. Not the road. Not the man beside her. Only Amanda."
    "It made her chest constrict. She gripped the wheel tighter and kept her eyes forward. The road dipped and wound along the cliffside, and still she felt it: the girl's gaze, steady, measuring, as though Amanda were the strange one here."
    "The engine hummed. Once the gas can clinked against the floor as the car jolted through a pothole; the man didn't flinch. The grin held. The stare never broke."
    "The air in the car smelled of wet wool and something metallic — the gas can, maybe. Maybe not. The scent clung to her tongue."
    "Another glance in the mirror — she told herself not to, and her eyes disobeyed. The girl's head had shifted closer, chin tilted down, eyes still fixed on her. As if the longer she looked, the less human Amanda became."
    hide girl with dissolve
    "Her heartbeat thudded in her wrists where they pressed the wheel. She thought of saying something — how far, the girl's name, anything to break the stillness — but the words stuck."
    ath "Silence is safer."
    "The kilometers crawled. The forest thickened, the sky bruised darker, and soon even the faint glow of sunset was gone, leaving only her headlights cutting the road ahead."

    scene bg roadside_truck with dissolve
    show vignette
    "Then, at last, the beams caught a shape on the shoulder. An old truck. Rust crept up its sides in streaks, the paint faded to an uncertain gray-green. The hood sat slightly ajar, its edges pitted and scarred as though pried open too many times."
    om "That's us."
    "As polite and even as before. She eased the car to a stop beside it and didn't turn her head. Didn't look at them. Only waited for the door latch to click."
    "The man's hand hovered on the handle a moment longer than necessary. Then, slowly, he turned his head. She felt it before she saw it — the pull of his gaze — and against her better judgment her eyes flicked sideways."
    show oldman grin at center with dissolve
    "Their eyes met. His grin deepened, faint crow's-feet tightening at the corners, but it was still a smile that didn't reach the eyes. The kind of smile one wears at a funeral."
    om "You'd best turn around now. U-turn and head back. Nothing good's waiting for you down this road."
    "For a heartbeat Amanda forgot to breathe. The words were simple, spoken almost like neighborly advice about a storm — yet the tone carried a certainty that made her skin prickle."
    $ note("Nothing good's waiting for you down this road.")
    "He dipped his head, as though in farewell, and slipped out into the night, closing the door with a soft, final click."
    hide oldman with dissolve
    "Her knuckles ached on the wheel. Through the windshield she saw him take the girl's hand. Together they walked toward the old truck waiting in the dark."
    "Even at a distance his grin lingered — too fixed, too knowing, as if it had been carved into him long before this moment. The girl didn't look back. She didn't need to. Amanda still felt those unblinking eyes, etched into her like afterimages."

    scene bg cliff_road_night with dissolve
    show vignette
    "The road ahead stretched empty, waiting. To one side the sea hissed against the cliff; to the other the forest leaned close, its shadows crowding the edge of her headlights."
    "The engine ticked softly in the silence. She drew a breath, steady, decisive."
    ath "Warnings from strangers mean nothing."
    "She pressed on."

    ## the village
    scene bg village_view_night with dissolve_slow
    show vignette
    "At last the hill gave way, the cliff retreating. The road widened, spilling her out of its narrow grip. Just ahead, lights appeared, faint and flickering: windows glowing from stone houses, a single streetlamp swaying in the wind."
    "Driftwood Bay."
    "She exhaled shakily, though her chest didn't loosen. The village looked small, quiet, almost too still — a pocket of life pressed between land and sea. Had Janet seen this same view earlier in the day? Had her car traced these same curves?"

    scene bg village_lot_night with dissolve
    show vignette
    stop ambient2 fadeout 1.0
    stop music fadeout 2.0
    "The village opened before her almost abruptly, as though the narrow road had coughed her into a different world. Its \"center\" was a broad, uneven square ringed by low stone buildings; the single street that fed it ended at a cracked and pitted parking lot."
    "She pulled in and cut the engine. The silence that followed was unnatural. No cars. No footsteps. No voices. Only one old agricultural truck, its body rusting, its wheels long gone, slumped like a carcass in the corner of the lot."
    "She stepped out, the door shutting too loud in the stillness. Salt and damp stone. She tried Janet once more; the call failed before it could even connect."
    am "Damn it."
    "Pacing, she tilted the phone upward, as if the sky might gift her a bar of service. Her eyes flicked down again — and froze."
    "A few meters away, something small lay against the gravel. Cracked. Smashed."

    scene cg smashed_phone with dissolve_slow
    window hide
    pause 2.0
    window auto
    play music m_grief fadein 2.0
    "Her legs moved before her mind caught up. She crouched and reached for it. The frame of a phone, its glass spiderwebbed, the back split where it had been crushed under weight."
    am "Please, no…"
    "She pressed the power button. Nothing. Dead. Her fingers trembled at the side slot — the memory card was intact. With a practiced motion she slid it free, fished out her own phone, and slotted it in."
    "Seconds. Then her screen lit with a cascade of images: selfies, café tables, blurry nights out. And there, clear as day, her sister's face. Janet, smiling, laughing, alive."
    "Her vision blurred. Her chest convulsed with a sob she didn't let escape — grief and fear and fury crashing through her all at once. She pressed a fist against her mouth and breathed through it."
    "It was Janet's. There was no doubt now."
    $ note("Janet's phone — smashed in the lot. Her photos on the card.")
    "She closed her eyes and forced the tears back. No time. No luxury for collapse. She tapped the screen, searching for a clue, a message — but the signal icon mocked her, a hollow X."
    "She dialed the emergency number anyway, hands shaking so violently she almost missed the digits. The call failed instantly. No service."

    scene bg village_lot_night with dissolve
    show vignette
    "The silence pressed in thicker, like the whole village was holding its breath."
    ath "What do I do?"
    "She could leave. Drive back toward the city, try again once she cleared the hills. But even if she reached the police, even if they sent someone immediately — it would take hours. Three, maybe four. Hours Janet might not have."
    am "No. I can't wait."
    "She tucked the broken device into her coat pocket, wiped her face hard with both palms, and drew in a shuddering breath. Her legs still trembled, but beneath the panic something sharper took root: resolve."
    ath "If Janet is here, I'll find her."
    "The stone houses stood watching, shutters closed, windows faintly glowing. Somewhere behind those walls, someone knew something. She would not turn back."

    ## the dogs
    scene bg village_square_night with dissolve
    show vignette
    stop music fadeout 2.0
    play music m_judgment fadein 2.0
    "She crossed the square, her steps echoing too loudly in the emptiness. Old stone, wooden shutters closed tight, slivers of light through the cracks — proof of life inside. Yet the village gave nothing back."
    scene bg lane_fence_dog with dissolve
    show vignette
    "The first house: a small garden fenced by iron bars streaked with rust. A dog erupted before she even reached the gate — a big shepherd, teeth bared, barking so furiously the metal rattled. She flinched and forced herself closer."
    am "Hello?"
    "Her voice carried thin against the animal's roar. She knocked against the gate."
    am "Please, I need help! My sister—"
    "The barking drowned her out. No movement inside. No footsteps. No voice calling back. Just the dog lunging against its chain, foam flecking its muzzle."
    "The next house. Another fence, another dog — smaller but shrill, snapping at the bars. Light burned behind shuttered windows. No one answered."
    "A third house. A fourth. Each the same. Dogs howled until her ears rang, until her own words seemed swallowed whole."
    am "Is anyone there? Please, I need help! My sister is missing!"
    "Only the dogs replied. She pressed her hands against the bars of the nearest fence, the animal inside snarling inches away. Behind it, a curtain shifted in a lit window — just slightly, as though someone had looked out."
    am "Hey! I see you! Please—"
    "The curtain fell back. Silence, except for the dog. Her hands fell uselessly to her sides; her own pleas seemed ridiculous now, swallowed by indifference."
    $ note("Driftwood Bay: a dog at every gate. They heard me. They chose not to answer.")

    scene bg village_square_night with dissolve
    show vignette
    "She stumbled back into the square, the barking still echoing off the stone. One by one the houses seemed to close in, their silence deliberate, suffocating. They heard her. They all heard her. And they chose to do nothing."
    "Her knees weakened. She pressed her hand hard against her mouth, forcing down the sob clawing up her throat."
    ath "No. Don't break. Don't give them that."
    "She dragged in a breath sharp enough it hurt and spun on her heel, scanning the square for an opening, a sign of where to go. If no one would help her, she would help herself."
    am "Fine. Fine. I'll find her myself."
    "Janet was here. Somewhere. And Amanda would tear this place apart until she found her."

    ## the beach
    scene bg beach_night with dissolve_slow
    show vignette
    stop music fadeout 3.0
    play ambient sfx_wind fadein 2.0
    "Her feet carried her down the slope away from the square, past shuttered houses and crumbling stone steps. The air grew colder, the tang of salt thickening with each stride, her breath rising in short clouds. Almost at a run now."
    "The sound reached her first — the dull, rhythmic crash of waves against rock. The street thinned into a path, uneven and slick, toward a faint gleam of silver ahead."
    "The beach opened abruptly beneath her: a wide, desolate stretch pressed between black cliffs. Clouds rolled thick above, swallowing the moon. Only a faint glow lingered where the waves collapsed against the shore."
    "Her shoes sank into the damp sand. Brine, rot, and something faintly metallic, like iron left too long in the rain. To her right, the skeletal remains of old wooden shacks leaned crookedly, windows shattered, doors hanging loose — broken teeth against the dark."
    am "Janet!"
    "Her voice tore into the wind, thin, quickly devoured. No answer. Only the endless hiss of the sea."
    "Her phone's flashlight cut a narrow beam through the gloom: warped planks, heaps of seaweed, the quick scurry of something small. She swept the light wider — sand, cliffs, water. Every flicker only made the darkness beyond it thicker."
    "The beach was empty. But the emptiness itself felt wrong. Her skin prickled, as if unseen eyes were on her from the cliffs above, from the black mouths of the shacks."
    ath "I should turn back. Regroup. Not now."
    am "Janet!"
    "The sea answered. Nothing else."
    "If Janet was anywhere near, if she'd been brought here, there had to be something. A trace. She stepped further into the dark, toward the stretch of sand that vanished beneath the shadow of the cliffs."
    play sound sfx_thud
    "The crash of the waves nearly drowned it out — but Amanda froze when she heard it. A metallic groan, sharp and unnatural against the roar of the sea. Somewhere ahead, hidden in the darkness, a door scraped open."
    "Then came the voice. Old, rasping, cutting through the night like a knife."
    bv "Go get her, boy. Tear this bitch apart."
    "Her stomach lurched. She spun toward the sound, but before her eyes could adjust, the patter of rapid steps broke into the sand. Heavy. Animal. A growl rolled closer, deeper, more feral with every stride."
    am "No—"
    play music m_route_nine fadein 0.5
    "The dog erupted from the shadows — muscle and fury, a pit bull, its eyes reflecting the meager beam of her phone like coins of fire. It charged with terrifying speed, sand spraying in its wake, growl building into a snarl."
    "She turned and ran. The wet sand dragged at her shoes, each step swallowed by the sucking ground. Waves exploded against black rock, spray hitting her face. To her right, the dog thundered closer."
    "Her lungs burned. She could hear it gaining. Nowhere to go — only the endless beach, the hiss of waves, the darkness ahead."

    scene black with flash_red
    show vignette red
    play sound sfx_thud
    "The impact came like a car crash. The dog slammed into her side, its jaws clamping down on her forearm. White-hot pain as the teeth sank deep, tearing through coat and skin alike. She hit the ground hard, sand grinding into her face, her phone skidding away, its light spinning."
    "It shook its head violently, dragging her arm, twisting, pulling with a force that felt like it would rip the bones from her body. Her scream ripped out of her throat — raw, guttural, endless."
    "Instinct. Her free hand groped blindly until it closed around a jagged rock. She brought it down hard against the dog's skull."
    play sound sfx_thud
    "It growled and didn't release. Hot breath seared her skin. She struck again — harder. And again. The rock slipped in her bloody grip, but she didn't stop."
    play sound sfx_thud
    "The jaw finally loosened, teeth pulling free with a wet rip. She didn't stop. If she let go it would lunge again. She raised the rock and smashed it down with manic speed, each strike meeting bone, fur, flesh."
    "A piercing squeal. The animal twisted to retreat, and she followed it down, raining blows as sand and blood sprayed in the beam of her discarded phone."
    "At last it yelped — a broken, whimpering sound — and stumbled backward, dragging itself toward the darkness. It vanished the way it had come, its retreat swallowed by the pounding sea."
    play sound sfx_thud
    "Somewhere behind her, the same metal door slammed shut."
    stop music fadeout 2.0

    scene bg beach_night with fade
    show vignette
    call mature_show("dog_bite")
    "Amanda collapsed onto her knees, the rock falling from her trembling hand. She clutched her torn arm against her chest, sobbing, breath ragged, throat raw. The voice. The door. The dog."
    "She pressed her forehead into the sand and wept, every part of her shuddering. Her arm throbbed with each heartbeat, sticky with blood. The salt wind stung the open wounds. She dug her hands into the cold sand as though the earth could anchor her."
    "At last, with effort, she forced herself upright. Her coat hung in tatters, her sleeve soaked through, the skin beneath shredded."
    call mature_hide
    "The sea roared louder now, or maybe it was her own heartbeat. She scanned the darkness, half-expecting the door to open again, another shadow to emerge. Nothing. Only black waves, only the rustle of sand."
    "She staggered to her feet, swaying, every muscle trembling with shock. One thought pierced the chaos."
    ath "They tried to kill me."
    $ note("A voice on the beach. A metal door. A dog. They tried to kill me.")
    play sound sfx_tinnitus
    "Her sobs tore through her throat until they broke into something else — guttural growls, the sound of a wounded animal. She clutched her arm, rocking forward on her knees, every nerve screaming."
    "Her ears rang with a violent buzzing, a storm trapped in her skull. Janet. The pain. The village. The voice. All of it spun, colliding, fracturing, rising until it felt like her head would split apart. She pressed her palms to her ears, choking on her own breath."
    "And then—"
    pause 1.5
    "Silence."
    "The buzzing cut out as suddenly as it had come. The whirl of panic and grief dropped into a void. All that remained was the sea. The endless rhythm of waves. The hiss of wind along the cliffs. The real world, stripped bare."
    "Her sobs stilled. Her shoulders trembled once more, then eased. She blinked, vision blurred, but the tears no longer fell."

    scene cg the_belt with dissolve_slow
    window hide
    pause 2.0
    window auto
    "Mechanically, she pushed herself upright, her body moving as if guided by something outside herself. She staggered once, steadied, and pulled the belt from her waist."
    "Slow, precise, practiced, though she had never done this before. She wound the belt tightly above the wound, jaw clenching as the pressure flared the pain into a white-hot burn. Her breathing hissed through her teeth, but she didn't flinch. Not anymore."
    "The leather bit into her skin. Blood welled beneath, sticky against her coat. She tugged the knot tight. Infection, blood loss — she didn't think the words. She knew them. She knew what she had to do."
    "When she lifted her gaze again, her eyes were different. The frantic edge was gone, the panic drained. What remained was something colder. Emptier. A void where the screaming had been."

    scene bg beach_night with dissolve_slow
    show vignette
    play music m_forecourt fadein 3.0
    "The wind whipped her hair into her face; she didn't brush it aside. She breathed once, deep and calm, and stepped forward."
    "The sea continued to roar, but it no longer felt overwhelming. The cliffs towered sharp and jagged, but they no longer pressed down on her. The pain in her arm radiated through every nerve, but it no longer owned her."
    "Her shadow stretched long and broken across the wet sand, fractured by the light of her discarded phone still glowing behind her. She didn't look back at it. She didn't need it."
    "Her boots pressed into the sand with steady rhythm, one after the other. No hesitation. No faltering. The tears were gone. The buzzing was gone."
    "Amanda was gone, too — the Amanda who had come here in desperation, who had begged, who had panicked, who had cried out for help in an empty village."
    "What walked forward now was quieter. Harder."
    "Cold eyes fixed on the path ahead, Amanda continued on."

    jump ch09
