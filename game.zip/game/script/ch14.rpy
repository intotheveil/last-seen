## Chapter 14 — "Carry Me"
## Source: docs/manuscript/ch08.txt l.279–356. POV: Amanda throughout (no sprite).
## Beats 47–50 per docs/horror_beats.md; rulings #4 (the call) and #5 (Amanda never knew Sofia's name).
label ch14:
    call chapter_card(14, "The cell — a broken choir")

    # --- The abomination speaks ---------------------------------------------------------
    scene bg cell_abomination with fade_slow
    show vignette
    show abomination chained at center with dissolve
    play ambient sfx_storm fadein 3.0
    play music m_nineteen fadein 3.0
    call place("Beneath the church — the storm overhead")

    "Amanda edged closer, every instinct in her body screaming to turn and flee."
    "The creature loomed, its proportions wrong in every way, a parody of what flesh should be. Each link of chain that bound it seemed too small, too fragile, and still it hung there, watching her through eyes like hollow lanterns."
    "Her voice cracked when it left her throat."

    menu:
        "Are you… a failed Nephilim attempt?":
            am "Are you… a failed Nephilim attempt? Did a ritual make you this?"
        "What are you?":
            am "What are you? Did a ritual make you this?"
            "A child's question, in a cellar full of bones. It was the only one she had."

    "For a heartbeat there was silence — silence so heavy it felt alive. Then the abomination's chest lurched, and a jagged sound spilled from its mouth. A laugh, grotesque and clipped, like iron scraping against stone."
    "Black ichor dribbled between its teeth, smoke curling upward, stinking of ash and rot. The grin never shifted. It had always been there, as if the mouth itself had been carved into a permanent leer."
    ab "You call us many names."
    "Its voice was not one but many, overlapping, a broken choir where each note bled into the next."
    ab "Angel. Demon. Savior. Curse. You kill in our name, you betray your kind in our name, you build empires and burn them down again — all in shadows you do not understand."
    ab "You are nothing but a spark in the dark, a glimpse of time in our gaze. And yet…"
    "The chains rattled as its head tilted."
    ab "…you crown yourselves significant."
    "Her stomach twisted. She clenched the knife, though the gesture felt like mockery — like holding a child's toy before a storm. Still she forced the words out."
    am hard "Yet you are chained. Like an animal."
    "The grin widened. For a moment she thought its head would split apart, the corners of its mouth tearing to its ears. Teeth slick with black fluid gleamed in the half-light."
    "And then — a sound like wood cracking in frost."
    "The iron links corroded in seconds, rust flowering along their length before crumbling into orange dust. One by one each chain snapped and fell away, clattering to the stone floor."
    show abomination free at center with dissolve
    with vpunch
    "Amanda froze. Her heart stuttered so violently she thought it had stopped. Her breath caught in her throat."
    ath "This is it. I provoked it. I invited my own death."
    "But the creature did not lunge. It did not even shift. It simply stood, towering, the grin fixed, as its voice came again."
    $ note("It rusted its own chains to dust in a breath. It stayed down here because it chose to.")
    ab "I have feasted on your kind. On your livestock, on your children, on your desperate prayers. I have worn the mask of your gods and laughed at your fear."
    ab "And still you crave me. You drink our blood, you plant our seed, you call it ritual."
    ab "You are nothing but soil, eager to be sown."
    $ note("You are nothing but soil, eager to be sown.")
    "Her throat was dry. Somehow she managed to speak, her voice thin, defiant."
    am "Then why stay here? Why let yourself be bound, when you could have left?"
    "The ichor dripping from its teeth hissed when it hit the stone. Its eyes, hollow and faintly glowing, turned to her fully now — and for a heartbeat she felt stripped bare, her bones, her blood, her thoughts all laid open."
    ab "Because Markus…"
    "It savored the name like poison on its tongue."
    ab "…is the seed. Through him the gate opens. Through him the Old One shall pass. And when He comes…"
    "The grin stretched further, impossibly."
    ab "…your world will not be devoured. It will bend. Fold. Become His flesh. As you have always begged."
    $ note("Markus is the seed. Through him the gate opens. Through him the Old One shall pass.")
    "Her lips parted before her mind could stop them. The words left in a broken whisper."
    am "Then… what do you want from me?"
    "For the first time the grin shifted — not wider, but deeper, as though it pulled inward, dragging the very skin of its face taut."
    "The voice came hollow and vast, filling every corner of the chamber so completely that she couldn't tell if it came from the creature's mouth or from her own thoughts."
    ab "I am but reflection. A shard scattered through your world, splintered across your prayers, your myths, your lies."
    ab "You named me, worshipped me, buried me, feared me — and so I remain. I am because you remember. I breathe because you speak."
    "She shivered, hands trembling against the knife's handle. The rain and blood on her skin felt suddenly colder, like ice crawling beneath it."
    "The creature leaned forward, its neck cracking in wet snaps. For a moment she thought it might collapse on top of her. It stayed, looming, its teeth dripping."
    ab "Yet through you, I came. And through you, I remain. The seed, your Markus, believes himself gate and master. But he is meal. He is tinder to flame. He should die."
    "Its grin tore wider again, as if it had waited centuries to savor the words."
    ab "And when he dies… I shall feast. On him. On all of him. Until not even his name remains."

    hide abomination with dissolve_slow
    "Amanda backed away, every step careful, eyes never leaving the thing until the shadows swallowed it whole. The last trace of its grin shimmered like an afterimage in her skull before the dark claimed it."
    "She pressed against the wall, palm sliding over damp mortar to keep herself steady. Her mind spun, trying to order what she'd seen, what she'd heard."
    ath "Markus. The abominations. The seed."
    "It all tangled into one sick truth. Markus didn't just know the abominations. He commanded them. Somehow, by blood or ritual, he held them bound."
    "One had sat chained in this chamber for years — a decade, maybe longer, if the Book was true. Markus wasn't bluffing. He had leverage over monsters that were supposed to be uncontrollable."
    ath "And yet. {i}The seed should die. I shall feast on him.{/i}"
    "Markus was both master and prey. A gatekeeper, but also bait. If he succeeded, something worse would come. If he failed, he'd be devoured."
    "Either way — her, Janet, everyone — they would be nothing but kindling in someone else's fire."
    "She clenched her teeth and forced herself to breathe slow, shallow. The storm rattled faintly through the stones, thunder echoing like distant drums."
    ath "Lose or lose. That's all this was."
    $ note("Lose or lose. That's all this was.")
    "And yet she couldn't stop. Not while Janet was out there, tangled in this web, marked for something that should never be."

    # --- Carry me -------------------------------------------------------------------------------
    show abomination free at center with dissolve_slow
    "The abomination was not finished with her. The shadows gave it back, gaunt and unshackled, and for one hopeful instant she thought it might slink into whatever pit had birthed it."
    stop music fadeout 1.5
    play sound sfx_tinnitus
    "From its throat poured a sound that defied creation — a low thrumming moan that swelled into a cascade of guttural syllables. It was speaking again, though not in any tongue of men."
    "The air vibrated with it. Stone cracked in the walls as if the words themselves were tearing at the chamber. Her teeth rattled; her vision blurred at the edges."
    "She fought the urge to clap her hands over her ears. It wouldn't help. The voice wasn't passing through her ears at all. It resonated inside her skull — a chorus of wet murmurs and shrieking choirs, ancient and otherworldly."
    "She did not understand the language. Yet the meaning poured into her head like black syrup, coating her thoughts. A great gnarled tree dripping with blood. An endless night split by roots of lightning. Her own body on the ground, and something vast moving inside it."
    am "S-stop…"
    "Its hollow eyes bored into her, pinning her in place. It was asking — no, commanding — something of her. She felt the intent as clearly as a hand closing around her throat."
    "Her knees nearly buckled as the understanding crystallized. The thing was begging her for passage. It wanted to hide within her."
    ab "Carry me."
    "The voice came voiceless, inside the bone."
    ab "Carry me inside your flesh. Hide me in your womb. Deliver me to the Tree."
    $ note("Carry me. Inside your flesh. To the Tree.")
    ath "The Tree."
    "Her thoughts latched onto the word, frantic for sense. Markus. Her sister. The ritual. The Book had drawn it in ink: a tree bearing foul fruit, vessels beaten and starved and forced to eat, ribs opening outward on the anatomy plate. And Janet chained, awaiting the same."
    "Her free hand drifted to her abdomen, trembling."
    ath "Inside my womb."
    "The womb that had never known a child, never been more than an abstract thought at the back of a busy life, now threatened to become the hiding place for a nightmare."
    am "I… I can't."
    "The command slithered through her, relentless. The creature loomed taller in the torchlight, its silhouette stretching like one cast by a corpse-lantern. Black ichor dripped from its ruined grin."
    "It was waiting. It would not let her leave until she answered."
    ath "If I refuse this… ally? This monster. Then what hope do I have? One person, hurt and alone. Markus has an army of fanatics and the power to bind creatures like this."
    ath "If I run, Markus kills me, or worse, and Janet is lost. If Markus wins, the Old One comes through the gate. If Markus fails, this thing has promised to feast on him and on everything in reach."
    ath "Lose or lose. That's all this is."
    "A soft, desperate laugh bubbled up in her throat — hysterical, almost a sob. No outcome was good. But perhaps there were shades of doom. If she threw in her lot with this chained devil, perhaps she could at least tear Markus down and spare her sister whatever he had planned."
    ath "The enemy of my enemy."
    "The abomination tilted its skeletal head, waiting. The grin stretched in anticipation. It wanted her to agree. Of course it did. It needed her. She was its only path out of this prison and into the heart of the ritual."
    "She pressed a fist to her mouth, nearly gagging on the taste of blood and fear. She had killed twice tonight, and once already at this thing's bidding — Michael's corpse cooling not five feet away, his blood splashed across her sleeves."
    ath "Was it murder, or survival? I don't know anymore. The line blurred to nothing the moment I stepped into this village."
    "She thought of Janet's smile, the dimple in her cheek, the little drawings she used to leave on Amanda's desk to cheer her up. She thought of Janet's eyes, so like their mother's, and that cursed call from Janet's phone, cut off before it could beg for help."
    "Janet, who had trusted a monster and was now in chains. Janet, who always believed Amanda could fix anything."
    "A cold calm flooded her chest. She lowered her fist from her lips. Her knuckles had gone white."

    menu:
        "If I do this… will you help me stop him?":
            am "If I do this… will you help me stop him?"
            "The question was absurd — the thing served only itself, she knew that. Yet she needed to hear something, anything, before she gave up the last shreds of her humanity."
        "If you touch her, I'll cut you out of me myself.":
            am "If you touch my sister, I will cut you out of me myself. Do you understand? Help me stop him."
            "An absurd threat to make to a thing that had rusted iron with a thought. She made it anyway. It was the last shred of herself she had left to bargain with."
        "Swear it. Swear you'll stop him.":
            am "Swear it. Swear you'll help me stop him."
            "As if it could swear by anything. As if its word were worth more than Markus's. Yet she needed to hear something, anything, before she gave up the last shreds of her humanity."

    "The many-voiced whisper churned through her bones, a grind of promise and hunger."
    ab "Yessss…"
    "A hissing chorus, the word stretching, crawling along the floor. She wasn't sure if she heard it with her ears or if it simply bloomed inside her head. It curdled her blood all the same."
    ath "Help, or so it claims. More likely it will use me to get close to Markus and then unleash Hell. But that is precisely what I need done. Isn't it? And if unleashing Hell is the only way to save Janet—"
    "Her throat tightened. Hot tears pricked her eyes, born of terror and fury."
    am "Fine."
    "She squared her shoulders, every muscle trembling. With a shaky, deliberate motion she shrugged off her sodden coat and let it drop. Beneath it her blouse was torn and bloodstained."
    "She pressed a hand over her belly, the gesture almost protective, though nothing could protect her from what she was about to invite in. A sob escaped her lips. Her eyes burned with feral resolve."
    am "Do it."

    # --- The possession: BLACK FRAME + SOUND (beat 49, condensed) --------------------------------
    scene black with fade
    "It needed no further consent. In two great strides it closed the gap. The reek of charnel winds and centuries of decay gusted over her, so strong she couldn't breathe. She forced herself rigid. She would not flee. Not now."
    "Cold, leathery fingers, each as long as her forearm, closed around her shoulders. It tilted its head down to regard her like a specimen on a slab. Then, with slow, hideous grace, it began to dismantle itself."
    "Its skin sloughed into dust. Its bones groaned and collapsed inward. A thick, tar-like fluid gushed from its mouth onto the stones, and the whole towering shape sank into a pool of living darkness that swirled at her feet. Waiting."
    ath "If I lose consciousness now, I drown in it. Stay awake. Endure. For Janet. For Janet."
    play sound sfx_heartbeat
    "Something brushed her ankle. The cold was unlike anything she had ever felt — an arctic death, a vacuum that sucked the breath from her lungs. The dark took her legs, and the floor came up to meet her."
    play sound sfx_thud
    "She slapped a hand over her mouth and cut off the scream. Her free fist found the stone and pounded it, over and over, needing something to anchor her to the world."
    "The cold poured into her. There was blood — her own, hot where everything else was ice — and a fullness spreading under her ribs that eclipsed the chamber, eclipsed time, eclipsed everything."
    play sound sfx_tinnitus
    "And in that void, something stirred. A vast presence, like an eye opening and fixing its gaze upon her soul. An ocean pouring into a thimble. She was no longer Amanda. She was a vessel, a cup brimming with ancient fury and hunger."
    "She saw: a ring of standing stones under a storm-wracked sky, faceless figures bowed to a colossal black tree. A village on fire, its people dragged into the earth by root-like shadows. A towering silhouette with burning eyes, striding across a field that had once been people."
    "Memories. Not hers. Echoes of a time when it had answered humanity's call for gods and delivered only death."
    ath "Stop… please stop…"
    "She had no mouth in that place. She was drowning in it."
    "And then, through the maelstrom, a face. Janet as a little girl, reaching for her with tears on her cheeks."
    "{i}Help me, Mandy…{/i}"
    "The child's voice rang clear and pure, slicing through the nightmare. Amanda seized it like a lifeline. Janet was real. Janet was now. She dragged herself back into her own flesh — into the cold stone beneath her, into the pain."
    "Her belly swelled, the skin going taut and veined, searing hot and freezing cold at once, until she was certain she would burst apart at the seams."
    "A final spasm wracked her. Then the pain ebbed from cataclysmic to merely unbearable. The cold presence settled deep, coiling itself into the hollow of her womb like some infernal fetus."

    # --- After ------------------------------------------------------------------------------------
    scene bg cell_abomination with fade_slow
    show vignette
    "For several long moments she lay on the stone floor, twitching in shock. Steam rose around her in wisps. Her thighs were slick and warm; she didn't have to look to know she was bleeding badly."
    call mature_show("belly_after")
    "She pressed a quivering hand to her belly. It was grotesquely swollen — she looked nine months with child. Beneath the torn remnants of her blouse, dark veins spread outward from her navel like spiderwebs, pulsing faintly, as though in time with a second heartbeat."
    ath "God… oh God…"
    call mature_hide
    "Something moved inside her. She bit back a scream as a bulge passed under her palm — a limb, or a tendril, shifting within. It didn't pierce out. It merely repositioned, then went still."
    "Tears finally spilled. She wept silently, each sob a red-hot knife in her throat. She felt ruined. Defiled. She wanted nothing more than to curl up and sob until death took her."
    "A faint sound cut through the ringing in her ears: the roll of distant thunder. The storm. Janet was out there under it, awaiting a fate worse than death. And now Amanda carried a piece of Hell inside her."
    ath "I made a choice. I'm not dead. I'm… I'm still me."
    "She almost expected the thing to refute her, to whisper in her mind, to seize her limbs. It didn't. It lay quiet within her, a coiled snake sleeping in her entrails. Waiting."
    play music m_judgment fadein 3.0
    "Slowly, shakily, she rolled onto her side and pushed herself to hands and knees, then to a crouch, then to her feet against the wall. Her belly hung heavy, a leaden weight pulling at her spine."
    "The bulge had receded somewhat — what had looked nine months now looked two or three — but the skin was tender and distended, and every slight movement inside her made her flinch."
    "She yanked her torn jeans up and cinched the belt tighter to hold them. Then the coat. She wrapped it around herself with trembling fingers, hiding the stains and the swelling beneath the wool."
    "The chamber reeked of blood, rust and afterbirth. Michael's body still sprawled near the door, eyes glassy, a forgotten casualty in this unholy night."
    "She felt light-headed, hollowed out, yet paradoxically stronger. Adrenaline, perhaps. Or madness. Or the thing inside her lending a fraction of its vitality to keep its new vessel upright."
    "The howling panic that had dogged her for hours was gone, burned away in the crucible of pain. What remained was grim resolve, hard and cold."

    menu:
        "Take the knife from him.":
            "She paused by the corpse. The knife she'd plunged into his throat was still lodged there, the hilt protruding from a coagulated mess of blood."
        "Leave it. What good is a knife now?":
            "What could a mere knife do now? The greatest weapon she possessed was curled up inside her. She took two steps past him — and stopped, and turned back. A knife was still a knife."

    "She crouched with difficulty, pried the blade free with a wet squelch, and wiped it on Michael's sleeve. Her shoulder ached where he had wrenched it. It felt distant, insignificant."
    ath "I will need this."
    $ note("Michael's knife. Pried from his throat and wiped on his sleeve. I will need it.")
    "She tucked it back into her belt. The weight of it against her hip was a comfort, and a dark part of her mind mocked the gesture."
    play sound sfx_thud
    "A faint noise echoed from somewhere up the corridor — a distant shout, or the slam of a door. It spurred her into motion. She had spent too long here. Janet's time was running out."

    scene bg undercroft_corridor with dissolve_slow
    show vignette
    "She crept out of the chamber into the winding passage beyond. The darkness was near total, but she moved with surprising ease, as if guided by an unseen hand. Her senses felt unnaturally sharp."
    "The passage climbed. A stone stairway led her up, toward the muffled rumble of thunder and the hiss of rain."

    scene bg tunnel_grate with dissolve_slow
    show vignette
    show rain
    "A rusted metal grate camouflaged the tunnel's mouth. She set her shoulder to it and pushed. It gave with a shriek of iron, and the storm greeted her with a gust of cold wind and needle-sharp drizzle against her face."
    "She climbed out on her hands and knees into a tangle of thorny brambles at the edge of a forest clearing. Overhead the sky churned iron-grey, hiding the moon. Lightning flickered, and tall pines stood around the clearing like silent sentinels."
    "Torchlight moved between the trunks. Voices — many of them — chanting under the rain."
    "And beneath her coat, as she rose to her feet, the thing inside her turned over once, as if it had smelled the Tree."

    jump ch15
