## Chapter 3 — "We Meet at Dusk"
## Source: docs/manuscript/ch03.txt l.3–87 (Markus POV) + ch04.txt l.3–38 (Amanda POV).
label ch03:
    call chapter_card(3, "Driftwood Bay — past midnight")

    ## ---- 3.1  Driftwood Bay by day (omniscient montage) ----
    scene bg coast_wild with fade_slow
    play ambient sfx_wind fadein 2.0
    play music m_greyvale fadein 2.0
    call place("The coast road — late afternoon")

    "The coastline stretched wild and unbroken, the sea battering the land as if intent on erasing it. Waves shattered against jagged rocks. The wind carried no softness, only a hollow roar that sent gulls scattering into the grey sky."
    "No people moved here. The beaches lay empty, dark sand littered with driftwood and seaweed; the rare houses along the road stood shuttered and weather-stained, less like homes than remnants of a season long past."

    scene bg burned_hills_road with dissolve
    "Beyond the coast the road climbed through green hills, forests leaning close enough to swallow it whole. Blackened stumps lingered among the trees, silent witnesses to summers of devastation. Yet new shoots pushed through the charred remains."

    scene bg village_view_day with dissolve_slow
    "At last the road bent inland and revealed Driftwood Bay: a modest cluster of rooftops pressed between hills and sea. No hotels, no marinas, no postcard beaches marked it on a map. Life here was small, self-contained, forgotten by the world yet quietly enduring."
    "Thick stone walls, shutters painted sea-worn shades of blue and green. Narrow lanes wound between the houses, vines creeping across fences, fig trees leaning over courtyards where stray cats dozed."
    "The village stirred gently in the late afternoon. Men with baskets of oranges, women exchanging bread on the steps, laughter from neighbors repairing a fence. Faces were known. Doors stayed unlocked. Help was given before it was asked for."

    scene bg village_view_dusk with dissolve_slow
    "As the sun sank, windows bloomed with amber light. Woodsmoke drifted into the streets, pots simmered, children's laughter carried through the lanes. A passerby could catch fragments of it: a burst of laughter, a playful scolding, someone calling for more bread."
    "The streets themselves were nearly empty, save for a cat along a fence or a man carrying firewood across a courtyard. A place without wealth or ambition, held together by familiarity — modest, enduring, whole."
    "It was not a place of spectacle. But as evening settled it felt whole, every table, every fire and every shared word a thread stitching its people together. It was home."
    "And yet, like every home, it carried its secrets — tucked away behind closed shutters, buried in silence, waiting for this night to draw them out."

    ## ---- 3.2  Past midnight: the walk to the church ----
    stop music fadeout 3.0
    stop ambient fadeout 2.0
    scene black with fade_slow
    pause 1.0

    scene bg village_lane_rain with fade_slow
    show rain
    show vignette
    play ambient sfx_rain fadein 2.0
    play music m_judgment fadein 3.0
    call place("Driftwood Bay — past midnight")

    "It was past midnight when a lone figure appeared on the narrow streets of Driftwood Bay. The village that only hours before had been filled with the warmth of laughter and dinner now lay sealed in silence, its shutters drawn, its windows dark."
    "Rain drifted in slow sheets, soft drops breaking across the uneven cobblestones, turning them slick as glass beneath the lamps."
    "The man moved with steady, unhurried steps. His long coat brushed against his legs, the hood drawn low, shadowing his face. Each footfall echoed in the emptiness and was swallowed quickly, as though the streets themselves refused to carry sound too far."
    "The air smelled of wet stone and damp wood. The sea rolled unseen beyond the last houses, its roar dulled by the mist. A gust now and then rattled shutters and set signs creaking on their chains. But no doors opened, no voices called out. Driftwood Bay slept with its back turned."
    "The silence made each noise precise: the drip of water from a balcony, the groan of beams in old houses, the whisper of the tide behind the wall of mist. Only the figure pressed forward."

    scene bg church_ext_rain with dissolve_slow
    show rain
    show vignette
    "At the far end of the street the church rose, its steeple a jagged silhouette against the clouded sky, taller than the clustered roofs hunched below. Most lamps on this stretch had guttered out."
    "He passed through swathes of near-darkness, under sagging archways and dripping vines, into the shallow glow of a single flame, then lost it again to shadow. The world felt reduced to his breathing, the pulse of his stride and the insistence of the rain. His course was fixed."

    scene cg three_knocks with dissolve_slow
    window hide
    pause 2.0
    window auto
    "The steps gleamed wet when he reached them. He climbed and stopped before the tall doors, rain running from the edge of his hood, his breath steady in the cold night air. Then he lifted a gloved hand and rapped three times against the old wood."
    play sound sfx_thud
    "The knocks landed like hammers, dull and heavy. A pause. Then the hinges groaned, and an old woman appeared in the crack of the door, stooped slightly, gray hair bound beneath a scarf. Her eyes, though clouded by age, carried an alertness that did not fade."
    "She regarded him without surprise and dipped her head once."
    ow "Come in."

    scene bg church_nave with dissolve
    show vignette
    stop ambient fadeout 1.5
    "He stepped across the threshold, the warmth of the interior settling against his coat. Candles flickered along the nave, their flames bending and straightening as if uneasy."
    "He followed the woman in silence, her soft steps absorbed by the stone floor, past the altar and into a narrow side passage. At its end she pushed open a heavy wooden door."

    ## ---- The council of seven ----
    scene bg church_council with dissolve
    show vignette
    play music m_driftwood fadein 2.0
    "A chamber stripped of ornament, lit only by a ring of oil lamps casting long, uneasy shadows across bare stone. Seven men waited, their coats and sweaters plain, their faces carved with a seriousness that magnified them beyond their bodies. All of them turned as he entered."
    show jonathan neutral at center with dissolve
    show kalinos neutral at left with dissolve
    show michael neutral at right with dissolve
    "He lowered his hood slowly, letting water drip from the folds. His eyes swept the room once. One by one he measured them. They did not measure him back. They straightened, as though something long-expected had finally taken shape."
    mk "Good."
    "His voice carried calm, and weight. They knew him: every vessel he had secured, every ritual prepared under his direction, every failure averted with a precision others lacked. Respect was not offered in this circle. It was won and held. And Markus held it now."
    "Some were very old, with faces like weathered stone, carrying memory no book could hold; others were still sharp from youth. But all deferred to the presence at the center of the room: Jonathan Morales."
    "To the village, Jonathan was simply the head of Driftwood Bay, a role one might mistake for mayor. Within these walls he was something greater, the anchor of generations. At more than seventy his posture remained straight, his gaze as sharp as any blade."
    "To Jonathan's side sat Jacob, his second son, trying and failing to mirror his father's bearing. His shoulders sagged a fraction; his eyes wandered."
    "To Markus's right sat Michael, his childhood companion — tall, broad, his silence worth more than another man's arguments. If Jonathan was the mountain of Driftwood Bay, Michael was its shield. Markus trusted him more than any man here."
    "To his left sat Priest Kalinos, bent with years, eyes sunk with a wisdom older than the rest combined. His voice no longer thundered as it once had, but even whispered words from him could quiet the room."
    mth "And he has already named me successor, in everything that matters."
    "The rest were elders, enforcers, witnesses — not here to debate but to confirm, to obey, and to carry Markus's words into every shuttered home in the village. He crossed the chamber and lowered himself into the chair. Water dripped from his hood, darkening the stone."

    menu:
        "Let the silence stretch.":
            "He folded his hands and let the silence stretch until the lamps hissed faintly in the oil. No one filled it. That, too, was a measurement, and every man in the room passed it by holding his tongue."
        "Watch Jacob while they wait.":
            "He folded his hands. Jacob's eyes wandered — to the door, to the lamps, to his father's hands — while the silence stretched and the lamps hissed faintly in the oil."
            mth "A pale echo. A hollow attempt at command. Jacob is of no consequence."
            "Markus's lips did not so much as twitch."

    jon "Is everything in place?"
    "Jonathan had leaned forward, half in shadow. Steady, not quite a question — more ritual than doubt. Markus held his gaze and gave a single, deliberate nod."
    mk "Yes. The vessel is prepared. The conditions align as they must. Nothing has been overlooked."
    "A murmur shifted the circle. Not surprise, not fear — simply confirmation, as though all had expected nothing less. Jonathan's shoulders eased by a fraction."
    kal "You have done well, Markus. Better than any before you. Thorough, precise. If the old texts hold true, this vessel is our strongest chance since the first generations."
    "Jacob shifted forward, mouth half-open as if to speak, but his father's hand cut the thought short before it could form. He sank back. The rebuke was silent but final."
    mk "I will not pretend certainty. We all know what failure looks like. We have all seen what happens when the flame consumes rather than endures."
    mk "But my preparations hold. The vessel carries what is required. Tomorrow, the work will begin."
    mi "Then there is nothing more to be said. We are ready."
    "It was the first time Michael's deep voice had rumbled. The others nodded. That was their role: to listen, to leave convinced, to spread the conviction like smoke through the village. Markus had spoken; therefore it was settled. Jonathan rose to his feet."
    jon "Then we meet at dusk."
    "His tone brooked no argument, though none was offered. One by one the others pushed back their chairs and filed out, their footfalls fading into the hall."
    hide jonathan with dissolve
    "Only three remained: Markus, Kalinos and Michael. Kalinos rose with effort, his hand brushing Markus's shoulder in passing."
    kal "You carry this now."
    "His eyes were softened by something between pride and warning. Then he, too, left, his steps uneven but sure."
    hide kalinos with dissolve
    "The silence returned, thick and waiting. The lamps trembled faintly, their hiss the only sound until Michael finally spoke."
    mi "You've secured their faith. Even Morales bows to you now. Jacob's nothing. But still — you must know, if this fails—"
    "Markus cut him off with the barest shake of his head."
    mk "It will not fail. The isolation has rotted their will, made them doubt. But doubt is weakness. I have none."
    mk "My only concern is you, Michael. Are you with me?"
    mi "Of course."
    "No hesitation. Markus's mouth curved faintly, neither warmth nor cruelty — something harder."
    mk "Good."
    "No more words passed between them. Michael pulled his coat close, ready to take the path out through the nave, but Markus lifted a hand — a small gesture that froze him."
    mk "Come."
    mi "Where?"
    mk "You've followed me this far. You'll see it now."

    ## ---- 3.3  The stair, the door, the cell ----
    hide michael with dissolve
    scene bg church_stair with dissolve_slow
    show vignette
    stop music fadeout 2.0
    "Markus turned, his boots echoing down a narrow archway, and Michael followed reluctantly. The passage bent downward into the belly of the church."
    "The air grew colder, slick with damp, each breath coated with the tang of stone and mildew. Their lantern's flame swayed across walls scored with faint carvings — crosses, symbols, half-effaced by centuries of hands."

    scene bg undercroft_door with dissolve
    show vignette
    "The stair ended in a corridor that pressed close around them. At the far end a door waited: massive, iron-banded, scarred as if raked by claws from both sides."
    "Markus drew a key of bright silver from his pocket, its gleam sharp in the lantern light. The lock groaned when he turned it, reluctant, as if protesting what it held shut."
    play sound sfx_thud
    "The hinges cried out, and the door yielded. At once a sound rose from within. Not loud, but insistent. A rasping whisper that seemed to vibrate in their bones."
    ab "Mar…kuuus…"
    "The syllables dragged out, broken, too raw to be human. The air thickened, as though the voice alone could bind it tight around their lungs. Michael's jaw clenched. Sweat dampened his brow despite the cold. Still, he followed Markus inside."

    scene bg cell_abomination with dissolve_slow
    show vignette
    play music m_driftwood fadein 3.0
    show abomination chained at center, tremble with dissolve_slow
    "The chamber was little more than stone walls and a dirt floor. Chains rattled faintly in the dark. At the center a shape stirred — hunched, trembling, its limbs knotted wrong."
    "The lantern light crawled reluctantly across its skin, stretched pale and translucent, shot through with black veins that pulsed as though carrying fire instead of blood. Its mouth split wide in a soundless scream, then broke into guttural growls no human throat could make."
    show michael neutral at right, dimmed with dissolve
    "Markus dragged a wooden chair forward and sat down directly before it, only a few handspans beyond the reach of the chains. Michael lingered behind his shoulder, towering but restless, shifting his weight like a soldier bracing for attack."
    with hpunch
    "The creature roared again, a sound like tearing metal. The chains snapped taut; stone dust sprinkled from the ceiling. Michael's hand flexed, as though ready to strike. Markus did not flinch. He leaned forward slightly, his face calm, eyes bright in the lantern's flame."
    "Then, with sudden force, his voice cracked through the chamber."
    with vpunch
    mk "QUIET."
    "The word fell like iron. The creature froze. The growls strangled into silence. In their place came frantic, spasmodic movements — its nails scratching stone, its joints shuddering as it tore at its own flesh, as though compelled to release the violence the command had denied."
    mi "Is this…?"
    "His voice faltered, something rare for him. Markus's lips curved faintly, without humor."
    mk "Yes. The abomination."
    "Michael stared, unable to pull his gaze from the thrashing shape. His voice dropped low."
    mi "The entry said it was destroyed."

    scene cg the_leash with dissolve_slow
    window hide
    pause 2.0
    window auto
    "Markus leaned back, folding his hands calmly on his knee. His words came slowly, steady, like a confession he had rehearsed for years."
    mk "I was there. Ten years ago. My first time assisting Kalinos. The fruit bore black veins, the chosen boy consumed it, and then it began."
    mk "You know the rest. You've read it. How it turned on the congregation, how it escaped into the night."
    "Michael nodded stiffly, his eyes flicking to the chains."
    mk "What was never written is what followed. The others fled to their homes, trembling. Kalinos prayed and called it failure. But I did not leave. I hunted."
    mk "The creature ran wild through the fields until exhaustion gnawed it hollow. It was hungry, bleeding from the bullets I put in its chest. Dying, but not dead. Its will was strong enough to cling, even as its body failed."
    mk "That was when I seized it. Shackled it. Dragged it into this place while the village wept."
    mi "And for ten years…?"
    "Markus turned his head toward the creature. Its body writhed, tearing skin from its arms as its nails scraped bone."
    mk "For ten years, I've broken it. Fed it. Starved it. Taught it to know my voice, my presence."
    mk "It has tasted flesh — animal when I had nothing else, human when I could. The elderly who slipped quietly from life, the forgotten vagrants who wandered too close. Their passing became its sustenance. Their bodies… my tools."
    "Michael's face twisted."
    mi "You've kept it alive."
    mk "I've kept it mine."
    "A cold correction. His eyes gleamed with something like reverence."
    mk "This is not failure. This is proof. Every scream, every drop of blood, every bone shattered is proof that the flame burns. That His power exists. That it can be harnessed."
    "He leaned closer, his voice lowering to a whisper edged with fervor."
    mk "It obeys me now. Do you understand what that means? For ten years it has survived what no vessel survived before. It is not perfect — but it is close. And I hold the leash."

    scene bg cell_abomination with dissolve
    show vignette
    show abomination chained at center, tremble
    show michael neutral at right, dimmed
    "The creature thrashed harder, its head jerking side to side, teeth gnashing until blood flecked the stone. Michael's fists clenched, his breath ragged."
    mi "This… thing is no savior. It's a curse."
    "Markus turned to him slowly, his expression calm, almost serene. His smile widened, thin and sharp."
    mk "A curse?"
    mk "Curses, blessings… they are words for the same flame. Only power matters. And power is not given. It is taken."
    mk "Even this — even this listens when I command."
    "He had gestured toward the chained, broken body as he said it. Now he leaned back in the chair, unblinking. The chains rattled; the growls subsided into pitiful shudders. For a moment the chamber fell quiet except for the faint hiss of the lantern."
    "Michael shifted uneasily, his massive frame diminished by what he had seen. He had stood against men and beasts alike, but this pressed against the edges of his sanity."
    "Markus, however, sat as if upon a throne. Patient, deliberate, content in the knowledge that the horror clawing at the stone before him was not chaos but proof."
    mth "Proof of my dominion."

    ## ---- 4.1  Amanda, six in the morning ----
    stop music fadeout 3.0
    hide abomination
    hide michael
    scene black with fade_slow
    pause 1.0

    scene bg amanda_bedroom with fade_slow
    play sound sfx_beep
    call place("The city — six in the morning")
    "Amanda woke to the grating chime of her phone alarm against the glass of the nightstand. Her eyes opened at once, sharp and unblinking, as though her body had been waiting for it. She swung her legs over the side of the bed, bare feet landing on the cool floor with certainty."

    scene bg amanda_bathroom with dissolve
    "The bathroom mirror offered a pale reflection blurred by sleep, but she didn't linger. She stripped away her nightclothes and stepped into the shower, twisting the handle until the water plunged down ice-cold."
    "Her body flinched — muscles tightening, breath seizing. She hated cold showers. She hated the way the water bit at her skin, the way her scalp tingled under the relentless stream. But she endured it. She always endured it."
    "And then, as always, it began to work. The discomfort drove everything else out — the meeting, the client, the weight of expectation scattered like startled birds. Anxiety couldn't survive here. The cold demanded all of her."
    "Her heartbeat slowed from its panicked sprint. She tilted her head back and let the water run across her face until the sting dulled into something she could control. Then she shut it off and wrapped a towel tightly around her shoulders, grounding herself in the simple sensation."

    scene bg amanda_kitchen with dissolve
    play music m_records fadein 2.0
    "In the kitchen the early light slipped through the blinds, striking the sterile counters. Still damp, she pulled an energy bar from the cupboard above the espresso machine and tore into the wrapper with a sharp, impatient motion."
    "A button pressed, a low hum, the hiss of espresso filling the silence. The aroma rose at once — dark, earthy, grounding. Coffee wasn't pleasure; it was fuel. Her first sip burned her tongue and she drank again, as though the bitter heat itself were what she needed to keep moving."

    scene bg amanda_bedroom with dissolve
    "Rows of neatly arranged clothes greeted her: muted tones, precise lines, nothing extravagant. Amanda's world left little space for indulgence. Today mattered. More than most days."
    "A dark navy suit — tailored, efficient, a second skin of authority. Beside it a pale blouse and skirt, more approachable but far less commanding. Her hand hovered between the two as if they were chess pieces and this move would define the game."
    ath "This isn't another client. This is the client."
    "The data center project was large, and if her pitch succeeded, her name would no longer be one among many. She felt the weight of it pressing at her ribs even as she forced herself to breathe evenly."

    menu:
        "The navy suit.":
            "She pulled the navy suit from the hanger and laid it across the bed. The fabric caught the light, its sharp lines promising control."
        "The blouse. Something softer.":
            "Her fingers touched the pale fabric and stayed there a moment. Approachable. Likeable. Then she thought of the boardroom, the glass walls, the faces around the table, and let it go."
            "She pulled the navy suit from the hanger and laid it across the bed. Its sharp lines promised control, and control was the only thing she could afford today."

    "One leg into the trousers, then the other, the zipper pulled with a firm, upward tug. The shirt crisp white against her skin, buttoned from bottom to top. Then the blazer. The routine was precise, almost ritualistic."
    "In the wardrobe mirror the dark suit wrapped her frame, her posture straightening almost instinctively under its weight. On the outside, every bit the professional ready for conquest. Inside, her stomach tightened, her heart ticking faster than it should."

    scene bg amanda_bathroom with dissolve
    "A careful line of eyeliner first, her hand steadied against the counter. Then a soft red lipstick — not too bright, just enough to cover the faint marks left by her anxious habit of biting her lips."
    "Concealer, tapped lightly over the dark crescents beneath her eyes and blended until they softened into her skin. When she leaned back, the reflection was composed, sharper, controlled. Not flawless — but prepared."

    scene bg amanda_living_dawn with dissolve
    "The laptop bag waited on the desk. She unzipped it and checked its contents piece by piece: laptop, mouse, charger, the slim folder with her printed proposal. She scanned the cover sheet once. Everything was there. Everything ready."
    ath "It has to be enough."
    $ note("Strategic Planning Meeting — 9:00 AM. The client. The data center. My name on it, or not.")
    "Preparation never truly stilled the gnawing at her ribs. She carried the bag to the door and set it neatly against the frame. The keys were cool in her hand, grounding and final."
    ath "No mistakes. Not today. Not in front of them."
    "She glanced back once at the neat living room, the silent apartment that had been both her refuge and her cage. The photos on the shelf caught her eye: Janet's bright smile on her graduation day, her parents frozen in their wedding portrait."
    ath "I'm doing this for you. For both of you. Even if it's the only way I know how."
    $ note("Janet's graduation. Mum and Dad's wedding. The two photographs on the shelf.")
    "The moment lingered, fragile, then she shook it away. Her jaw tightened as she turned the handle. The lock clicked, the corridor's muted light spilled inside, and she pulled the door closed behind her with finality."

    ## ---- 4.2  The walk to the subway ----
    scene bg apt_corridor with dissolve
    "Her heels clicked softly on the corridor floor. The narrow space was lifeless at this hour — barely six in the morning — the tenants still wrapped in sleep, the faint hum of radiators the only sign of life behind the doors."

    scene bg apt_elevator with dissolve
    "The elevator groaned open. Tania's suffocating perfume from yesterday had faded; in its place, the stale scent of old machinery and dust — unpleasant, but easier to endure. She exhaled at her taut reflection and fixed her eyes forward until the doors opened again."

    scene bg city_dawn_street with dissolve_slow
    "Outside, the city was only just beginning to stir. The air was cool, brushed with the faint promise of autumn, the sky tinged pale gold where the sun had begun to rise."
    "Amanda pulled her coat a little tighter and started down the familiar path toward the subway. The fifteen-minute walk had become a ritual in itself, a buffer between the stillness of her apartment and the demands of the day."

    scene bg city_park_dawn with dissolve_slow
    "By night the park had felt like a husk, its lake drained, its bridge groaning under the weight of memory. In the morning it carried a different life, a fragile rebirth that came with the day's first light."
    "Birdsong broke the quiet, scattered and playful. Sparrows and blackbirds darted between branches. The breeze carried damp earth and the faint sweetness of wet grass, and she inhaled deeply, easing the tightness that had built since she'd woken."
    "The lake basin was a patchwork of cracked mud and weeds, puddles from last week's rain catching the sunlight like fragments of broken glass. The wooden bridge still arched across the emptiness, its warped planks and crooked nails standing like tired guardians."
    "A jogger passed, earbuds in, his breath misting in the cool air. He gave her a quick nod, which she returned automatically. A few cyclists curved past her, their bright jackets stark against the muted autumn colors."
    "Her thoughts turned, as they always did, to the presentation. She had rehearsed it a dozen times, polished every slide, anticipated every question. There was nothing left to prepare."
    "And yet the weight of expectation pressed against her chest with each step. This was the kind of opportunity that reshaped careers, and she knew it."
    "She forced herself to look around, to anchor herself in the park rather than the spiral of her mind. Sunlight scattered gold across the tree line, the benches, the dew on the grass. The park felt alive, resilient in a way she admired, and she let it steady her while it lasted."

    scene bg city_dawn_street with dissolve
    "The path widened toward the main road. The park fell away behind her, trees thinning into scattered shrubs, then vanishing altogether as the first rows of apartment buildings rose against the morning light."
    "The low hum of traffic thickened into a growl: buses hissing at their stops, scooters weaving between cars, shopkeepers pulling up heavy shutters with metallic rattles."
    "Amanda pressed forward. The subway entrance came into view just ahead: a wide concrete mouth opening toward the underground, already busy with commuters funneling into its depths. People clustered at the top of the stairs, spilling in waves down toward the station below."
    stop music fadeout 2.0
    jump ch04
