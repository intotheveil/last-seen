## Chapter 9 — "A God That Failed"
## Source: docs/manuscript/ch05.txt l.230–455. Amanda POV. Beats 22–28 (docs/horror_beats.md).

label ch09:
    call chapter_card(9, "The tavern — a seam of light")

    scene bg beach_night with fade_slow
    show vignette
    play ambient sfx_wind fadein 2.0
    play music m_judgment fadein 3.0
    call place("Driftwood Bay — night")

    "The sandy path carried her on until the ground changed under her. The cliffs fell back, the beach gave way to cobblestones, and the outline of the village pressed closer. Each step deliberate, silent, as if the village itself were listening."

    scene bg tavern_ext_night with dissolve
    show vignette
    "At the bend, half-hidden behind a sagging awning, stood an old tavern. Its stone walls were weathered, its wooden sign faded to near illegibility. But from a distance she saw it: light. A faint glow leaking from within, golden against the night."
    ath "People. Help."
    "The word had not finished forming before suspicion crushed it. No voices carried. No laughter, no clinking glasses, no shuffle of plates. Just the faint, steady glow spilling across the threshold."
    "Still, she couldn't ignore it. Her arm burned, her blood sticky beneath the torn sleeve. She needed to clean it, patch it, do something to keep herself moving."
    ath "Trust is a luxury you don't have. Survival isn't."
    "She approached carefully, boots soundless on the uneven stones. The windows were smeared with grime, the shutters hanging crooked. One half of the door stood ajar on its rusted hinges. She paused at it, listening."
    "Nothing."

    scene bg tavern_dining with dissolve
    show vignette
    "She pushed the door open with her foot, slow enough to keep the hinges from shrieking. The smell hit her first: stale beer, damp wood, the ghost of long-spilled wine soaked into the floorboards."
    "The light came from deeper inside, a flickering warmth. Chairs were stacked on the tables, except one, set oddly alone near the bar, as if someone had left in a hurry, or never quite finished sitting down."
    "She moved with care, footsteps barely grazing the warped boards. The glow pulsed stronger as she neared the back of the tavern, drawing her deeper into the dark."
    "And then she heard it. Not footsteps. Not voices."
    "Music."
    play sound sfx_static
    "A faint hum, tinny and unsteady, like something leaking from the walls. Not a song, not an instrument. Words. A voice. A radio."
    "Beneath the static rose the unmistakable cadence of a psalm. A hymn, slow and reverent, intoned in a voice that seemed ancient in its weariness. It filled the silence, weaving through the shadows like smoke."
    "She crouched, lowering her frame as she moved closer to the source. A tavern abandoned, lifeless — and yet somewhere inside, a voice prayed through a machine."

    scene bg tavern_back with dissolve
    show vignette
    "She rounded the corner behind the bar. A lantern sat on a table in the back room, its flame steady. Next to it, the radio, a battered box with its knobs worn smooth, its speaker buzzing with the psalm. Her breath froze in her throat."
    show butcher neutral at center, dimmed with dissolve
    "From the far doorway a figure emerged, half-silhouetted by the lantern's glow. Tall and thin, his frame wiry with muscle strung tight against age. He moved with the steadiness of ritual, every step unhurried."
    "In one hand he carried a glass bottle, half full of amber liquor. In the other—"
    "Her gut lurched. Her body threatened to convulse, to expel the horror through her throat, but she clamped her teeth shut and forced it down."
    "Dangling from his fist was a human torso. The legs and head gone. The weight of it dragged his thin arm low, but he carried it with ease, like a butcher with his prize."
    ath "Don't move. Don't breathe. He can't know you're here."
    "His age showed in the lined face, the graying hair slicked back, the sunken cheeks. But the wiry arms, the taut shoulders beneath a once-fine suit jacket, were still strong. An apron hung over him. Clean. Almost immaculate."
    play sound sfx_thud
    call mature_show("torso")
    "He moved to the wooden counter and laid the torso down with a hollow thud against the scarred surface. She flinched at the sound, teeth grinding."
    ath "It was a person. Someone's child. Someone's sister."
    "She shoved the thought back. She couldn't afford it now."
    call mature_hide
    "For a long breath he simply stood there, shoulders rising and falling. Then he lifted the bottle and drank. The liquor ran down his chin and he didn't wipe it away. He set the bottle down hard."
    "The psalm crackled on, words bending through static. His lips moved with it, mumbling, his own version spilling under his breath — not quite prayer, not quite song, something caught between worship and habit."
    ath "He believes this. He worships what did this. He thinks this is holy."
    $ note("He worships what did this.")
    "The thought left her cold. Her body screamed at her to flee, but her mind knew the truth: the door was too far, the floorboards too treacherous. One sound, and she was finished."
    "His hand drifted to the table, to the object resting there. A butcher's knife."
    "The blade gleamed in the lantern light. Sharp, but not sharp enough for him. He drew it across a steel sharpener, slow, methodical, the scrape biting into her bones. Each pass deliberate, his lips moving in rhythm with the psalm."
    ath "I've seen enough to know the order of things here. The drinking. The prayer. The cutting."
    "Her eyes slid shut against it. She pressed herself tighter into the corner. The scrape of steel on steel filled the silence. Once. Twice. Again."
    ath "I can't run. I can't scream. Just hold. Just stay small. Survive."
    "She began to step back. Slowly. Quietly. One step. Another. She never took her eyes off the lantern's glow, as though it might leap forward to expose her. She already knew she wasn't welcome here. This place wasn't built for her survival."
    hide butcher with dissolve

    scene bg tavern_dining with dissolve
    show vignette
    "The doorway opened back into the dining area. She slipped through, body close to the wall. Out here the air felt less suffocating, but no safer."
    "The tables were scrubbed almost unnaturally clean. On each, a small vase of stiff plastic flowers faded to dusty pastels. Ashtrays, pristine, lined up with military neatness. Oil, vinegar, salt, pepper. Untouched. Waiting."

    menu:
        "The refrigerators behind the bar.":
            "She moved quickly, quietly, to test them. Each handle was sealed with a thick padlock, secured tight, as though guarding something more precious than food."
            ath "Whatever these people keep here, it isn't for outsiders."
            $ note("Padlocked refrigerators in the tavern. Whatever they keep, it isn't food.")
            "She turned instead toward the waiter's stand near the entrance."
        "The waiter's stand by the door.":
            "Behind her the refrigerators sat sealed under thick padlocks, guarding whatever these people kept from outsiders. She let them be and crept toward the podium."

    "A modest stand, worn with use. Scraps of paper, a cracked pen — and plastic water bottles, half-hidden in the shadow of the counter."
    "She twisted the cap with agonizing slowness. The seal gave with no sound at all. The first sip was a cool rush, washing the metallic tang of blood from her mouth. Her eyes fluttered shut for a moment, savoring it."
    "Then she remembered where she was. The psalm still hummed faintly from the back room. But the steady thuds — the knife cleaving into flesh — were gone."
    "Her eyes snapped open. The bottle was still pressed to her lips when she turned, her neck stiff, the water sloshing."

    stop music fadeout 1.0
    play sound sfx_thud
    show butcher neutral at center with hpunch
    "A crack shattered the silence. Something heavy smashed against the side of her face. The bottle flew from her hand as she crashed against the nearest table, the edge digging into her ribs. The vase toppled, fake flowers scattering across the wood."
    play music m_route_nine fadein 1.0
    show vignette red
    "She gasped, the metallic sting of blood spreading across her cheek. Her head rang, her vision swimming. She clutched at the table to steady herself, dragging in breath after breath."
    "He was there. His frame a shadow cut sharp against the lantern glow, his face pale, eyes deep-set and gleaming with cold fervor. The liquor bottle still in his hand, dripping across his apron where he had struck her."
    "He didn't hold the knife. A flash of relief. Short-lived."
    "His lips moved, a low murmur tumbling out. Fragments of the psalm, twisted, broken, replayed as if he were chewing them into nonsense. His steps were heavier now, deliberate, like a predator closing the gap."
    ath "You can't scream. It would bring more. You can't fight. Not like this. Not yet."
    "His shadow blotted out the lantern light as he closed in. She staggered backward, but there was nowhere to go. His hand shot out, skeletal yet impossibly strong, and clamped around her neck."
    play sound sfx_thud
    "The air fled her lungs in a single ragged gasp as he slammed her down against the table. The wood groaned. Plates and bottles rattled, a vase shattered across the floor. Her legs kicked out uselessly, boots squealing for purchase."
    "His grip tightened. Fingers like iron bands crushed into the soft of her throat, and the sound of her own strangled breath filled her ears. Her vision narrowed at the edges."
    "She clawed at his arm with her good hand, nails raking across his skin, but it was like tearing at stone. Her other arm hung limp and useless, blood dripping steadily down her sleeve onto the table."
    "His face loomed above her, twisted, sweat beading across his temples. His lips peeled back in a feral snarl — not words, not prayer anymore, only animal sound. His breath sour with alcohol, his teeth yellow in the dim light."
    play sound sfx_tinnitus
    "She bucked against the table, her back arching, but the weight of him pinned her flat. The buzzing began again in her skull, a deafening surge that made the world dissolve into fragments."
    "A flash — Janet's smile, soft and unguarded. Another — their parents' faces, framed in the photograph by the door. The dog's jaws clamped around her arm. The village, silent, watching. The man, killing her."
    ath "No."
    "Her hand groped blindly across the table, fingers skittering until they closed on something heavy, cold. The ashtray. She swung it upward with every ounce of strength left in her."
    with hpunch
    "It cracked against the side of his head, near his eye. He grunted, staggered — but his grip did not falter. If anything his fingers tightened, and her vision flared white with sparks."
    "She tried to scream. Only a rasp came. Her other hand flailed across the surface again, frantic, until it struck something else. Glass. A bottle."
    play sound sfx_thud
    with hpunch
    "She didn't think. She swung it fast and hard, smashing the vinegar bottle against his temple. Shards sprayed outward, and the acrid smell stung the room. He roared as vinegar seared his eye, stumbling back, his hands rising to his face."
    "Air rushed into her lungs in a searing gasp. Her body convulsed as she coughed, clutching at her raw throat. Every nerve screamed, but she didn't stop. She couldn't stop."
    "Her hand closed around one of the jagged pieces of the broken bottle. The edge cut into her palm, warm blood slicking her grip, but she didn't feel it. She lunged."

    scene black with flash_red
    play sound sfx_thud
    "The glass plunged into his throat. Once. Twice. Again. His scream turned into a gurgle. He stumbled, clutching at her, but she drove him down with the sheer force of her frenzy. Everything went black."
    "There was no thought. No sound. Only the motion of her arm rising and falling, the resistance giving way. The world shrank to that rhythm, the spray of warmth, the wet crunch and tear."
    stop music fadeout 2.0
    pause 1.5
    "When her vision cleared, she was on top of him."

    scene bg tavern_dining with fade
    show vignette red
    call mature_show("butcher_aftermath")
    "She sat straddling his chest, her legs soaked with blood, the shard of glass still clutched in her trembling hand. His face was unrecognizable. His throat had long since stopped spilling. The tavern was silent again."
    "Her breath came ragged, tearing through her raw throat. Her eyes unfocused, staring through him, through the ruin she had made. The buzzing lingered faintly, but beneath it there was only emptiness."
    "She dropped the glass with a dull clink against the wood. It rolled once, slow, before coming to rest against his hand."
    call mature_hide
    "For the first time, she really saw him — the body slumped in grotesque stillness, the blood pooling beneath, the stink of iron climbing thick into her lungs."
    ath "I killed him. I did this."
    "The thought tore through her like glass. She staggered back, shaking her head as if she could shove it away, but the corpse followed in her vision, burned against her eyes."
    ath "It was survival. You had no choice."
    "But the voice inside wouldn't quiet. It kept repeating the same word, over and over. Killed. Killed. Killed."
    "Her knees buckled. She dropped to the floor, palm slipping in the blood-slick grain. The dizziness came like a wave. She gagged, turned sharply, and vomited onto the boards."
    ath "Get away from him. Just move. Don't look. Janet. Think of Janet. You have to find her. Not now. Not here."
    "She crawled first, dragging herself toward the hallway. Slowly — painfully — her breaths began to even out. She forced herself upright, boots sticking to the floor, and pressed one foot forward, then the next, until the corpse was behind her."
    "A faded sign pointed her toward the restroom."

    scene bg tavern_restroom with dissolve
    show vignette
    "Inside, the air was damp, sour with mildew. A cracked mirror hung above the sink, its glass mottled with age."

    menu:
        "Look.":
            "Her hand rose toward the mirror, as if to wipe the grime from it. It stopped halfway. She turned her face to the wall instead."
            ath "Not yet. Not what you've become. Not yet."
        "Keep your eyes on the tap.":
            "She kept her eyes on the tap. She didn't want to see what she had become. Not yet."

    "The pipes groaned, water sputtering before a thin stream trickled out, cold and metallic. She shoved her wounded arm under it, biting down hard on her lip as the sting flared bright and hot. Blood ran in swirls down the porcelain, spiraling into the drain."
    "Her throat still ached from his grip, each swallow a raw reminder. She cupped water into her mouth anyway, spitting it red onto the tiles."
    "A towel hung nearby, frayed but clean. She pressed it hard against her arm and wrapped it tight, knotting it as best she could with one hand. It soaked through almost immediately."
    "When the pain dulled to a bearable throb she turned away, refusing again to face the mirror. The blood streaking her face. The wildness in her own eyes."

    scene bg tavern_back with dissolve
    show vignette
    play sound sfx_static
    "Back in the rear room the psalm still hummed through static, as though nothing had happened. She yanked the cord from the wall. The radio sputtered, whined, then died. She hurled it across the room. The silence afterward was heavier than the song had been."
    "Bottles lined the counter in uneven rows. She snatched the nearest — whiskey — and unscrewed it with trembling fingers. The first sip burned her throat raw, but it steadied her shaking, if only a little."
    "She poured some over her wound, jaw clenched until her teeth ached as the alcohol seared her skin. The towel darkened further, but it was cleaner now, sharp with the sting of whiskey instead of filth."
    "On a rack nearby, kitchen tools hung neatly. Her eyes fixed on the largest knife — a heavy chef's blade, gleaming faintly even in the weak light. She pulled it down and felt its weight, solid and grounding in her hand."
    ath "The blade felt like certainty."
    "The tavern smelled of iron and liquor now, of death and cleansing. She didn't let herself linger. Her phone's flashlight flared to life. She held it low in her uninjured hand, the knife tight against her side."

    scene bg village_lane_fog with fade
    show fog
    show vignette
    play ambient sfx_wind fadein 2.0
    play music m_alice fadein 3.0
    call cinematic("fog")
    "The tavern door groaned when she pushed it open. Outside, the night had thickened. A heavy mist coiled around the streets, rolling low across the cobblestones, swallowing the outlines of houses. Droplets already speckled her face, faint but steady."
    "No barking dogs, no murmured voices. Only the whisper of waves somewhere beyond the fog and the low hiss of wind through the alleys."
    "She stepped forward and the mist closed around her immediately. Her phone's beam cut only a few feet ahead before being swallowed whole. She tightened her grip on the knife, breath steady now, her eyes hard and empty."

    "The fog swallowed the village whole."
    "Her steps echoed faintly against the cobblestones, muffled almost instantly. Her light only thickened the mist. Houses on either side appeared and vanished, as though she were walking through a labyrinth whose walls moved when she wasn't looking."
    "The air was heavy with staleness — damp stone, rot clinging to wood, the metallic tang of rusted gates weeping into the fog. Each breath felt thick, sour, like inhaling a cellar sealed for years."
    "Fences and gates loomed suddenly from the whiteness. Beyond them, faint shapes twisted into gardens — swings, trees, sheds — warped by the fog until they were grotesque, unrecognizable."
    play sound sfx_thud
    "A sudden bark shattered the silence. Behind a nearby gate a dog lunged at the fence, teeth snapping, froth streaking its muzzle. Two houses down, another joined in. Across the street, another. The whole row erupted, as if the village itself had noticed her."
    ath "They can't reach you. Just keep walking. Don't let them see it — don't let them see you crack."
    "She forced her pace steady. Slowly, the barking thinned. A single growl, then a yelp, then nothing. Silence crawled back in, heavier than before."
    "Her body ached. The wounded arm throbbed beneath its whiskey-soaked towel. Each step dragged. The fire that had carried her through the tavern was guttering now, rage ebbing away into fatigue."
    ath "Keep moving, Amanda. Just forward. Just keep her in your head. Janet, Janet, Janet."
    "The word barely held her together. Her pace faltered. She leaned into a fence, forehead pressed to the iron bars, slick and cold, smelling of rust and wet earth. The knife dangled by her side."
    ath "You're slipping. Get up. Don't stop now. Not here."
    "And then it came again. One bark, sharp and hollow through the mist. Then another. Then dozens. The sound surged in waves until the entire village howled. A chorus of rage, of teeth and hunger, rising from every yard."
    ath "They know where you are. They're calling each other. Herding you."
    "The dogs barked in patterns, answering one another across the fog, circling her in sound. She spun, frantic, but there was nothing — only pale walls of mist and the faint glimmers of houses sliding away into shadow."
    "And then — silence. As sudden as it had begun, the noise died. The stillness pressed in heavier, the fog curling closer, suffocating."
    ath "It's not gone."
    "She raised her phone higher, breath shallow, her arm trembling. She froze. There, in the fog ahead, a shape. Small, delicate, familiar."

    menu:
        "Call her name.":
            am "Janet?"
            "Her voice cracked, raw from the choking."
        "Don't make a sound. Follow it.":
            "She held her breath and took one step, then another. The name came out of her anyway, before she had decided to speak it."
            am "Janet?"

    scene bg village_square_fog with dissolve
    show fog
    show vignette
    "The figure didn't answer, but it moved. Slowly, almost gliding, deeper into the mist."
    am "Janet!"
    "Her legs were already moving before she could think, the knife clutched tight, the flashlight beam shaking wildly as she ran. The figure was always just ahead, the mist hiding its features. But she knew the slope of those shoulders, the sway of that hair. It had to be her."
    "She chased, stumbling on slick stones, boots splashing in puddles, breath tearing in her chest. The fog pulled Janet away, then brought her close again, like a cruel game."
    am "Stop! Wait!"
    "Her own desperation echoed back at her, thin and hollow. The figure slipped around a corner, disappearing behind a wall of white. She sprinted after it, ignoring the fire in her arm."
    "The mist thickened again, swallowing everything. She stumbled to a halt, spinning in circles, the beam cutting through nothing. Janet was gone."
    "Sobs tore free before she could stop them. She dropped to her knees, the knife clattering against the cobblestones. Only the mist remained, curling close, cold against her skin, whispering with every shift of the wind."

    scene bg village_lane_fog with dissolve
    show fog
    show vignette
    mim "Amanda…"
    "The voice came broken, muffled through sobs. It cut through the fog like a thread, trembling and fragile. The whimpers came again, closer now — the sound of someone crumpled and weeping into their hands. She followed, each step hesitant."
    show mimic janet at center with dissolve
    "A figure crouched against the wall of a house, folded in on itself, shoulders shaking. Through the mist it was unmistakable: the dark fall of hair, the curve of the back, the voice that carried her name like a prayer."
    mim "Amanda…"
    am "Janet? Is that you? Oh God — are you hurt?"
    "She moved closer, step by step, every instinct warring against the urge to run. Something felt wrong. The sobs didn't sound natural. Too long between breaths, too steady, almost as if rehearsed. She froze a few feet away."
    am "Janet?"
    "Sharper, this time. The whimper answered back. But this time it broke — stretched, distorted, as though funneled through a rusted machine."
    stop music fadeout 1.0
    mim "Am…annn…daaa…"
    "Her stomach dropped. The sound wasn't human anymore. She staggered back a step. Her pulse hammered in her ears, louder than the waves crashing somewhere beyond the mist."

    scene cg what_wore_janet with dissolve_slow
    window hide
    pause 2.0
    window auto
    "The figure shifted. Slowly. Too slowly. Its shoulders pulled unnaturally high, its spine arching as though something inside was pushing outward. A wet crack echoed as joints stretched, bones jerking against the limits of flesh."
    "It rose, uncoiling into the fog, taller than it had any right to be. Skin pulled tight over a frame that looked unfinished, translucent and thin, veins glowing faintly beneath. The mist itself seemed to seep from its pores, thin streams curling into the air."
    "Her knife trembled in her grip. The head lifted."
    play sound sting_reveal
    call mature_show("mimic_face")
    "The face — if it could be called that — was a grotesque parody of Janet's. The jaw hung too low, stretched wide as though the ligaments had rotted away. Teeth jutted crookedly, yellow and wet."
    "The eyes glowed faintly from hollow sockets, catching just enough of the beam to reflect something alive. Something aware."
    call mature_hide
    play music m_judgment fadein 2.0
    "It inhaled, and her lungs seized. The air itself turned heavy, acrid, poisoned. Her chest burned as if she'd swallowed smoke. She stumbled back, choking, her body screaming for oxygen that wasn't there."

    scene bg village_lane_fog with dissolve
    show fog
    show vignette
    show mimic true at center with dissolve
    "The thing tilted its head, jerky, insect-like. Its chest hitched, and from its gaping throat came the mimicry again."
    mim "Amaaanda…"
    "This time the voice was perfect. Janet's tone, Janet's rhythm. For a fleeting instant her knees buckled, her heart begging her to believe. Then the sound broke apart, warping into a guttural growl, a vibration that rattled her bones."
    "It stepped forward, jerky, unstable. Its limbs were too long, arms dangling past its knees, fingers twitching and curling as if they couldn't decide what to grab first."
    "Her vision blurred at the edges from the suffocating fumes, the fog tightening like a noose. The realization sank like ice into her stomach."
    "The mist wasn't natural."
    "It was this thing."
    $ note("The mist wasn't natural. It was this thing.")
    "Every exhale poured another ribbon of haze into the air, spreading outward, choking the world around it. Her light flickered across its chest — wasted, sunken, skin flaking like parchment. Its body was collapsing even as it stood."
    "She couldn't move. Her legs wouldn't obey. Her eyes were locked on the thing as it leaned closer, its jaw stretching wider, as though her name had split it apart from the inside."
    mim "Amaaandaaaaa…"
    "The sound twisted into a shriek, layered — human and not, Janet's voice over something deeper, something primal. She clutched her ears, staggering backward. Her boot slipped on the wet stone. The knife clattered before she scooped it back up. Every breath was a fight."
    show mimic true at center, tremble
    "The creature lurched toward her, its legs jerking like a marionette. Its shadow stretched long in her light, distorted, massive. Tears streaked her face. She whispered her sister's name once more — not as a question this time, but as a prayer."
    "It bent low, close enough that the suffocating heat of its breath washed over her. Its teeth gnashed, crooked rows clacking together. The thing that wore Janet's voice unspooled its ruined body toward her, reaching."

    play music m_route_nine fadein 0.5
    with hpunch
    "The claws slashed, and she barely threw herself aside, boots skidding on slick stone. Her breath tore through her throat, eyes wild — and in that desperate surge, she drove forward."
    "Her knife cut across the mist, a flash of steel, and she plunged it hard into the creature's chest. The impact jolted through her arm, a deep, sickening resistance as the blade tore through thin flesh and brittle bone."
    "She screamed with it, a raw, animal cry, and stabbed again, twisting the handle with manic force. The creature bent forward under the blow, its massive frame folding in, lowering toward her as though in submission."
    ath "It's working. It has to work."
    "She struck again, stabbing and pulling, the hilt slick against her palm. The sound was obscene — wet tearing, bone scraping."
    "But the thing didn't falter. It didn't scream. Didn't even stagger."
    "It remained utterly still, letting her rage bury the knife deep into its chest, until finally she froze, her lungs burning, her muscles trembling from the frenzy. The knife stayed lodged in its flesh, sunk to the hilt, quivering with the rise and fall of its unnatural chest."
    "She stumbled back a step, her hand empty now, blood — or something darker — smeared across her skin. She looked up, forcing herself to see what she had done."
    stop music fadeout 1.5
    "The creature's head lowered slowly, its posture unfolding until its hollow eyes locked onto hers. The mist curled between them, thick and choking."
    "And then it smiled."
    "A grin split its face, jaw unhinging too wide, teeth crooked and glistening. It stretched farther and farther, grotesque, impossibly wide, until the expression mocked the very idea of human joy."
    "Her entire body went rigid, legs rooted to the cobblestones. Her heart slammed in her chest, but it no longer felt like her own — more like something the creature toyed with, beat by beat."
    "That grin wasn't pain. It wasn't defeat. It was amusement."
    "Her attack meant nothing. Her defiance meant nothing. She was an insect, waving a tiny blade at a god that had failed to become divine."
    "Her lips parted as though to scream, but no sound came. She could only stare into that cavernous smile, her reflection tiny in the black void of its hollow eyes. The knife handle stuck out from its chest, absurd now, like a child's toy lodged in stone."
    "It leaned closer, bringing its grinning face down until it hovered just above hers. Each exhale laced with the mist that made her vision swim. The grin widened, splitting almost to the ears. The world narrowed to that grin. That awful, mocking grin."
    "Fear screamed through every nerve, telling her this was the end. There was no escape. But survival had never been quiet inside her. It burned now, a flicker in the haze, demanding she move. Her eyes darted sideways — a gap between two stone houses, swallowed in fog."
    with hpunch
    "Her knee shot up, slamming into the creature's wasted ribcage. The sound was a brittle crack, hollow, like branches snapping. It didn't hurt the thing — but it startled it. In that blink of stillness she tore backward, boots skidding, then launched herself into the fog."
    hide mimic with dissolve

    scene bg village_square_fog with dissolve
    show fog
    show vignette
    play music m_judgment fadein 1.0
    "Her feet hammered the cobblestones, blood pounding in her ears. The mist thickened around her, swallowing her light, turning every step into blind hope. She didn't look back. She couldn't."
    "Her lungs seared. Her wounded arm throbbed violently, the soaked towel dragging heavier with every drop."
    "And then — a sound behind her. Not the scrape of claws. Not the rumble of pursuit."
    "A wet, sickening pop as the knife slid free. Her heart lurched. She risked a glance over her shoulder."
    show mimic true at far_left, dimmed with dissolve
    "The creature had not chased her. It stood, tall and bent in the mist, one grotesquely long hand curled around the knife she'd left buried in its chest. Slowly, deliberately, it drew it out, holding it delicately between two fingers like a surgeon examining an instrument."
    "Her blood dripped from its edge. She stumbled to a halt, eyes wide, her body trembling with exhaustion and terror."
    "The creature tilted its head. And then, with a suddenness that shattered the fog — it moved. Its arm snapped forward, straight and precise, like a gunshot."

    stop music
    scene black with flash_red
    play sound sfx_thud
    "The knife whistled through the mist, a black streak too fast for her to react."
    "It struck."
    play sound sfx_tinnitus
    "The blade drove into her right shoulder with the force of a hammer blow, the impact hurling her forward. She staggered, half airborne, before crashing to the stones. A scream tore out of her throat, sharp and guttural. Tears burst from her eyes, streaking hot down her face."
    "The pain was blinding — white and electric, burning through every nerve. Her hand flailed back, clutching at the wound, but there was no time. No thought beyond one single command pulsing in her skull."
    ath "Run."

    scene bg village_square_fog with fade
    show fog
    show vignette
    play music m_judgment fadein 2.0
    "She dragged herself upright with a sob, legs trembling, blood soaking warm down her chest and side. Her vision blurred, her head swam — but her body moved anyway."
    "Every step was agony, her right arm hanging useless at her side, the knife still embedded deep. The handle jutted from her shoulder, every movement sending new shocks of pain ripping through her chest. But she didn't stop. She couldn't."
    "Behind her, silence. The creature hadn't followed."
    "It stood in the mist where she had left it, tall and unbroken, its grin carved impossibly wide. Those hollow, glowing eyes watched her retreat — not chasing, not rushing, only observing. A predator amused by its prey's desperate scramble."
    $ note("It wore Janet's voice. Perfectly. A knife in its chest did nothing.")
    "Her legs buckled with every stride. The mist pressed tighter, twisting the streets into endless shapes. Her body screamed to collapse — but the thought of that grin behind her kept her moving."
    "Through the fog, a break appeared. A small garden gate, its metal frame ajar. No growls. No barking. Just silence."

    scene bg garden_yard with dissolve
    show fog
    show vignette
    "Without thinking she veered sharply and shoved the gate open. It groaned faintly but didn't resist. She staggered inside, stumbling past the fence as though crossing into another world."
    "The air felt heavier in the enclosed yard, the mist still curling across the ground, but the faint sense of barrier steadied her. At least for a moment, she was hidden."
    play sound sfx_thud
    "Her knees buckled, but she forced herself upright again, clutching the wound with her free hand. The gate swung shut behind her with a hollow clang."
    "She pressed her back to the wall of the garden, her body soaked with blood and rain. She closed her eyes, fighting the blur of dizziness, forcing breath back into her lungs."
    "The creature's grin still burned in her mind."

    stop music fadeout 3.0
    jump ch10
