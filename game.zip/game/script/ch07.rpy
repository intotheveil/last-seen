## Chapter 7 — "Welcome Home"
## Source: docs/manuscript/ch04.txt l.389–501 (Janet POV) + ch05.txt l.3–58 (Amanda POV).
## Rulings applied: #7 (Markus's car, not Janet's), #9 (the father's "The road has led you true…"
## exchange plays once), #10 (afternoon, not dusk; Amanda takes the call in the early afternoon),
## #14 (the hearth symbol is a crude hand-painted Key of Hecate — described, never named).
## Beats 16 (the drink, STANDARD) and 17 (the collapse, CG janet_falls then black).

label ch07:
    call chapter_card(7, "Driftwood Bay — late afternoon")

    ## — Janet —
    scene bg parents_gate with fade_slow
    play ambient sfx_wind fadein 2.0
    play music m_markou fadein 2.0
    call place("Driftwood Bay — afternoon")
    show markus neutral at right with dissolve

    "The street narrowed, the houses leaning close, until Markus stopped before a tall iron gate — paint flaked to rust, hinges whining. Beyond lay a two-story house of stone, its shutters drawn tight against the pale afternoon."
    "Janet followed him up the gravel path. A lantern flickered to life above the door as they approached, though she hadn't seen anyone light it. Markus lifted the knocker. Before it struck, the door opened inward."
    show mother smile at left with dissolve
    "An older woman: gray hair pulled beneath a scarf, eyes like wet stones. She smiled too quickly, lips stretched as if in anticipation rather than welcome. Her gaze slid over Markus as though he were incidental, and fixed on Janet."
    mmo "You've brought her."
    jn "Hello. I'm—"
    mmo "We know who you are."
    jn "It's nice to meet you."
    "Heat crept up Janet's neck. The woman's mouth curved, but no name came in return."
    mmo "Come in, child. You must be tired from the road."

    scene bg parents_hall with dissolve
    show mother smile at left
    show markus neutral at right
    "Inside, the air was thick with herbs and dust. The walls were crowded with photographs — generations of faces in the same stone doorway, the same fixed gravity in every eye. Janet brushed a frame and shivered. The glass seemed warm."
    mmo "Father is waiting."

    scene bg parents_sitting with dissolve
    show father neutral at center with dissolve
    show mother smile at left
    show markus neutral at right
    "A man rose from a chair by the hearth — broad shoulders, thinning hair, a presence that filled the space. He did not greet his son. His eyes went straight to Janet."
    play sound sting_word
    mfa "Welcome home."
    "Not welcome here. Welcome home."
    jn "Thank you. It's a beautiful village. I'm Janet."
    "The man's smile tugged upward, though it never touched his eyes."
    mfa "Yes. Beautiful. And you… you're exactly as we hoped."
    mk "Father—"
    mfa "The road has led you true. You'll bring us what we've waited for."
    jn "I'm not sure I understand…"
    "The woman's hand closed over Janet's arm with surprising firmness. Cool skin, fingers digging just enough to remind her of restraint."
    mmo "Rest now. Everything else will come in its time."
    "Her grip lingered too long before sliding away. Janet wanted to rub the ghost of those fingers off her arm. She stayed still and smiled — brittle, breaking — because what else could she do?"
    mk "They're just… old-fashioned. Don't mind the words."
    "But Janet did mind. The way they looked at her — not as Markus's girlfriend, not even as a guest — but as if she were already theirs. Already promised to something she didn't want to know."
    "When she sat, both parents remained standing, watching in silence, eyes shining with a strange, fevered pride. Then his mother walked to another room. Janet looked at her phone. No signal."
    hide mother with dissolve

    ## the drink
    "The room smelled of old varnish and something faintly metallic, like coins left too long in a damp pocket. Markus's mother returned with a tray: porcelain cups, a pot that steamed too sweet, hard biscuits stacked in neat rows."
    show mother smile at left with dissolve
    "Janet sat on the edge of the sofa, bag clutched against her hip. Markus leaned back beside her, easy. His parents stayed upright, flanking the hearth as though the chairs weren't meant for them."
    mmo "Please. Drink. It steadies the nerves."
    "The china felt warm, hotter than it should. The liquid was dark, not quite coffee, not quite tea, heavy with herbs she couldn't place. The father lowered himself into the armchair opposite her at last, knees cracking, eyes never leaving her."
    jn "Thank you."
    mfa "It has been a long road. Roads are always long before they bring you where you must go."
    jn "The drive wasn't so bad. Markus did all the work."
    "Neither parent looked at Markus. Their gazes pinned her, patient and unblinking. She sipped. Bitterness coated her tongue, followed by a sweetness that clung to her throat — something that wanted to stay inside."
    mmo "Do you like it?"
    jn "It's… different."
    mmo "Different is good."

    stop music fadeout 2.0
    play music m_alice fadein 3.0
    "She took a second sip, small, cautious. Bitter again, then that faint sweetness like licorice and ash, clinging long after she set the cup back down. Not coffee, not tea, nothing she'd ever had in the city cafés with her roommates."
    jth "Don't be rude. You're the guest. Smile. Be gracious."
    "Markus's father hadn't moved: elbows on his knees, thick fingers laced, eyes fixed on her face. His mother stood to one side of the hearth, hands folded over her apron, that smile still plastered on as if sewn into place."
    "And their cups… The porcelain sat before them, steam curling upward, untouched. Full. Not one sip. Not one casual lift of the hand. Markus's cup, too, sat untouched at his elbow."
    "Janet's stomach dropped a fraction. The realization settled like a stone: she was the only one drinking."
    jth "They poured it for me. Only me."
    "Her first instinct was to laugh at herself. Maybe they'd already had theirs. Maybe they didn't drink in the afternoon. But the longer she sat, the clearer it became: the cups weren't hospitality. They were for show."

    menu:
        "Look at Markus. Just once.":
            "She looked. He leaned back, expression carefully neutral — but his hands rubbed against his knees, restless, like a man waiting for something he didn't want to arrive. He didn't look back."
        "Don't look at him. Don't plead.":
            "She fought the urge to glance toward Markus, to beg silently for reassurance. From the corner of her eye she saw his hands rubbing his knees. Restless. Waiting."

    "The silence thickened. She looked around for distraction. Bare stone walls, flaking to show mortar lines like scars. A mantle with no photos, no mementos — just a bowl of acrid dried herbs, and above them, painted directly onto the wall, a symbol."
    "A circle, drawn crudely, maybe with coal. A child's scrawl — until she saw the details. Three intersecting lines inside, each curling at the ends into hooked shapes, like roots or claws. Around the circle, faint repeated marks: triangles, spirals, small knife-sharp scratches."
    jth "Why would anyone draw on their wall? Why leave it there for guests to see?"
    "She forced herself to look away. No photographs. No paintings. No warmth. Just the symbol, watching from above the hearth like a black eye."
    jth "Say something. Small talk. Break this stare before it eats you alive."
    jn "Your house is… very traditional."
    mfa "It has always been so."
    "The mother's smile widened a fraction. Then the silence spread again: the hiss of the kettle cooling, a crack of wood in the hearth. Her throat itched with the aftertaste of the drink. She needed air."
    jn "Excuse me. I should just… call my sister. She'll worry if I don't check in."
    "No one moved. No one answered. The father's eyes narrowed slightly, but his smile never broke. The mother stood perfectly still, as though she hadn't heard. Markus looked as though he wanted to interject, and didn't."
    "Janet stood anyway, bag tight against her hip, and pulled her phone free, holding it like a weapon."
    jth "Please, please work this time."
    "The screen lit. One bar. She typed quickly."
    note_voice "At Markus's family house. Strange vibe. Please call later."
    "Send. The bar vanished. Message Failed. She tried again, faster, as if speed would trick the signal into staying. Failed. She pressed Call. Amanda's name glowed. The ring stuttered once, then cut to silence."
    jn "Damn it."
    "Markus's mother didn't look up: straight-backed, hands folded, eyes lowered to a point on the rug. The father stared past them both at the hearth, jaw set, like a man listening for a sound only he could hear."
    jn "I left my purse in the car. And I could use some air."
    "Markus's gaze flicked to his parents, then back to her. The smile he gave her was practiced and soft."
    mk "Of course. Come on. It's cooler outside."
    "The mother's fingers tightened once — an almost invisible tremor — and stilled. The father didn't blink. No goodbye, no nod. They could have been carved from salt."
    hide father with dissolve
    hide mother with dissolve

    ## the lane

    scene bg village_lane_day with dissolve
    show markus neutral at right
    stop music fadeout 2.0
    play music m_greyvale fadein 2.0
    "He opened the door, and a tired wash of flat afternoon light fell into the room. Behind them the hush felt arranged rather than natural. When Markus pulled the door closed, the latch clicked with a strangely final sound."
    "The lane pressed close on either side, plaster stained by wind and salt, shutters half-closed like sleepy eyelids. Somewhere a gull cried once and fell silent. The village seemed to be holding its breath."
    jn "I'm… sorry. I probably wasn't very polite in there."
    mk "You were fine. They're not big talkers."
    "His voice had a cool evenness to it, like a corridor with no echoes."
    jn "That's one way to put it."
    mk "They're old. Old village. They take a while to warm up to anyone from outside. Don't take it personally."
    jn "They didn't even warm up to you. Not like… parents."
    mk "You grow up here, you learn different languages. Words aren't always one of them."
    "A breeze slid along the lane, not cold exactly, but dense — like air that had already been breathed and set back down. Janet caught a faint metallic tang at the back of her throat."
    "Her legs felt fine, but the world had shifted a half step out of place. Maybe the quiet. Maybe the way the light had turned the color of weak tea."
    jn "Your mom was… praying?"
    mk "Muttering. She does that when she's tired."
    mk "We'll grab your purse. Then I'll walk you to the square. Get you a bottle of water, whatever you want."
    jn "That would be good."
    "Her tongue felt dry. The lane opened into a wider stretch: hills beyond the rooftops and, farther still, a pale seam of water. No voices. No playing children. An old curtain stirred in a cracked window and went still."
    jn "You grew up here."
    mk "For a while. Enough to know where not to step."
    jn "And where not to look?"
    mk "For some people."

    scene bg lane_silver_car with dissolve
    show markus neutral at right
    "There was the car, exactly where they'd left it — silver under a film of road dust, parked close to a low wall, overgrown rosemary brushing the wheel well. Relief crept up Janet's spine in a small wave. Something normal."
    mk "Go ahead. I'll give you a minute."
    "The handle stuck, then gave. She leaned in: the leather of Markus's seats, a ghost of the morning's coffee, the rubber tang of floor mats. Her purse sat on the passenger seat where she'd left it, the strap looped like a lazy snake."
    "She straightened up. The air pressed a fraction heavier. Markus stood by the hood now, facing the lane, hands in his pockets, weight easy in his heels like a man untroubled by weather. He asked without turning."
    mk "You all right?"
    jn "Yeah. Just… need to call my sister."
    mk "Of course."
    stop music fadeout 2.0
    stop ambient fadeout 2.0
    show screen phone_call("Amanda")
    "Janet's thumb pressed call. For a heartbeat, a line opened — static, and Amanda's voice breaking through."
    phone "Janet?"
    hide screen phone_call
    scene cg janet_falls with dissolve_slow
    window hide
    pause 2.0
    window auto
    "Relief surged — and then everything went black."
    play sound sfx_thud
    "The phone slid from her hand as her body gave way, crumpling against the stones. No warning, no struggle. One instant awake, the next swallowed whole by silence."
    scene black with fade
    pause 1.5

    ## — Amanda —
    scene bg amanda_living with fade_slow
    play music m_records fadein 2.0
    call place("The city — early afternoon")
    "Amanda was halfway through tracing another clean line across the digital floor plan when her phone buzzed beside the keyboard. Janet's name. Her chest loosened — she hadn't heard from her sister all morning. She swiped the call immediately."
    play sound sfx_phone
    show screen phone_call("Janet")
    am "Hey, finally—"
    play sound sfx_thud
    "Her words collided with a sharp clatter in her ear. A blunt sound, hollow and quick, like a phone striking the ground. Silence."
    am "Janet?"
    "She pressed the phone harder against her ear, straining for a voice, a laugh, anything that might explain the sound away. Nothing came. Then, with a dull click, the call cut off."
    play sound sfx_beep
    hide screen phone_call
    "Her heart thudded once, painfully loud. Her hands were already fumbling to redial. Straight to voicemail. Once. Twice. Again. Janet's recorded voice, cheerful, detached, and then the beep."
    am "Shit."
    "She bit hard on her lower lip, pulse climbing too fast. She tugged the headphones from her ears and dropped them on the desk; the silence of the apartment pressed in."
    ath "Think. Don't panic."
    note_voice "Hey, you okay? Call me back."
    "The gray delivery wheel spun, then halted. Not delivered. She set the phone down with deliberate care, as though roughness might make things worse, and began to pace — desk to sofa to kitchen counter and back, tasting old lipstick rubbed raw from her lip."
    $ note("Hey, you okay? Call me back. — Not delivered.")
    ath "Battery. Or signal. She's traveling. It could be anything."
    "But Janet wasn't careless. She wasn't the type to vanish without a word. Amanda checked the clock. Early afternoon. Too early to imagine the worst. She would wait a couple of hours; Janet would see the calls and laugh at her for overreacting."
    "Still, the phantom echo of that clatter kept replaying, looping in rhythm with her footsteps. Back at the desk, no music, no headphones — only the hum of the refrigerator and the phone face-up beside the keyboard. Every imagined vibration sent her eyes darting to it."
    "The hours dragged. She walked to the market just to burn minutes. Back home, less than two hours had passed. No call. No message. Janet always answered; even busy, she found a second for a text. This silence was wrong."
    "Again voicemail. She dropped the phone on the counter, louder than she intended."

    menu:
        "Janet. One more time.":
            "Her thumb found Janet's name again before she could stop it. The cheerful recorded voice. The beep. She hung up before it finished."
            am "Okay. I'll call Markus."
        "Markus.":
            am "Okay. I'll call Markus."

    play sound sfx_beep
    "His line rang out normally — no voicemail wall this time. She held her breath. No answer. Again: ringing, a beat of silence, then a dull beep-beep-beep. Busy tone. A third time, and straight to voicemail."
    am "Goddammit."
    "She hurled the phone onto the sofa hard enough she thought she'd cracked it. Her lip stung; she tasted iron. Her hands were shaking. She was losing control of the situation. She scrolled to Lara, one of Janet's roommates, and breathed before pressing call."
    play sound sfx_phone
    show screen phone_call("Lara")
    la "Hey, Amanda."
    am "Hi, Lara. Sorry to bother you. I just wanted to ask — do you remember what time Janet left this morning?"
    la "Um… Yeah, around nine, maybe a little earlier. Why?"
    am "Nothing serious. I just… haven't been able to reach her. Probably bad reception where she is."
    la "Everything okay?"
    am "Yes. Don't worry about it. Thanks for letting me know. I'll catch her later."
    la "Oh. Sure. No problem."
    hide screen phone_call
    $ note("Lara: Janet left around nine.")
    "Amanda ended the call before Lara could ask more, and opened Maps. The name Markus had mentioned: Driftwood Bay. The route blinked to life. From the city to the village: three hours by car."
    $ note("Driftwood Bay — three hours.")
    "Her stomach twisted. Early afternoon when Janet had called. If she'd left around nine, she had been there for hours already. The dropped call. Markus dodging her. The silence that stretched too far."
    ath "Something is wrong."
    ath "Enough."
    "She shoved the phone into her bag, pulled on the coat from the back of the sofa in one practiced motion, and closed her hand around the car keys, the metal sharp and cool against her palm."
    "For a moment she hovered by the door. Impulsive, dramatic, she told herself. Then she remembered the clatter. The silence afterward. Markus's evasive calls."
    ath "No. I can't sit still anymore."

    scene bg apt_corridor with dissolve
    "The corridor air was close, stagnant, the old fluorescents buzzing. Her heels struck the linoleum in brisk, clipped beats. The elevator doors dragged open, their reflection catching the hard line of her mouth."
    scene bg amanda_car_day with dissolve
    play ambient2 sfx_engine fadein 2.0
    stop music fadeout 1.0
    play music m_snow_road fadein 2.0
    "Out through the glass doors into the churn of city sound, shoulders squared, as though nothing could slow her now. The fob clicked; her car blinked in answer. Leather and faint coffee grounded her for exactly one second. Then her hands gripped the wheel, knuckles pale."
    ath "Straight through, maybe less than three hours. I can be in Driftwood Bay by evening."

    jump ch08
