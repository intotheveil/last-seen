## Chapter 16 — "The Circle Held"
## Source: docs/manuscript/ch08.txt l.424–469 (Amanda POV: the stab, the birth, the Fruit, her death)
## + ch09.txt l.3–47 (Janet POV: the apotheosis, the circle; then the epilogue). Beats 55–65.
## The stab (55) and the birth (56) open as BLACK FRAME + SOUND; 63 is black frame from Janet's POV.
label ch16:
    call chapter_card(16, "The Tree — after")

    scene black
    play ambient sfx_storm fadein 1.0
    play sound sfx_tinnitus
    "White-hot pain exploded in Amanda's belly. The blade punched through coat and shirt, through skin and muscle, deep into her lower abdomen just below the navel. It sank to the hilt. Her scream tore through the night, raw and primal."
    "For one awful second he left it buried in her, twisting it, just enough to wring another scream from her throat."
    "Janet's shriek answered it — a howling that echoed into the trees. She thrashed so violently that blood ran fresh from her wrists, and the gag tore loose and hung useless at her throat."
    call mature_show("stab_wound")
    "Then he yanked the blade out. A gout of blood followed, hot and thick. A strangled moan escaped her. The pain radiated outward in nauseating pulses; warm wetness spilled over her sides and into the earth, and the edges of her vision dimmed."
    ath "This is it. I'm going to die here."
    "Janet's face was a blur of anguish beyond Markus's shoulder. Amanda tried to speak — to say she was sorry, to say I love you — and only a wet gurgle came out. Copper filled her mouth."
    call mature_hide
    play sound sfx_heartbeat
    "But amid the agony, the instant the knife pierced her womb, the thing inside her jolted awake — a bomb going off in her core, not fire but motion. Coiled in her depths, it unraveled; tendrils whipped toward the opening in her flesh. Cold flooded her veins."
    "Markus raised the bloodied knife to strike again, to carve upward — and hesitated, confusion wrinkling his brow. He had felt it too. Beneath him her body convulsed, and from the wound something was emerging."
    "Hands. First one, then another, claw-like and bony, slick with her blood, grasping the edges of the wound and widening it with a sickening rip. Her scream choked off as wave upon wave of numbing cold rushed out from the injury. The pain was still there, but far away."
    call mature_show("the_birth")
    "Dark smoke billowed from her, carrying the stench of rot and ozone. It poured over her torso and over Markus's hands, and he snatched them back with a curse and stumbled off her."
    mk "What— what is this?!"
    "She watched in half-conscious horror as it pulled itself out of her. A forearm. A shoulder. The ridge of a hunched back. Then the head — misshapen, skull-like, and somehow smiling — and the hollow, lambent eyes that locked at once onto Markus."
    mk "No… {i}NO!{/i}"
    "The chanting faltered and died. Cultists crossed themselves or fell flat in terror. They knew what this was — an abomination freed of chains — and it was beyond any of their plans."
    "It finished leaving her with a wet slither. An awful emptiness yawned inside her. She was vaguely aware of Janet shrieking her name, of her own hands pressing weakly at her belly, of warm stickiness everywhere."
    call mature_hide

    scene bg tree_clearing_ritual with dissolve
    show rain
    show vignette red
    show abomination free at center with dissolve
    play music m_route_nine fadein 2.0

    "Her fading mind was drawn upward — to the creature that now stood over her, half-crouched on the roots, smoke still pouring off it and hiding what it had left behind."
    "It was smaller than in the chamber — six feet, not eight or nine — as if part of it still stayed coiled in her, joined to her in some way she had no words for. Tatters of membrane clung to its limbs. Her mind gibbered at what that meant."
    show markus ritual at left with dissolve
    "It stretched, vertebrae cracking. Its sunken, glowing eyes never left Markus. And Markus, for once, looked truly afraid. He darted a glance around the ring, dragging composure back by sheer will."
    mk ritual "Stop! Stand your ground!"
    "It answered not with words but with action. Quicker than eyes could follow, one spindly arm lashed out and plucked the Fruit straight off the bough; it skittered backward up the trunk and crouched on an outcrop of roots, the Fruit cradled in its claws like a heart."
    mk "No!"
    "He abandoned the incantation mid-verse and lunged for the Tree. True panic set in; without the Fruit there was no seed to plant in Janet or anywhere. Everything was unraveling."
    "The abomination tilted its head at him and grinned wider. Black drool fell from its jaws onto Amanda below. It began to squeeze, and the Fruit answered with a grotesque wet sound, cracks splitting its skin, oozing red-black sap."
    mk ritual "{i}GIVE IT BACK!{/i} I command you!"
    "His voice cracked. He clawed at the roots, trying to climb, the dagger still white-knuckled in one fist."
    "Two acolytes — the bravest, or the most fanatical — finally rushed to their master, one with a torch, one with a curved blade. They splashed through the circle and reached for the roots."
    "They never got far. With a guttural, many-throated hiss the abomination breathed out a plume of black vapor. It struck the torch-bearer full in the face; he went down with a gurgle, the torch flying from his hand."
    play sound sfx_thud
    "The second skidded, backpedaled — and the creature was on her, a blur of darkness. They hit the ground with a crunch. When it rose again, she did not. The rest broke; fervor shattered into self-preservation, and they scattered into the trees. All pretense of ritual was gone."
    stop ambient2 fadeout 1.0
    "Markus hardly noticed. His eyes were on the Fruit — dropped when the creature pounced, lying a few feet from Amanda's twitching hand, half-sunk in mud and glowing faintly from within."
    "He charged for it — if he could just retrieve it, force it down Janet's throat himself, without the full ceremony — and the abomination was simply there, in his path, silent as a thought. Its hollow eyes burned. A rattling, clicking laugh came up out of it."
    "Markus skidded to a halt, spattering mud. He gripped the dagger in both hands, chest heaving, rain washing the blood from his wounds. And then, instead of faltering, he advanced. One step. Another. Boots sinking in the sodden earth."
    "The creature hunched low, claws gouging the mud, pure predator. Then, faster than thought, it struck — a blow that should have ripped him in half."
    "Markus only tilted his head. He wove between the claws as if the world bent to let him through. The strike passed so close the air singed, black ichor spraying across his coat — and he walked on, unscathed."
    mk ritual "You can't hurt me. You worm of existence…"
    "Low, trembling, somewhere between rapture and fury; his lips pulled into a grim smile."
    "The dagger pulsed in his grip, red light racing down the curve. His own veins answered — black streaks crawling across his neck, his face, his arms, beating in time with his heart. He looked less a man now than a vessel, half-formed into something else."
    "For years he had fed on the blood of chained horrors. Now, at the pinnacle of the ritual, the change was peaking — precisely as he had calculated. His voice steadied, as if the storm itself bent to hear him."
    mk "You thought I was prey… but I am your kin. Your master."
    "He kept walking, unafraid. The claws drew back. In the creature's face was a flicker of something alien — recognition, or hesitation. Amanda's deterioration was making it weak."

    stop music fadeout 4.0
    "Behind it, Amanda lay gasping, pushing herself with dwindling strength away from the melee. Every breath was knives through her lungs. Warmth spread beneath her — not warmth, she understood. Blood. Hers. Seeping into the mud."
    ath "I'm dying."
    "Not dramatic. Not panicked. The cold fact of a body giving out. She had minutes, maybe less."
    "Through the blur she saw Markus striding at the creature, dagger gleaming, veins lit black. The creature crouched, ready. Whichever of them prevailed no longer mattered; either would claim what lay between them."
    "Her gaze slid sideways and her heart clenched. Janet was still there, stretched against the Tree, screaming hoarsely, pulling until the skin split, and the iron held. No escape for her. No rescue Amanda could give."
    ath "I can't save her… I can't even stand."
    "And then she saw it. The Fruit."
    "It lay feet from her hand, half-sunk in mud, its skin swollen and throbbing with a pulse that was not its own. Each beat echoed through the ground, faster and heavier than her failing heart. It wanted to be taken. By Markus. By the abomination. By someone."
    "If either of them reached it, Janet was lost. The world was lost. She was powerless, broken, her life bleeding out into the earth. And yet the Fruit was right there. Her hand twitched toward it."
    "Her arm trembled as she dragged herself through the mud, fingers clawing. With a gasp that tore her chest, she closed her hand on the Fruit and pulled it in. Slick, fever-hot, quivering in her grip like living flesh."
    "She got up onto her knees, cradling it against her torn belly — and both of them froze, Markus and the monster, heads snapping toward her as if bound by one will. For the first time, predator and zealot ignored each other. All that existed was Amanda, with the Fruit in her hands."
    play sound sfx_heartbeat
    "Her mind began to unravel under its touch. Janet's screams dulled to silence; the thunder vanished; even the roar of her own wound ceased. There was only the pulse in her palms, faster and stronger than her own."
    "Throb. Throb. Throb. As though it was breathing her life away — or offering to lend its own."
    ath "I am dying… I don't want to die… maybe it can save me… maybe it will kill me faster."
    "She wanted desperately to live. To drag Janet away and see the dawn. And just as strongly she felt the pull of surrender, to let the darkness take her and end the pain. The Fruit pulsed louder, as if it alone would decide."
    "Amanda drew a final, rattling breath and raised the throbbing thing above the stones. Every vein in her body screamed against it. She summoned the last ember she had and hurled it down with all her will."
    "It never struck the ground."
    show abomination free at right with dissolve_fast
    show markus ritual at center with dissolve_fast
    "In the blink of an eye Markus was there, a blur of black veins and wet steel. His hand closed over the Fruit and wrenched it from her grasp as though she were no more than a child tugging at a man's cloak."
    "Behind him the abomination lowered itself, claws sinking into the mud, head bowed. It knelt — to Markus."
    "The sight struck her like a blade: the nightmare was his to command, and she had never been anything but a pawn. Yes, he was superior. Yes, he was better. Stronger."
    "Her strength gave way. The world pitched sideways as she fell, and through the narrowing tunnel of her sight she did not see Janet's chains, nor the creature's grin. Only Markus — towering, triumphant, a smile curving his lips as he looked down upon her death."
    "That was her last sight."

    scene black with fade_slow
    stop ambient fadeout 3.0
    window hide
    pause 2.5
    window auto

    ## — Janet —
    scene bg tree_clearing_ritual with fade_slow
    show rain
    show vignette
    play ambient sfx_rain fadein 2.0
    show markus ritual at center with dissolve
    show abomination free at right, dimmed with dissolve
    call place("The Tree — Janet")

    "Janet's sobs had turned dry. Her throat was raw, her eyes hollow. She could only watch as Markus raised the Fruit, its dark flesh splitting under his grip, and brought it to his mouth. The ceremonial dagger clattered into the mud at his feet, forgotten."
    "He bit deep, tearing into it with a fervor that made her stomach twist. Thick black-red pulp spilled over his chin as he devoured it whole."
    "With every swallow, Amanda's body blurred at the edge of her sight. Her sister's sacrifice cut deeper than any chain ever could. She wanted to scream again, and had no tears left, no breath left — only despair."
    play music m_nineteen fadein 3.0
    "Then Markus stilled. His head dropped forward, shoulders quaking, as though he were weeping. When he raised his face there was no grief in it. His eyes shone with a terrible radiance, burning from within like twin suns drowning in tar."
    show markus god with dissolve_slow
    "His veins bulged, glowing black and gold, spreading beneath his skin like a lattice of roots. The gashes across his ribs, the blood at his side — they sealed before her eyes, flesh knitting with obscene ease."
    "His breath fogged the air, and it was not human breath. It shimmered like incense smoke, sweet and cloying, almost holy."
    "The abomination, which had snarled and defied, crouched low at the Tree's roots, trembling in ecstasy. Its grin stretched impossibly wide, its ember eyes gleaming with awe. It recognized in Markus something greater than itself."
    "His form elongated. Skin pale as bone, veined with living shadow; features too perfect to be mortal, too calm to be sane. He radiated serenity and horror in equal measure, as though divinity had been dragged down into rotting flesh."
    stop ambient fadeout 4.0
    "The storm above went quiet, as if the sky itself bowed. He looked on them all — on Janet, on the kneeling monster — with a tranquil smile. In him was holiness and corruption, a calm that promised salvation and a terror that promised annihilation."
    "He was no longer a man. He was what he had always hungered to be: something eternal."
    stop music fadeout 2.0
    "His face was a mask of stillness as he turned to the abomination. For a heartbeat nothing moved — rain suspended in the air, thunder caught in its throat, the world itself waiting. Then came his voice."
    "It was not human. It was not sound. It was the resonance of stone and sea, of root and flame. Even chained, Janet felt it vibrate in her marrow, a note that made her teeth ache and her lungs seize."
    mk god "You disgust me. Disintegrate now."
    play sound sfx_tinnitus
    hide abomination with dissolve_fast
    "The words became reality. The creature convulsed, its grin frozen in shock as cracks tore through it. In the span of a blink it shattered — fragments, then motes of ash, then dust finer than smoke."
    "Each division faster than the last, until nothing was left. No claw. No ember eye. Not even a shadow. In less than a second the nightmare that had stalked them all was simply gone, erased as though it had never existed."
    "Janet stared through the silence. Her chains rattled faintly with her trembling. Markus had not moved an inch. He only stood there, calm and radiant, as if unmaking a god were as effortless as breathing."
    "His gaze swept to the few cultists who still lingered, too broken or too enthralled to run. Their fear turned instantly to devotion; they fell to their knees in the mud, wailing praises in a fevered chorus."
    cu "Chosen one! Savior! Our god made flesh!"
    "He raised one hand, palm outward."
    mk god "Shhh…"

    scene black with fade
    "The command was soft. The effect was merciless. Their chanting cut off mid-breath, strangled, as blood welled in their throats. Something green and sickly bubbled past their lips in wet gurgles."
    play sound sfx_thud
    "Their eyes rolled back, and one by one they toppled forward into the mud, twitching as life left them. The storm swallowed their bodies without ceremony."

    scene bg tree_clearing_ritual with dissolve
    show rain
    show vignette
    show markus god at center with dissolve
    "Janet didn't scream. She didn't even breathe. She pressed herself into the cold bark of the Tree, every fiber of her body begging to be unseen, unnoticed — to dissolve into the shadows."
    jth "Please, don't look at me. Please, don't see me."
    "But his gaze had already dropped to the ground at his feet. To Amanda, lying limp in the muck. With the same indifference a child might have toward a ruined doll, he bent and seized her by the arm. Her body hung from his grip, head lolling, rain streaking her lifeless face."

    scene black with fade
    "Janet shut her eyes. She could not shut her ears."
    call mature_show("the_bite")
    "He drew the body close and bit deep into the neck. Flesh tore with a sound that made Janet's stomach heave. He fed, jaw working with slow, deliberate relish."
    call mature_hide
    play sound sfx_thud
    "He ripped until something gave — one final crunch — and a soft, wet weight was tossed aside into the mud, casual as a fruit rind."

    scene cg circle_holds with dissolve_slow
    window hide
    pause 2.0
    window auto
    play ambient sfx_rain fadein 3.0
    play music m_forecourt fadein 3.0

    "He paced then, slow and thoughtful, circling beneath the Tree. His steps were unhurried, his expression unreadable, as though he were studying the clearing itself — absorbing it, mastering it."
    "And yet Janet sensed it: something unseen held him back. He was trapped here, confined, forbidden to leave. His power filled the night, but its borders were drawn tight around the Tree."
    "He walked with the poise of a sovereign inspecting his kingdom, and his strides carried a weight of irritation. His eyes swept the Tree, the chains biting into her flesh, Amanda's ruin — none of it held him. What finally drew his eye was underfoot."
    "The circle carved into the earth. Symbols glistened where the rain had not yet washed the blood away, their lines intact despite the chaos. The sigils hissed faintly, pulsing with a dull red light, roots of power threading into the soil."
    "Janet followed his gaze and understood, with a shiver."
    jth "It wasn't the Tree that confined him. It was the circle."
    "He halted at its edge, his face tightening ever so slightly. He raised his foot as if to step across — and the air there shimmered, resisting him. He smiled thinly and tested it again. The circle pushed back, a ripple of unseen force humming through the clearing."
    call cinematic("circle_rain")
    jth "He's bound."
    "That circle, drawn for the ritual, had become his prison. And Markus knew it. His jaw flexed as he studied each symbol, already calculating how to undo it."
    "Her chains rattled as she shifted, her wrists burning where the iron had bitten raw. She couldn't look away from him. His gaze was steady, unblinking, impossibly calm. The sky had gone hushed above them, as though even it bent to listen."

    menu:
        "He isn't going to hurt me.":
            "It dawned on her. Not now. Not out of mercy — Markus had never known that word — but because she was the only one left who mattered. The cultists dead or fled; Amanda a ruined heap in the mud. She was the last living witness. The last tool."
            "He needed her alive. She was the only one who could free him."
            "And as his eyes glowed with unearthly promise, she understood the other truth, just as cruel. He wasn't going to free her either."
        "He isn't going to free me.":
            "It dawned on her. She would remain bound, straining against the chains until her voice broke, her strength faded, her body starved. He would not spend a thought on it."
            "And as his eyes glowed with unearthly promise, she understood the other truth, just as cruel. He wasn't going to hurt her either. Not out of mercy — Markus had never known that word — but because she was the last living witness. The last tool."
            "He needed her alive. She was the only one who could free him."

    "A prisoner by iron. While he, a god remade, was a prisoner by blood-lines scrawled into the earth."
    "The irony clawed at her mind. A girl in chains, too weak to break them. A god in flesh, too mighty to be touched, held fast by nothing more than marks in the dirt. The universe had a taste for mockery, it seemed."
    "Markus smiled faintly, as if he shared her realization."
    mk god "Do you see it, Janet? Fate binds us both. But you… You can choose to end it."
    "His voice carried no anger. Only quiet satisfaction, serene and terrible."
    "Her breath shook in her chest. She knew what he meant — that she had only to stumble forward, only to smear her foot through the circle, and eternity would be his."
    "And if she didn't… then she would die here, shackled to the Tree, while he watched and waited, patient as stone, until the world brought him another chance."
    "Her nails dug into her palms. She wanted—"

    menu:
        "Scream at him.":
            "The scream rose as far as her chest and stopped there, as if her body had forgotten the rest of the way."
        "Curse him.":
            "The curse was on her tongue, every word of it. Her tongue would not move."
        "Say Amanda's name.":
            "{i}Amanda.{/i} Three syllables. She had said them ten thousand times. They would not come."

    "Instead, only silence filled her throat, and the weight of cosmic irony pressed down until she could hardly breathe."
    "The storm rumbled distantly, far away now, as though even the heavens had turned their faces. And Markus waited, still as a statue, eyes locked to hers."
    "Janet did not move. She did not scream. She only sat chained to the Tree, shivering in the cold, while Markus stood within the circle, radiant and calm, his inhuman eyes fixed upon her."
    "Neither spoke. Neither needed to. The truth lay heavy between them: she was too weak to break her bonds, and he was too strong to break his. A dying woman in chains. A god in flesh bound by lines in the dirt."
    "The rain fell harder, washing blood into the mud, hissing over the symbols at his feet. He did not flinch. He only watched her, and waited. And Janet, wishing herself invisible, wishing herself anything but alive, stared back — into eternity."
    "The storm rolled on. The circle held."
    "And Janet knew her time was slipping. She was injured, cold, her strength ebbing with every breath. The clock was ticking, whether she accepted it or not. Soon, she would see Amanda again — if not in this world, then in whatever came after."

    scene black with fade_long
    stop ambient fadeout 3.0
    window hide
    pause 2.0
    window auto

    ## — Epilogue —
    scene bg village_view_day with fade_slow
    call place("Driftwood Bay — days later")
    "Days later, the village was silent again, its streets washed clean by rain. The locals muttered behind shuttered windows, refusing to speak to the authorities who came asking questions."

    scene bg police_room with fade
    show lara worried at center with dissolve
    call place("The city — an interview room")
    "In the city, Lara sat before two tired detectives, her hands wrapped around a cold paper cup of coffee. She had been answering the same questions for hours. Her voice was hoarse, her eyes rimmed red."
    la "Yes. Markus and Janet left together. They drove down to the coast. That was the last time I spoke to her."
    "Her gaze drifted to the tabletop, unfocused."
    la "That was the last time… they were seen."
    det "What about her sister, Amanda?"
    la "I talked with her on the phone. She was worried too… She didn't tell me anything else."
    "The detective wrote something down, his pen scratching in the silence. Then he reached for a folder and stamped the front page with a dull thud."
    play sound sting_word
    note_voice "LAST SEEN."
    "The ink bled dark into the paper, stark and final. Lara didn't notice. In her mind's eye she saw Amanda's weary smile, Janet's nervous laugh — fragments of two women who had vanished into fog and whispers."
    "No bodies. No trace. Just absence."
    hide lara with dissolve
    scene black with fade_slow
    "Somewhere far from that sterile room, beneath a storm-twisted Tree and a circle still humming with power, eternity held its breath."
    jump ending

label ending:
    scene black with fade_long
    stop ambient fadeout 2.0
    play music m_theme fadein 4.0
    centered "{size=+24}LAST SEEN{/size}"
    centered "Adapted from the novel by A. Damon"
    centered "Art generated for this adaptation"
    centered "{i}Last seen.{/i}"
    $ persistent.finished = True
    return
