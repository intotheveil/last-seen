## Chapter 15 — "The Last Ingredient"
## Source: docs/manuscript/ch08.txt l.357–423. Amanda POV. Ends on the dagger coming down (the deliberate
## cliffhanger cut); the stab itself opens ch16 as a black frame. Beats 51–55 (horror_beats.md).
label ch15:
    call chapter_card(15, "The Tree — thirty torches")

    scene bg tree_clearing_ritual with fade_slow
    show rain
    show vignette
    play ambient sfx_storm fadein 2.0
    play ambient2 sfx_crowd fadein 3.0
    play music m_square fadein 2.0
    call place("The clearing — the Tree")

    "A stone stairway led her up, toward the muffled rumble of thunder and the hiss of rain. Amanda pushed aside a rusted grate and came out into the night at the edge of a forest clearing, half-hidden behind a tangle of thorns."
    "The storm met her with cold wind and needle-sharp drizzle. Overhead the sky churned iron-gray. Lightning flickered far off and lit the tall pines that ringed the clearing like silent sentinels."
    "But it was the center of the clearing that seized her, and made her blood run colder than any abomination's touch: thirty people, perhaps forty, in a loose ring, all facing an ancient Tree, gnarled and massive, that clawed up from the earth at the clearing's heart."
    "Its bark was bone-pale in places, charred black in others, as if lightning had struck it over centuries and it had refused to die. Its bare branches writhed into the sky in shapes like grasping hands and screaming faces."
    "Thick roots radiated from the trunk, half-buried, some thrust up like the ribs of a long-dead beast. And from one low bough, like a lurid jewel in a skeletal crown, hung a single Fruit."
    "It was the size of a human head and obscenely fleshy, its skin a deep, bruised purple veined with black. Rainwater ran off it in sluggish red rivulets, as though the Fruit itself bled."
    "Her stomach churned. The Book had a plate for this: the vessels, beaten and starved and forced to consume it. Jaws splitting. Bones stretching. The failures loosed into the forest. And now Janet—"

    scene cg the_tree with dissolve_slow
    window hide
    pause 2.0
    window auto

    "There. {i}There.{/i} Janet was chained to the trunk just below the Fruit, half-slumped against the wood. They had stripped her to her undergarments; her wrists were shackled above her head, arms stretched high around the trunk in a cruel embrace."
    "Even from here Amanda could see the welts. One of Janet's eyes was swollen nearly shut, her bottom lip split and puffy. They had beaten her — perhaps worse. She was shivering violently, and a filthy gag was tied across her mouth."
    "To her left and right stood robed figures holding torches that sputtered in the wind, hoods thrown back despite the rain. Markus's acolytes, eyes alight."
    "Around the roots, etched into the ground, ran a dark circle of ash and blood — the circle from the Book, the circle from the cloth on the wall, drawn large. Runes glistened inside it, painted fresh. At intervals stood cultists with curved knives and bound tomes, lips moving."
    "And there, pacing before the Tree like a general before his troops, was Markus."

    scene bg tree_clearing_ritual with dissolve
    show rain
    show vignette
    show janet chained at left with dissolve
    show markus fervent at midright with dissolve

    "He wore a high-collared ritual coat of deep black, embroidered with swirling gold symbols; his dark hair hung in damp strands around an angular face. This Markus stood tall, broad-shouldered, both arms raised over the storm, the torchlight flickering across him."
    "Amanda crept from shadow to shadow until she crouched behind a fallen log at the clearing's edge. From here, at last, she could hear him. His voice rang clear and strong, somehow untouched by the wind."
    mk fervent "…ten years we have waited! Ten years since the Tree last bore His gift. We have kept the old faith when others faltered. We have persevered when others fled!"
    cu "Yes! {i}Yes!{/i}"
    mk "On that night, we were promised deliverance. The First among us said the time was not ripe, that the vessel failed because of human weakness."
    mk "I studied. I learned. I listened when our God whispered from the dark between stars. And He told me what must be done."
    "He turned and gestured grandly to the Tree behind him — and to Janet chained there, trembling and small. Rainwater streamed down his face, and he did not blink against it."
    mk "Tonight, my friends, the path opens. The fruit of the Tree is ripe and the gate awaits its key!"
    "He flashed a wolfish smile and paced nearer to Janet. With two fingers he traced a near-gentle line along her cheek. She flinched away, a whimper escaping behind the gag."

    menu:
        "Watch his hands.":
            "His right hand never strayed far from his belt. Something hung there that was not a cultist's crude iron: a slim hilt, bone-white, carved. He touched it the way other men touch a cross."
        "Look at the Fruit.":
            "Janet's one good eye darted upward, to the thing hanging over her head. In its skin, under the rain, something pulsed — slow, and not in time with any heart Amanda knew."
        "Look at Janet. Only Janet.":
            "Her sister's good eye was open and looking at nothing. Amanda had seen that look in a mirror, years ago, on a girl of fourteen who had just put down a telephone."

    mk fervent "The old rituals only half-understood the truth. The Old One comes not as flame to burn, but as seed to grow. He needs fertile ground — living ground — to root in our world."
    "He turned from Janet and looked out over the crowd. A grin split his face, proud and cruel."
    mk "I drank deep of the Firstborn's blood. His essence flows in me even now."
    "A murmur of awe went through the cultists. Markus laughed, low and delighted."
    mk "Yes. The one I captured and chained — I took its blood for myself. I have mastered the abominations that haunted our nights. By His gift, I command angels and demons alike! Who among you can say I have not earned this right?"
    "No one did. Several dropped to their knees in the mud. Amanda's nails dug into the rotting wood of the log. Even soaked and bedraggled, he looked every inch the dark messiah they believed him to be. He truly thought himself chosen."
    ath "He has their absolute devotion."
    "He lifted his arms again and shouted over a crack of thunder, pointing his knife at Janet."
    mk "Now the second part of the bridge must be laid. Through her flesh we shall hide the seed of the Old One and carry it through the gate! She shall be the holy mother — fertile soil to nourish His coming!"
    ath "Holy mother. Fertile soil."
    "She had thought Janet was to be made to eat the Fruit. This was worse. Hide the seed. Carry it through the gate. They meant to keep her alive while something grew inside her — a living incubator for whatever waited on the other side of reality."
    "A wrath so fierce surged through Amanda's chest that she nearly cried out. She clamped a hand over her mouth. Beneath her coat her belly cramped as the thing inside her stirred, coiling tighter, as if it too sensed the nearness of its enemy."
    play sound sfx_thud
    "Lightning flared, stark white. Amanda shifted for a better view — and her boot snapped a twig beneath the log. {i}Crack.{/i} A small sound, swallowed by thunder almost at once. But Markus's head came up mid-sentence."
    "Over the rain and the chanting he had sensed it. Or sensed her. His eyes swept the tree line. Amanda did not breathe. Another flash — and his lips curled in a knowing smirk. He raised a hand, and with that gesture the clearing fell silent; the wind itself seemed to hush."
    stop ambient2 fadeout 2.0
    mk cold "The last ingredient is here."
    ath "No. No, no, no—"
    "She ducked lower, heart slamming against her ribs. Perhaps he was bluffing. Perhaps he only suspected. She could still slip away, circle around—"
    mk "Don't be shy, Amanda. You've come all this way. Join us."
    mk "This ritual is for you as much as for any of us. Come, help your sister's glorious transformation. With your blood."

    menu:
        "Slip back. Circle around.":
            "She shifted her weight to go — and three faces at the ring's edge turned toward the treeline, then five. Blades came up. There was no around. She had lost the element of surprise. The bastard."
        "Stand up. Hands empty.":
            "She had lost the element of surprise. The bastard. Then she would spend what she had left in the open, where he could see it."

    "Slowly, Amanda rose from behind the log, both hands visible and empty at her sides, and stepped into the rain."
    "A hiss rippled through the cultists. Some sneered; others bared their teeth like feral dogs. Two men near the edge started toward her, blades drawn."
    mk "Hold!"
    "They halted, reluctant. His eyes gleamed with malice and delight."
    mk cold "There you are. I was beginning to worry you wouldn't make it in time."
    "Amanda forced herself forward one step at a time. The torchlight fell full on her now, and a few gasps went up: mud and blood down her legs, hair in soaked strands around a face she knew was bloodless and drawn."
    "She kept her eyes on Markus. Not on Janet — she couldn't risk it, not yet — or she would lose what little composure she had left."
    am hard "I wasn't about to miss your big speech. After all, you went to such lengths to invite me."
    "Her voice came out cold, even amused. It surprised her. She strode into the ring and they parted for her with mutters and hateful glares, blades held inches from her as she passed. They didn't matter. Only Markus did. Markus, and Janet."
    "Her gaze slipped, despite herself, to her sister. Janet's one open eye had gone wide as the moon."
    jn chained "Mmmph— {i}Mandy!{/i}"
    "Incoherent, and heart-wrenching. Janet fought her chains as if the sight of her sister had given her one burst of desperate strength; the woman with the torch yanked her head back by the hair, scolding, and Janet would not stop."
    "Amanda's composure wavered. She quickened, shrugging off a claw-like hand that one cultist laid on her shoulder, and in seconds she stood at the inner edge of the circle, face to face with Markus across the blood-drawn ring."
    "Janet was a few yards to her left. Their eyes met — Janet's terror incandescent, her face smeared with tears and grime — and she shook her head frantically behind the gag. Amanda understood. {i}No, you shouldn't have come.{/i} And under it: {i}I'm sorry. I'm so sorry.{/i}"
    am "Janet."
    "She took one step toward her sister, forgetting the circle at her feet — and a hand shot out and shoved her back. A robed man pressed a curved knife to her collarbone. A warning. She halted, hands rising."
    am "It's okay. I'm here."
    "Janet's chest heaved with sobs, but she nodded, faintly, as if to say she understood. Markus laughed — a light, cruel chuckle."
    mk cold "How touching. Truly. The dutiful sister to the rescue."
    "He stepped around to stand directly in front of her, only the narrow line of markings between them. The rain had thinned to a drizzle that clung to everything. In the firelight his face had a feverish flush."
    "He looked her up and down — and as his eyes crossed her midsection, one brow arched. The slight bulge under her buttoned coat. The way she hunched over it. Amanda folded her arms before she could stop herself."
    ath "Does he suspect?"
    "He gave her no time to wonder. Surprise slid into sly delight."
    mk "Amanda, Amanda. You've made quite a mess, haven't you? Poor Michael… I see his blood on your hands."
    am hard "He got what he deserved."
    "A ripple of anger went through the ring at her tone. Markus only smiled."
    mk "I'm sure he did, in your eyes. Frankly, I expected better of him than to let you slip out of his grasp. But I suppose you've always been the resourceful one, hm?"
    mk "Breaking into my family's tavern, prying into old secrets… and now killing my right-hand man. Very resourceful."
    ath "So Michael was his lieutenant. And he isn't even angry. He's gloating. He thinks he's already won."
    am "I didn't come here to talk about Michael. Let my sister go, Markus. She has nothing to do with this… this cult."
    "Markus blinked. Then he threw his head back and laughed outright, and a few cultists laughed nervously with him."
    mk "Yet you are both here, the day you should be, the day I wanted you to be. In the shape I wanted you in — physically, emotionally, a wreck. Ready to accept your fate. To bleed and die for your sister."
    "She had heard enough. True or not, every second put Janet in greater danger. Her right hand inched toward the knife hidden under her coat, and the weight in her womb writhed, sensing her intent — a pulse of sick anticipation through her core."
    ath "Soon. Very soon."
    mk "And dear Amanda — ever the protector — could not resist such bait. I knew you'd find your way here eventually. Family is your weakness."
    "He sighed, theatrically. She was toe-to-toe with him now across the line of blood-runes. Thunder rolled. His smile thinned, and he snapped his fingers."

    play music m_route_nine fadein 1.0
    "Two burly men lunged from behind her and seized her arms. She hadn't heard them move. She thrashed; their grip was iron. They forced her to her knees at the circle's edge."
    "One twisted her right arm behind her back, and pain lanced through the sore shoulder. The other fisted a hand in her hair and yanked her head back. She sucked a breath through her teeth and refused to cry out."
    "Janet screamed behind the gag. Markus stepped to the Tree and, with a flourish, pulled the cloth from her mouth."
    mk "By all means, let her speak. This is a family reunion."
    jn chained "Amanda! I'm sorry, I'm so sorry—"
    am "It's okay! It's not your fault, Janet! Don't apologize—"
    "The strain earned her a vicious yank on her hair."
    mk cold "Touching. Enough of that."
    "He flicked a finger. An acolyte stepped up; Janet sobbed and twisted away, and the cultist smacked her hard across the face and forced the cloth back between her teeth."
    "Rage and anguish warred in Amanda's chest."
    am hard "If you harm her—"
    mk "You'll what?"
    "He crouched in front of her and gripped her chin between thumb and forefinger, turning her face side to side as if inspecting a purchase."
    mk "You're in no position to make threats. Do you know why you're still alive right now? Hmm?"
    "He squeezed until her teeth cut the inside of her mouth."
    mk "Because I want you to see this. I want you to watch every moment of Janet's ascension. I want the image of her glorious fate to be the last thing your mind clings to when you finally bleed out at my feet."
    mk "Hold her tight."
    "Her arms were pinned harder, both wrists clamped behind her back until her shoulders screamed; a meaty hand gripped her neck. Through the blur she saw Markus climb the tangle of roots until he stood level with Janet, face to face. Janet cringed into the chains."
    "He drew a blade from his belt. Not the crude iron the others carried: the ceremonial dagger, curved like a serpent's fang, and along its length pulsed faint veins of red light, as if it had been forged from coals."
    "Its hilt was bone-white, carved into figures twisting together — serpents, or people, in agony. At a glance it was hard to tell."
    "Summoning every ounce of strength and speed she had left, Amanda moved. She wrenched her right arm free of the distracted man and drove her elbow into the other's gut. He grunted; his hold on her neck slipped. She tore her left arm loose and lunged."
    "Michael's knife flew into her hand as if by its own will. With a snarl she drove it deep into the thigh of the nearest acolyte."
    ac "{i}Aaah—!{/i}"
    "The woman crumpled. Chaos ignited: shouts, a lunge, flailing arms. Amanda ducked under them and hurled herself at the Tree — at Markus — knife raised. For a heartbeat his face registered genuine surprise, and perhaps a sliver of fear."
    "She slashed with all her momentum behind it. He jerked aside with serpentine grace, and the tip sliced only the heavy fabric across his ribs. Then his hand clamped around her wrist. Bone ground on bone until the knife fell."
    "She struck at his throat with her free hand. He had expected that too. He twisted the captured arm, and her own momentum threw her face-first into the trunk."
    show markus ritual at right with vpunch
    "Bark scraped her cheek as he slammed her against the wood — right next to Janet. Her sister's face was inches from hers, eyes wide in horror. Amanda tasted blood and moss."
    mk ritual "You shouldn't have done that."
    "The calm veneer had shattered; his voice brimmed with rage. He pressed his weight into her back and ground her cheek into the wood until stars danced in her vision. Behind them the cultists surged, unsure whether to intervene or watch."
    "He grabbed a fistful of her hair and pulled her head back from the trunk. Janet was sobbing uncontrollably. Rain ran down Amanda's face with the sweat and the blood, and she locked eyes with her sister and mouthed it."
    ath "It's okay."
    "Nothing was okay."
    "With a snarl he shifted his grip to her waist and hurled her to the ground. Her back hit a root and she cried out as pain lanced up her spine. Thunder boomed overhead like laughter from an indifferent god."
    hide janet with dissolve
    "He was on her in an instant, dragging her by the ankle through the mud toward the foot of the Tree, far stronger than a man. Her nails raked trenches in the soil. She was hauled beneath the hanging Fruit, torches crowding in above her, a dizzying carousel of flame."
    show markus ritual at center
    "He dropped her leg and straddled her, seized her wrists and pinned them on either side of her head. His eyes were wild, pupils blown with exhilaration or something less human. He looked, in that moment, like a maddened prophet ready to sacrifice whatever his altar required."
    am hard "Go on then, kill me!"
    "She spat it up at him, half-choking on rain. If she could keep him on her, Janet might be spared a moment longer. Maybe—"
    "He panted, and shook his head slowly, almost regretfully."
    mk "Kill you? No, no, dear Amanda. That would be too simple."
    stop music fadeout 3.0
    "He released one wrist — and drove his knee onto that forearm to keep it pinned. In the freed hand: the dagger."
    "She struggled anew. He held her down with ease, relish in his grin, and brought the blade to her abdomen with deliberate slowness. The cold kiss of steel through the torn shirt, right over her navel. A sickening dread washed over her."
    mk ritual "Watch, Janet."
    "He never took his eyes off Amanda's."
    mk "Watch and learn how little family truly means. Her life for yours, that's always been the bargain."
    "Before Amanda could steel herself, Markus drove the knife down."

    scene black with flash_red
    jump ch16
