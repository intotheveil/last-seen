## Chapter 4 — "Tested Under Its Roots"
## Source: docs/manuscript/ch04.txt l.41–132 (Amanda POV).
label ch04:
    call chapter_card(4, "The subway — morning rush")

    ## ---- 4.3  The station ----
    scene bg city_dawn_street with fade_slow
    play music m_records fadein 2.0
    call place("The subway entrance — morning rush")

    "She slowed slightly. The sight alone set a tightness in her chest. Amanda had never liked crowds — the way they pressed too close, the way a hundred scents and voices collapsed into one suffocating haze. Crowds demanded you surrender personal space; she loathed that surrender."
    "Still, there was no avoiding it. She drew a steadying breath and stepped forward, letting herself be carried along with the others into the subterranean passage."

    scene bg subway_hall with dissolve
    play ambient2 sfx_crowd fadein 2.0
    "The air changed instantly. Cooler, but thick with the familiar subway smell: metal, dust, the faint tang of oil and electricity, all undercut with the salt of sweat from too many bodies in motion."
    "Fluorescent lights buzzed overhead, flat and pale along the tiled walls. Posters peeled at the corners — concerts, perfumes, political slogans. Amanda kept her eyes forward, her pace deliberate, refusing to be swept entirely by the crowd."
    "The station hall opened wide at the bottom, a cavern of white tiles and echoing announcements. A calm, repetitive voice droned destinations, delays, reminders about unattended baggage, and became background to hundreds of overlapping footsteps."
    "The ticket gates clicked and beeped in quick rhythm. Amanda slid her card through and pushed past the turnstile in one smooth motion. The platform waited below, two escalators spilling bodies onto its length."

    menu:
        "The escalator. It's faster.":
            "She looked at the escalator — a packed, motionless column of shoulders pressed into stillness — and her feet had already turned away from it. The stairs, then. The quick burn in her legs was better than standing shoulder to shoulder with strangers."
        "The stairs.":
            "She chose the stairs, preferring the quick burn in her legs to the sensation of standing shoulder to shoulder with strangers pressed into stillness."

    scene bg subway_platform with dissolve
    "She stopped just short of the yellow safety line. Trains thundered in the distance, the sound rising through the tunnels like an approaching storm. The platform was crowded, clusters of commuters gathered at the middle where the cars would be thickest."
    ath "Never the middle."
    "Too many people, too much noise. She turned and walked purposefully toward the far end of the platform, each step carrying her farther from the restless shuffle of the main crowd."
    "Here only a handful of people lingered: a man in a grey suit scrolling through his phone, a woman rocking a stroller and humming to herself, a teenager on a bench with headphones drowning out the world. The press of humanity was looser."
    "Her gaze drifted to the tunnel's black mouth, where the lights of the approaching train began to flicker. The sound swelled — metal on metal, the rush of air pushed ahead of it. A gust of warm, stale wind tore along the platform, tugging at her hair and coat."
    "She closed her eyes briefly, bracing herself, then opened them just as the train roared into view. The cars screeched to a stop; the doors sighed open with mechanical precision."

    ## ---- 4.4  The last carriage ----
    scene bg subway_car with dissolve
    stop ambient2 fadeout 1.5
    "She stepped deliberately toward the last carriage. Inside, the space was not empty but tolerable — scattered passengers rather than a crush. She took a side seat near the door, bag on her lap, body angled slightly away from the aisle."
    "The train lurched into motion, lights stuttering overhead, and Amanda exhaled quietly. For the next twenty minutes she would ride the city's veins in silence — anonymous among strangers, insulated in her own careful space at the edge of the crowd."
    "Headphones sat idle around her neck, as if only the appearance of listening would be enough to keep the world at arm's length. She let her gaze travel without landing."
    "A young woman stood by the exit, slim and poised, one hand wrapped around a hanging strap, the other smoothing the line of a tight skirt that ended just above the knee. High heels, neat jacket, clean collar, a glossy bun knotted high."
    "She had the air of a receptionist or a junior assistant in a firm with glass walls and plants that never drooped. Her mouth was set in a soft, polite line, the kind you practice for elevators and lobbies."
    "Opposite Amanda an old couple sat shoulder to shoulder in winter coats. The man's scarf was tucked into a worn tweed jacket; his hands were like folded parchment. The woman wore a pale knitted hat, a string bag of oranges on her lap. Their knees touched as the train swayed."
    "Farther down, a mother tried to divide herself between two children, seven, maybe nine. New sneakers and loud backpacks. The older one cradled a book upside down; the younger pressed a fresh sticker sheet against the window, staring at his own reflection."
    mo "Sit still."
    "A whisper, a smile pinned to her mouth, as if quiet could be bribed into staying."

    show drunk neutral at center with dissolve
    "And then, near the middle of the car, there was the man everyone knew by shape before they knew his face. Fifties, soft in the middle, a jaw grizzled the color of ash."
    "He paced in a slow loop around the central pole, mumbling to himself, one shoe untied, a jacket one season too thin. The smell of stale ethanol drifted around him, cut with the iron tang of an old nosebleed."
    "He turned his head to look at invisible people, barked a syllable that could have been a laugh or a cough, then resumed his orbit, the way a fly finds the same patch of air again and again as if it can't leave."
    "Amanda read the car the way you read a weather map: pressure systems and possible storms. The young woman's polished calm. The old couple's patience. The mother's thin smile. The man in the middle, his orbit slightly wider each time he rounded the pole."
    "Every time the car flexed, the lighting blinked, and gray shadows yawned along the floor like spilt water."
    "The first stop was announced with a soft chime and a voice that sounded like it belonged to nobody. The young woman shifted her weight and adjusted her heel — some discomfort she had been tolerating for a stop and a half."
    "The brakes bit. A final small lurch rolled through the car, the kind that pushes everyone forward a courtesy inch. The young woman lost her balance by that inch."
    "It was nothing — a small sway, a boot's worth of space given accidentally to the man's orbit. Her shoulder brushed the drunkard's back. She steadied herself, eyes widening in the universal apology of city etiquette, and offered it soft and perfunctory, already looking away."
    yw "Sorry."
    with hpunch
    "He wheeled as if she had struck him. His face came alive in a way that had nothing to do with wakefulness. The eyes slid into focus with a snap; the jaw tightened like a fist."
    stop music fadeout 1.0
    dr "Hey."
    "Too loud for the space, the word a slap. The young woman's gaze dropped and re-pinned itself to the strap, as if she could nail herself back to safety."
    yw "I said I'm sorry."
    dr "You hit me. You think you can just—"
    "His breath rolled out sour, a string of saliva clinging between tongue and teeth. A sweeping gesture, theatrical and clumsy; his shoulder bumped an empty seat. He advanced the half step that turned closeness into threat."
    "The car's sound changed. Not silence — the absence of small things: page turns, zipper pulls, the quick cough into a fist, the whisper of a mother to a child. The train became only the metal hum of its own motion."
    "Amanda felt it in her shoulders first, her muscles going still, as if stillness were camouflage. She watched him from the edge of her vision, refusing the direct stare that could be read as invitation."
    "The old couple looked down at their hands in unison. The mother shifted so that her body made a screen. Somewhere down the car someone pressed pause on whatever they were listening to, and never un-paused."
    yw "I said I'm sorry."
    "One last time, that small piece of politeness like a token to feed a machine. He swatted it aside with a laugh that bared all his teeth."
    dr "You're sorry. Princess is sorry. Look at you."
    "The word landed wet. He leaned closer. She leaned back, but there was nowhere to go. The doors had closed; the train had already tugged itself away from the platform. He sniffed at her hair, or just breathed too near it."
    dr "You think you're better than me. You think you're clean. You think—"
    "The PA tried to speak, a cheerful announcement smothered by the dead acoustics of the car. It only made him louder; his voice climbed to crest it."
    dr "Say sorry again. Say it."
    yw "I'm sorry."
    "Her knuckles were white around the strap. He grinned, pleased by the performance of his power."
    dr "No, you're not. Not yet."
    "He swung one arm out and caught the metal pole with a ringing clank. His eyes did their reluctant swim to the sides, checking whether the audience was still with him. No one moved. A man in a brown coat angled his phone into his thigh and pretended to read an old text."
    "Amanda's pulse threaded high into her throat. Her mind did that unhelpful thing it always did. Calculating."
    ath "Distance to the intercom. Distance to the emergency handle. The weight of the bag against my hip. What my own mouth would feel like saying 'excuse me, please stop'."
    "She could already hear the aftermath: the man's attention shifting like a spotlight to whoever spoke first. She could hear the tone of that attention. She didn't want it. She hated that she didn't want it."

    menu:
        "Press the call button.":
            "Her eyes found the red button by the door. Three steps. Her hand did not leave the bag. She watched her own hand not leave the bag, and clenched her jaw until she felt the ache in her ears."
        "Say something. Anything.":
            "Her lips parted. The first syllable sat on her tongue like a stone and stayed there. She clenched her jaw around it until she felt the ache in her ears."
        "Stay still. Stillness is camouflage.":
            "She clenched her jaw until she felt the ache in her ears. Stillness. The oldest trick an animal knows, and the one she was best at."

    "The old woman in the knit hat laid one trembling hand on her husband's wrist. Don't, her fingers said. The mother turned fully toward her children and began a story in a whisper that wasn't a whisper, her lips moving around words that had no sound."
    "\"Next stop,\" the PA tried again brightly, \"in two minutes.\" The drunkard swayed with the car, his finger rising to jab the empty air just beside the woman's cheek."
    dr "Say it like you mean it. Say 'Sir, I'm sorry I touched you.'"
    "The word Sir stuck like a fishbone going sideways. The woman's mouth opened and closed. She did not say it."
    "She wore a perfume that tried hard not to be perfume, something clean like paper or the inside of a new drawer. It couldn't compete with the acid stink of his breath, but Amanda caught it anyway, measured the collision of the two."
    ath "This is what an apology is worth in here. This is the exchange rate."
    "A man at the far door glanced up the car, met the drunkard's back, and glanced down again. His eyes flicked to the call button. Then he let them slide past it. Everyone in the car felt that small capitulation land like dust."
    dr "Look at me. Look at me when you say it."
    "Soft now, intimate, a parody of care. She didn't. She looked past him at the chrome trim around the door and found her own reflection very small and very pale inside it. Her free hand smoothed her skirt by reflex, as if her palm could iron fear back out of the fabric."
    "The train rattled through a stretch of tunnel, lights biting across the car in a rapid white frequency. In that hard light the wet red at the edge of his nostril showed itself, the cracked skin at the corner of his mouth, the stale damp in his collar."
    "His anger wore the weary clothes of habit. It looked like a room he knew too well, one he could find even in the dark. He took another step, so that his chest almost touched her shoulder."
    dr "I could push you. Do you know what happens when doors open and you're stupid?"
    "He smiled. It was soft and mean."
    dr "The world opens you first."
    "Amanda felt the sharp heat of shame under the skin of her neck. Shame for doing nothing, for pretending nothing was happening, for watching, for being the kind of person who calculated and chose the quiet. She swallowed it and tasted metal."
    "Her heart had already sprinted to the station, looked back, sprinted again. The car began to slow. The lights steadied. The young woman made her choice."
    yw "Excuse me."
    "That small, hard voice people use when they've done the math. She pivoted to slip between the drunkard and the door the moment the panels split. He moved faster than she predicted."
    play sound sfx_thud
    with hpunch
    "He flung his arm out and smacked his palm against the door frame just as it parted, slapping metal hard enough to echo down the car. People flinched. The doors banged open a hand's width, bounced off his hand and stalled, beeping."
    dr "Where you going? We're talking. You and me."
    "Suddenly bright. Her mouth opened, soundless. She was trapped between him and the warning beep. The old man in the tweed jacket shifted as if to rise, then stopped, because his wife's fingers dug crescent moons into his wrist."
    gd "Sir. Sir, step back from the doors."
    "Softly. A man in a maintenance jacket with the metro logo stitched at the breast, on the platform, his face framed in the small window of the door. The drunkard's head snapped toward the voice with delight. Audience."
    dr "We're talking!"
    "He threw his free hand wide, and in that flourish the door got three more inches before his palm hit again and jammed it. He turned back to the woman, sweet suddenly, leeringly gentle."
    dr "Don't be rude. It's rude to leave."
    gd "Sir, step back."
    "The voice outside had companions now. A second yellow jacket appeared at the edge of the frame, then a third. The beeping quickened its tempo like a heart."
    dr "I'm calm. I'm very calm."
    "He smiled with all his teeth. Then he hissed a sentence in the woman's face, low and private, and her jaw tightened. Amanda didn't catch the words, only the color of them."
    "The first guard wedged his fingers into the gap and pushed, with the professional patience of a man who does this several times a day and knows exactly how long it takes. The door yielded another inch."
    gd "Sir, step back from the doors and exit the train."
    "The drunkard turned sideways in defiance, as if his width alone could hold the whole system hostage. And then, because the moment had been too small for him, he made it bigger: he twisted at the waist, lifted his head, and pitched his voice to carry through the car."
    dr "Do you see her? You see this doll? You think she's real? She's plastic. She's hollow."
    "He tapped the air near her chest."
    dr "She should be next."
    "He giggled. The sound had the bright edge of something broken."
    play sound sting_word
    dr "She should be tested under its roots."
    "Amanda's stomach pulled tight, an animal reflex. The words did not belong in a morning, in a crowded car, in a city that believed itself immune to the grotesque theater of other places."
    "The children's mother put both hands over both small pairs of ears and gave the kind of smile you give in a hospital when someone comes to the door with a clipboard."
    "The guards had no time for theater. The first reached through the gap and popped the drunkard's hand off the steel with a practiced twist. The second slid the door along its track. The third planted himself in front of the woman, interposing his body."
    gd "Step out."
    "He didn't wait for permission. He took the drunkard by the elbow and turned him sideways and out, the way you lead someone through a crowd without touching their heart."
    "For a second the man let himself be moved. Then he bucked. The motion snapped from his shoulders, from some corner of himself that had been saving it. He jerked away from the guard's hand and tried to re-enter the car, eyes gone glitter-hard."
    dr "You should be next. I want to see it — your insides — burst out."
    "The words wet, flung. A pumping gesture with both hands that turned the sentence into a thing."
    "The mother closed her eyes. The old woman in the knit hat whispered a prayer in a language older than the trains. The young woman stared at the floor so fiercely that it might have burned a hole."
    "The first guard caught the drunkard at the bicep while the second took the wrist, the kind of two-point hold that reduces a man to mere armature. The third eased the young woman back into the car with a palm that didn't quite touch her shoulder."
    gd "You're okay."
    "It was not a promise, only a wish wearing the shape of a sentence."
    hide drunk with dissolve
    "They had him on the platform now. He tried once more to twist, but the guards were already moving him fast, the way you move a sparking wire: cleanly, without looking at your hands. The beeping stopped; the doors cleared and began to close."
    "His voice climbed briefly and struck the air one more time; the rest was taken by glass. The panels slid shut. His mouth became a shape on the other side, yelling in the aquarium of the platform, soundless as a fish."
    "For a beat the car held its breath. The window carried a slick replica of the platform, the gray jacket smeared across the glass like a thumbprint, the yellow jackets smudged bars of color. Then the train tugged forward, and the scene unwound away until it was just tunnel again."
    $ note("\"She should be tested under its roots.\" A drunk on the morning train, to a stranger in heels.")

    play music m_records fadein 3.0
    "The young woman still stood by the door, but her hands had left the strap. She pressed her palms flat to her thighs, then knotted her fingers together. Her chin was lifted higher than it had been, which is what people do when they are trying very hard not to cry."
    "The maintenance man who had first spoken through the window came through the pass-through to check the car. He stood near her without standing next to her."
    gd "Do you want to sit?"
    yw "I'm fine."
    "A tiny pulse of a headshake. And like all sentences that begin with I'm fine, it was true only in the way that the train was fine — moving, despite its weight."
    gd "Okay."
    "He stepped away and nodded to the mother, and the mother nodded back: two strangers acknowledging that the city had briefly remembered how to take care of itself."
    "The old woman released her husband's wrist by degrees. He put his hand over hers and patted it once, absent-mindedly, the way you pat a pocket to make sure what you need is still there."
    "Amanda unclenched her jaw. It felt as if she had been holding a pebble in her molars. She touched the cord of her headphones without lifting them, an old habit, pointless but comforting."
    "She looked at the young woman's shoes — heels never meant for trains and men — and felt a small, unnecessary surge of anger on behalf of a stranger she would never see again."
    ath "A dozen things I could have done. 'Are you okay?' And the answer I already know."
    "She did none of it. The moment for talking had passed; the car had reclaimed its right to silence."
    kd "What did he mean? Why was he—"
    "The children whispered at last, urgent in their whispering. The mother shook her head gently and began a story about a green bus and a bird that stole a french fry, and the children, bless them, let the story do its work."
    "The young woman's reflection found Amanda's for a moment in the black window. Two tired faces layered in the glass, anonymous, briefly aligned. As the car rocked they slid apart and became their own again. The city carried them both and forgot them both, equally, immediately."
    "At the next stop the doors opened with a yawn. The young woman step-clicked onto the platform, head high, shoulders squared, carrying the shaken relief in her sternum like a cup filled too near the brim. She did not look back into the car."
    "The doors closed behind her. The brief rectangle of platform light narrowed, narrowed, and vanished. The train plunged on, and the sound of it swallowed everything personal until all that was left was motion."

    ## ---- 4.5  The memory (narration only) ----
    stop music fadeout 2.0
    scene black with fade_slow
    play music m_grief fadein 3.0
    "Amanda closed her eyes, letting the rhythm of the train carry her. The sway of the carriage, the hum of metal on rails, the low murmur of strangers — all of it blended into a steady backdrop, dissolving until only her thoughts remained. Inevitably, they drifted backward."
    "She was fourteen again. The phone call had come on a grey afternoon, the kind that carried no warning, no shadow of what it was about to bring."
    "Janet's voice in the next room, light and innocent, still playing with the stuffed rabbit she refused to let go of. Amanda had picked up the phone expecting nothing more than another reminder about homework or schedules."
    "Instead the words had shattered the air: accident, gone, immediate. Her parents, gone in the blink of a moment. No goodbye, no chance for explanation or preparation. Just a clean, brutal severance."
    $ note("Accident. Gone. Immediate. Three words on a grey afternoon, at fourteen.")
    "She remembered her own breathing turning jagged, the taste of copper at the back of her throat, the blur of her vision as if the world itself had cracked. Then Janet's small footsteps rushing into the room, her wide eyes searching Amanda's face for answers."
    "Amanda had tried to speak, but no words had come. Only the knowledge that she was now both sister and shield."
    "The years that followed blurred into strange homes, strange faces. Foster families that tried in their own ways — some kind, others distracted — but none of them hers."
    "Amanda endured. Quiet, efficient, taking on responsibility far older than her years. She cooked when others forgot, cleaned when no one asked, kept Janet's clothes folded and her schoolbooks packed."
    ath "As long as Janet is fed, dressed and smiling, everything else can be borne."
    "When she turned eighteen the system stepped aside. She remembered the first time she turned the key in the lock of their parents' old house — the one inheritance that had not slipped through their fingers."
    "The air inside had smelled of dust and memory, the furniture waiting like relics of another life. She had stood in that silence feeling both crushed and liberated. From then on they were on their own. She was not just Amanda anymore: mother, guardian, provider."
    "Those first months blurred into long days and longer nights. Shifts wherever she could find them — cafés, tutoring, filing jobs at an accounting office — anything to keep food in the fridge and the bills paid. And through it all she clung to her studies."
    "Mathematics had been her lifeline, the one piece of order she could hold onto. Equations made sense in a way the world didn't; proofs had structure, certainty. The chaos of grief could not erode the truth of numbers. She pressed forward, building a life out of fragments."
    "She remembered Janet in those years: smiling, grateful, never the burden Amanda feared she might become. A good girl, soft-hearted, eager to please. Friends, easy laughter, homework done without complaint."
    "Never the rebellious teenager Amanda had braced herself for. Amanda's strictness — absolute, rules enforced with a stern hand — might have crushed another child. But Janet seemed to understand: the severity was born of fear, not cruelty. Fear of losing her. Fear of failing."
    "Still, Amanda sometimes winced at the memory of her own harshness. Nights when she had scolded Janet for staying out too late, mornings when she snapped over unfinished chores. The sound of her own voice, hard and unyielding, so unlike their mother's gentle patience."
    ath "If Janet grew careless. If she stumbled into trouble. If she slipped from the path I carved — what then?"
    "The thought had terrified her more than exhaustion, more than hunger. So she held the line, even when it hurt."
    "And yet Janet had always made it easier. Small drawings left on Amanda's desk. Tea brewed when she knew her sister was studying late. A way of smiling up at her after an argument, of reminding her the sacrifice wasn't invisible. That it mattered. That Amanda mattered."
    "The train lurched slightly, pulling Amanda back into her body, but her eyes remained closed. She could almost hear Janet's laughter, high and bright, drifting down the hallway of their parents' house. Almost feel her tugging at her sleeve, asking for one more story before bed."
    "Memories folded over each other, bittersweet — pain and pride, grief and love intertwined until they were inseparable."
    "Amanda had no friends, no boyfriend, no circle of people waiting for her outside the narrow world she had built. She had never allowed herself the luxury. Her career was her company, her duty her compass, and every action a proof that discipline could become love."
    "Advancement, achievement, progress — those were her only measures. Everything else was cut away, sacrificed, left behind. What remained was a life stripped to its essentials: work, duty, and the unshakable need to provide."

    scene bg subway_car with dissolve_slow
    "She opened her eyes at last and stared at the blurred reflection in the subway window opposite. The woman staring back looked sharp, composed, ready for the day. But Amanda knew the truth."
    ath "A patchwork of scars and duty. A vessel stitched together by responsibility and sheer willpower."
    "And still, despite it all, she would do it again. Every shift, every sacrifice, every sleepless night had been worth it — for Janet."

    menu:
        "Always for Janet.":
            ath "Always for Janet."
            "The words sat there a moment, familiar as a prayer. Then the question slid into her mind like a blade, quiet but sharp."
            ath "Was it, though?"
        "Was it, though?":
            "The question slid into her mind like a blade, quiet but sharp, before the old prayer could finish itself."
            ath "Was it, though?"

    "Amanda was smart enough to know the truth: it hadn't been entirely for Janet. Maybe not even mostly."
    ath "It was for me."
    "No one had asked her to take the role she carried on her shoulders. No judge, no social worker, not even her parents in their absence. Amanda had stepped into it on her own, claimed the burden like armor."
    "She told herself it was for Janet's sake, but deep down she knew what drove her: the constant need for approval that would never come. The silent audience she could never reach. Her parents."
    "Even years later she felt them watching. Their absence was a presence in itself, pressing down on her, demanding she live not just well but better. Every sacrifice, every late night over textbooks, every early morning between jobs was proof she had done well. That she was worthy."
    "She pictured their faces sometimes, the way they smiled in that wedding photo on the bookcase. She wanted to believe that somewhere, somehow, they could see her now. That they would nod and say they were proud of the way she had carried Janet, the way she had carried herself."
    "But pride was a hollow currency when you could never hear it spoken aloud. The truth gnawed at her."
    ath "I'm living for ghosts."
    $ note("Living for ghosts. All the rigidity, all the control — a shield, not a gift.")
    "All the rigidity, all the control, all the ambition — yes, it had provided Janet with a safe, structured life. But it had also been Amanda's shield, her way of holding back the chaos that had once swallowed her world."
    "Her lips pressed together. Maybe it was selfish. Maybe it had always been selfish. Janet had never asked for a guardian, a surrogate mother, a disciplinarian wrapped in duty. What she wanted, perhaps, was simply her sister."
    ath "And in becoming everything else, did I lose the chance to truly be that?"

    stop music fadeout 2.0
    "The train began to slow, its brakes screeching as the carriage lurched forward, pulling Amanda out of her thoughts. The lights flickered once, snapping her back into the present. Around her, passengers stirred, gathering bags, adjusting coats."
    "Amanda straightened in her seat and smoothed the fabric of her blazer with the flat of her palms. The doubt, heavy as it was, folded back into the quiet corner of her mind where it always lived, waiting."
    ath "Not today. Today is performance. Precision. Control."
    "The doors opened with a hiss. Amanda stood, bag secure against her shoulder, and stepped out with the others, heels clicking on the tiles, her face composed once more. Whatever questions haunted her would have to wait. The world demanded results; she would deliver them."
    jump ch05
