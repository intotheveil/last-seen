## Chapter 12 — "Time for My Medication"
## Source: docs/manuscript/ch08.txt l.3–137. Amanda POV (the store), then Janet POV (the cell).
label ch12:
    call chapter_card(12, "General Store / Sea Goods — the storm")

    scene bg village_lane_storm with fade_slow
    show rain
    show vignette
    play ambient sfx_storm fadein 2.0
    play music m_judgment fadein 3.0
    call place("Driftwood Bay — the storm")

    "The storm had eaten the horizon. Rain came sideways in sheets, ripped by the wind and flung into the narrow streets like handfuls of nails."
    "Amanda kept one arm clamped to her right shoulder and the other out for balance, boots slapping through water that ran along the gutters like a black stream."
    with flash
    "Every few seconds the sky tore open and the village jumped into cruel focus: stone walls slick with algae, bowed fences, shutters hammered shut. Then darkness swallowed it all again."
    "She moved by memory and brief illumination. The church had stood out on the last flash: high ground, a suggestion of a bell tower, maybe a cross. Far. A couple of kilometers at least."
    "The fog had thinned on this side of the village, peeled back as if a giant hand had wiped the air clean. She tried not to think about why."
    "Her shoulder pulsed with heat. Every movement was a bright wire pulled through muscle. Blood, washed thin by rain, still leaked down her bicep. The towel she had bound in the empty house had loosened."
    ath "I need the bleeding to stop. Really stop. Or I'll be slower every minute until I'm not moving at all."
    ath "There are other ways. Staplers. Fishing line. People sewing their own skin like torn fabric. Not now. My hands shake too much. Something simpler. Faster. Anything to hold me together long enough to keep moving."
    "A sign banged on its hinges ahead, metal on metal in the wind. In a lightning strobe she read it."
    note_voice "General Store / Sea Goods"
    "The sort of place that sells rope and buckets, cheap knives, floats, net-menders, bleach, twine."

    scene bg store_alley with dissolve
    show rain
    show vignette
    "The front shutter was bolted. She rattled it once and felt the building answer: a hollow tremor, a suggestion of emptiness."
    "A narrow alley slit between the shop and the next building, crates stacked under a tin awning that shook like a drum. At the back, a skinny service door with a single hasp. The padlock hung open. Empty."
    ath "Either someone forgot to close it, or someone opened it in a hurry and never came back."
    play sound sfx_thud
    "She shouldered the door with her good side. It stuck, swollen with rain. She hit it again, hips first, and it gave with a moan. Salt and dust and oil, old cardboard and damp rope. Somewhere inside a fluorescent tube ticked, trying to wake."
    am "Amanda. Move."
    "Hearing the name steadied her."

    scene bg store_int with dissolve
    show vignette
    "She eased the door mostly shut behind her, leaving it ajar for sound and air. A long rectangle, aisles stitched tight. Jerrycans, coils of nylon rope, a wall of hooks glittering like fish eyes. A low counter, a cash drawer left open."
    with flash
    "Lightning popped and the tube overhead finally caught, buzzing into a dirty hum. Weak, sickly, blue-white and unforgiving. But it was something."
    "She sagged against the endcap for a heartbeat. Then she pushed forward, the way she always moved once she'd decided: fast, direct, one thing at a time."
    "Cleaning aisle first. Expired iodine, crystals like rusted snowflakes along the neck. A half-empty bottle of rubbing alcohol gone yellow. She sniffed it and nearly gagged."
    ath "Not tonight."
    "Gauze pads sealed in plastic. Elastic bandages. Tape so old the cardboard core had softened. She took them all under her left arm. Another shelf: household glue, epoxy syringes with the plungers fused, little metal tubes rattling in a bin."
    ath "Superglue."
    "She pawed through the bin with shaking fingers. Most were stiff and light, empty or hardened. One stuck to her wet fingers. Still heavy. Cap intact. The brand name rubbed to nonsense by time: CYANO— something."

    menu:
        "One tube. Enough.":
            "She closed her hand on it. Then opened it again, and kept digging. A second tube as a spare. A third, for fear. Three tiny salvations, cold in her palm."
        "Keep digging. Take spares.":
            "A second tube as a spare. A third, for fear. Three tiny salvations, cold in her palm."

    am "Water. Clean first."
    "Spring water from the counter. She cracked a bottle with her teeth and poured it over her shoulder. The shock of cold bent her at the waist. Blood ran fresher. Good. The water hissed on raw flesh like water poured on a skillet."
    "She slid the kitchen knife from Markus's house under her collar and sawed the cotton away from the wound until air hit it."
    ath "Don't think about infection. Solve the bleed."
    call mature_show("glue_wound")
    "She braced both elbows on the counter, put the tube cap between her teeth, and twisted. A string of clear adhesive swam up, thin as a cobweb, alive with chemical smell. A bead swelled at the nozzle, fattened, quivered."
    call mature_hide
    am "Okay. Okay."
    "She pressed the wound edges together with the heel of her left hand. Skin slid under skin, greased by blood and rain."
    "And for an instant she saw without seeing: a fourteen-year-old girl with mud-streaked shins at the edge of a hole in the ground, a fistful of damp funeral dirt in her palm, a smaller hand strangling hers in fear."
    ath "Don't worry. You have me."
    "She blinked. The image fled. She leaned her weight into the cut until her vision narrowed to a tunnel, and squeezed."
    "The glue oozed thick and milky along the seam. Where it touched the shirt fibers still clinging to the tear, heat bloomed. A tiny puff — no sound, a ghost-wisp of smoke. The pain ripped up like a wave. She clamped her jaw so hard her teeth clicked."
    ath "Hold the edges. Hold."
    "She squeezed again, thicker, let it fill the little valley where her skin refused to meet, then smeared with the nozzle to lay a crude ridge."
    am "Come on. Come on."
    "She counted in fives while the glue found itself. Five. Ten. Fifteen. The warmth faded into a knifing tightness. She let go with care."

    scene cg the_seam with dissolve_slow
    window hide
    pause 2.0
    window auto
    "The seam held in a glossy white line, like the plastic handle of a cheap toy melted across her skin."
    "In places the glue had pebbled into hard beads like sugar glass and stuck to her palm; a few popped off and clicked on the counter. The main seam stayed sealed."
    "She dabbed the edges with gauze, then blew on it, absurdly, as if it were nail polish. The fumes stung. Tears and rain blurred the wound into a single glare."

    scene bg store_int with dissolve
    show vignette
    "Her forearm next. The arc of the dog's teeth, swollen and angry, the skin ragged. Gluing it would trap filth she couldn't flush. She rinsed it with the last of the water and wrapped it tight in gauze and elastic until the ache turned into pressure."
    "Her hands shook. Her legs had a slow electric hum in them now, tremor without motion. She slid down the cabinet and sat on her heels for a count of three, just to feel the floor hold her."
    "The storm barged against the building and the fluorescent flickered. Under the wind she could almost hear the sea, a lower note, as if something enormous breathed on the shore."
    ath "Get up."
    "Two more bottles of water. Plastic-wrapped biscuits torn open with her teeth, something sweet and dull chewed and swallowed, feeding a fire instead of a mouth."
    "A plastic poncho as old as the calendar behind the register. It split along one fold like onion skin, but what remained she pulled over her head. A thin lie of dryness. Duct tape, torn with her teeth, looped twice around her upper arm to mash a pad against the seam."
    "Her phone was dead weight in her pocket. On a low shelf she found a cheap scratched flashlight, the kind sold for fishing trips or blackouts. She thumbed the switch. A weak yellow cone sputtered to life. Steadier than lightning."
    $ note("A dead phone. A cheap flashlight. Three tubes of glue. The church on high ground at the far end of the village.")
    with flash
    "Lightning flooded the shop white. For an instant she was caught in the reflection of a glass display case."

    menu:
        "Look.":
            "Hair plastered flat to her temples. Face bloodless, streaked with grime. Eyes too wide. The wet clothes clung like another skin. The ugly plastic seam at her shoulder gleamed in the flash. Obscene. Almost alien."
            "She did not look away. That was her. All of it."
        "Don't look.":
            "She turned her face from the glass before the flash was done. She had refused a mirror once tonight already."
            "It didn't matter. She had seen enough: the plastered hair, the bloodless face, the seam at her shoulder gleaming obscene in the light."

    ath "You have me."
    "Her own voice, from a lifetime ago, steady over a grave. Her hand tightened on the little knife at her waistband. It felt childish now, inadequate against the scale of what waited in this place. But it was weight, and weight was choice."
    "She slid it back, wiped her hands on her thighs, scanned the room one last time, and went for the exit."

    scene bg store_alley with dissolve
    show rain
    show vignette
    "Wind shoved at the service door. When she pushed, the wind took it from her and the rain slapped her face, immediate and total, air so clean it felt violent. She pulled the ruined poncho tighter and slid back into the alley."
    "She peered around the corner toward the main street and waited for the sky to tear open again."
    with flash
    "It obliged. Low houses crouched behind walls. The square, a floodplain of black mirrors. And there: the church, a smudge of structure on higher ground at the far end, bell tower squared against the white-limbed tree of lightning."
    ath "Two streets over. Cut behind the park. Stay high. Avoid the shoreline curve where the cliff takes the shoulder."
    "Then the dark slammed down and the world went to sound. She moved."

    scene bg village_square_storm with dissolve
    show rain
    show vignette
    "Water rushed around her boots with every step, ankle-deep, sucking at the leather. Her breath fell into a rhythm, four steps in, four steps out. The seam at her shoulder tugged with every arm swing, a thousand tiny teeth set in plastic."
    ath "Good. I'm held together."
    "At the edge of the square she paused under the skeletal canopy of a plane tree, its bare branches rattling in the storm like bones in the sky. She leaned her forehead against the slick bark, her hands working on their own: pressing the tape, adjusting the knife hilt."
    stop music fadeout 1.0
    "The sound came without warning."
    "A single iron note rolled through the village, deep enough to rattle the air in her chest. Amanda froze. The bell swung again, slower, and the sound poured down the narrow lanes like liquid metal."
    ath "The ritual is near. Hours, maybe less. Janet's time is shrinking with every toll."
    $ note("The church bell. The ritual is near. Hours, maybe less.")
    "She drew her coat tighter and pushed forward, boots slipping on the wet stones. There would be no rest now. No stopping. She had to reach the church before the bell called them all."

    scene black with fade
    pause 1.0

    # --- Janet ---------------------------------------------------------------
    scene bg undercroft_corridor with fade_slow
    show vignette
    play music m_driftwood fadein 3.0
    call place("Beneath the church")
    "Iron at her wrists. Stone under her feet, then under her knees when she fell, then under her feet again when the chain hauled her up."
    "Janet was dragged through the sweating dark in what they had left her, the undergarments clinging cold to her bruised skin, her hair a tangled veil over her face. She tried to cover herself. The chain did not pause."
    jth "Amanda. Please don't come. Please."

    scene bg cell_abomination with dissolve
    show vignette
    play sound sfx_thud
    "A door forced open, metal on metal. The chamber beyond sank into a damp silence that smelled of mold and rust. The stone walls glistened; the place seemed to sweat."
    show markus fervent at right with dissolve
    "Markus stood at a wooden deck in the center, planks swollen and warped. Something lay on it, unwrapped from damp cloth: a syringe, long, archaic, its steel body gone dull with years, its tip wickedly sharp. More relic than tool."
    "He had been standing over it, staring. His hand, when he turned, had been trembling. It stopped."
    "On the far side something crouched in the dark, its outline barely visible in the shiver of lantern-flame. It did not move. It did not need to. Its stillness was worse than frenzy, like a storm holding its breath."
    show michael neutral at left with dissolve
    mi "Here."
    "Michael flung her down. Janet hit the stones with a dull thud, a cry breaking from her throat as her knees scraped. She curled instinctively, arms crossed over her chest, shoulders shaking."
    "Markus watched her in silence, grinning. He let her feel the weight of the chamber: the dripping walls, the lurking shape in the corner, the syringe gleaming faintly between them. Only when her whimpers quieted did he step closer."
    mk "Welcome, Janet."
    "Almost tender. Almost kind. But the grin remained."

    menu:
        "Say nothing.":
            "She pressed her lips shut so tightly they quivered and bowed her head, as though refusal could make her invisible."
        "Answer him.":
            "Her mouth opened. Nothing came. She pressed her lips shut so tightly they quivered and bowed her head, as though refusal could make her invisible."

    "Markus hardly noticed. He wasn't speaking to her anymore. He tilted his chin toward Michael. A silent summons."
    "Michael stepped closer, his broad frame casting a deeper shadow across her. The same iron calm, but his eyes were fixed on Markus with a rare hunger. The patience of a hound at its master's heel."
    jth "Tonight he's going to reward it."
    mk "The rituals were always wrong. Even the so-called improvement made a few centuries back — the bloodline binding — was a half measure. Not enough. They scraped at the edges of truth, but never reached it."
    "He gestured sharply, dismissively, as if erasing centuries of ritual with one sweep of his hand."
    mk "I know how to fix it. I know how to complete it. And more than that — I know how to hold the power of God in my own hands."
    "Michael's jaw tightened, though not in doubt. His eyes widened; a glimmer of rapture sparked there. His breath caught, just enough to betray it."
    mi "How?"
    "Hoarse. Caught between command and prayer. Markus's grin widened. He had been waiting for this."
    mk "The problem is that humans are weak. Frail shells. And the abominations are proof. Living proof. You see it with your own eyes — they are not divine, not holy. They are corpses trying to walk with fire still inside them."
    "He gestured toward the corner, where the thing crouched in silence."
    mk "They cannot contain it. It burns them. Destroys them. That's the truth of what happens when the divine and mortal try to fuse."
    "He paced slowly, boots clicking on the damp floor, his gaze never leaving Michael's. He jerked his chin at Janet, and she flinched without seeing his eyes."
    mk "Humans like her — the so-called vessels — they were never chosen by God. Never touched by fate. Always a lie. A trick. Kalinos confessed it to me years ago, when his tongue was loose with age."
    mk "The vessels were picked at random, at the convenience of the Arch-Priest. The girl who happened to be pure. The widow's daughter who wasn't wanted. The one who hadn't spread her legs, or the one the priest held a grudge against. That was the measure."
    mk "Animalistic bullshit dressed as sacred order. Power games. Nothing more."
    "His voice rose with venom, echoing across the chamber until Janet's chains rattled with her trembling. His finger stabbed the air at her like a knife."
    mk "So this bitch here — is nothing. Nothing special. Just another offering thrown to the teeth of a God that never cared. A sacrifice for priests who wanted to keep their thrones warm."
    "Janet's breath hitched. She did not look up. Her shame, her fear, coiled tighter. The sneer shifted back into the grin. He leaned toward Michael, eyes bright with feverish conviction."
    mk "So Kalinos asked me — begged me — to bring an outsider this time. Something to silence the doubters, something he could pass off as divine inspiration. And so I did. I brought her."
    "His grin widened into a mad smile."
    mk "But Kalinos got what he deserved."
    stop music fadeout 1.0
    "He flicked the wheel of his lighter. The tiny flame shivered, caught the end of a torch, and bloomed."
    show abomination chained at center, dimmed with flash
    "The chamber flinched under the sudden glow, shadows peeling back like a curtain. Janet's eyes lifted, unwilling, dragged by instinct. And then she saw."
    play sound sfx_tinnitus
    "Her scream tore loose before she could form breath, raw and hysterical, echoing off the stone and coming back mangled, as if the walls had joined in. Her body convulsed against the chains. She could not look away."
    "It wasn't a figure. It wasn't an animal. It was presence. Vast, wrong, crushing. A shape that devoured space rather than occupied it, as if the torchlight bent away from it."
    "Michael did not scream. His throat clicked once. He did not move forward and he did not move back. He stood like a man who had expected the face of God to be beautiful, and found it was made of ruin."
    "The thing stirred. Her scream seemed to feed it. A sound rose from its chest, not a roar, not a snarl, but something guttural, retching, like it was trying to vomit out a human word it could not form."
    "The girl screamed, the creature answered, two broken halves of a hymn forced together. Markus smiled, teeth flashing in the firelight, and let it swell. Then his smile vanished. His voice cut the air like iron."
    mk "Silence."
    with hpunch
    "The word dropped like a stone into the chaos. And at once, silence. Janet's scream died in a choked sob. The thing froze, its chest rumbling faintly, then collapsing into a single hiss. Both knelt before the command. Not in gesture. In fact."
    "The fire crackled, the only sound left. Markus lifted the torch higher, the grin creeping back, took the syringe from the deck, and walked toward the thing."
    ab "Mar… kuuuss…"
    "He grabbed it by its skeletal neck and stabbed the syringe in. It did not move. It did not react. The liquid he drew glistened like spoiled wine, thick and purple-red, almost black where it caught the torchlight."
    "Markus turned, slow and deliberate. Janet tried to crawl back, chains clattering, but there was nowhere to go. He loomed over her, rolling his sleeve to the elbow with casual precision, a man preparing for a dinner table ritual."
    play sound sting_reveal
    mk "Time for my medication."
    "Voice dipped in irony. A smile that showed more teeth than comfort. He sank the needle into his arm without hesitation. The plunger depressed with a wet click, and the black-red fluid surged into him."
    show markus ritual at right, tremble
    "The reaction was immediate. His back arched, tendons standing out on his neck like cords, breath tearing through his chest in ragged bursts. His face twisted between agony and ecstasy. Veins rose purple beneath his skin, spreading like a map of corruption."
    "Janet pressed herself to the wall, nails scraping stone, mouth open in silent horror. Michael froze, something breaking at last through his stoic mask: fear, mingled with awe."
    show markus fervent at right
    "Markus staggered back a step, then two, one hand on his chest as though steadying a furnace inside him. His breath slowed. His spine straightened. The grin returned, wider, crueler. When he looked up his eyes burned. Not glowing. Fever-bright, like embers under ash."
    mk "Humans. Humans are weak. Their flesh rots before it even learns to endure. But I am not entirely human. Not for a long time now."
    "The words slithered into the room like scripture. Michael's composure shattered. He took a half-step forward, almost involuntary, a disciple seeing his god step down from the altar. For the first time in years his face broke into something raw. Joy. Pure, unfiltered joy."
    "Markus saw it. He savored it. Behind them the thing stirred, hollow lungs wheezing, twitching faintly as though it sensed the theft of its own essence."
    jth "Whatever he's become… Amanda has no idea what she's walking into."
    "The bells tolled again, distant but unmistakable, their vibration crawling down the chamber like the voice of the church itself. Janet flinched. Michael turned sharply to Markus."
    mi "How do we proceed now? The bells are ringing. In less than an hour, the people will gather. They'll expect the ritual."
    mk "Oh, don't worry, my friend. The ritual will happen. They will have their spectacle. And I will make sure the seed will obey my will and grow inside her till the end."
    "He paced a small circle, the syringe dangling between his fingers, faint drips of dark fluid across the stone. His gaze came back to Janet, and she shuddered under it."
    mk "Both sisters will take part. Amanda will come. She's stubborn enough to bleed her way through the whole village if she must."
    "Michael's expression hardened into grim acceptance. A single nod. Markus crouched, bringing his mouth level with her ear. His words spilled out soft, intimate, soaked in venom."
    mk "And when she does, Michael… we will give them a performance. A hymn written in blood. The Ritual requires sacrifice — real sacrifice, not the hollow games Kalinos peddled for power."
    play sound sting_reveal
    mk "The fruit must be watered in kinship blood. Sisterly blood."
    "Janet's body jolted, chains clattering, her throat tightening until her breath came in a ragged sob. He brushed her damp hair back from her face, almost tenderly. She recoiled from his touch."
    mk "Her sister must die before the Tree."
    mk "Amanda's veins will feed the roots. And only then will the fruit be worthy. Only then will it pulse with His breath."
    "He leaned back, eyes glittering, and met Michael's stare again."
    mk "And then… our dear little vessel here will take her part. She will eat of the fruit, watered with her sister's blood. She will drink deep of His fire, and we will all witness the return."
    mk "And whether she survives or splits apart before us… it does not matter. Either way, the covenant will be sealed. Either way, the age of silence ends tonight."
    "The bells tolled again, closer now, like the world itself marking time. Janet pressed her chained hands to her chest, shaking her head. Her lips moved soundlessly, then burst out in a hoarse whisper."
    jn "You're insane…"
    "Markus straightened, the torchlight casting his shadow tall and jagged across the stone. He adjusted his sleeve, flicked the last drop of dark blood from the needle, and tucked the syringe back beneath the cloth."
    mk "I will wait for you at the ritual site, Michael."
    "Calm. Decisive. The tone of a man who spoke not of plans but of inevitabilities."
    hide michael with dissolve
    hide markus with dissolve
    "Then, without another glance, he seized her chains and yanked. She stumbled forward with a strangled cry, knees scraping stone, the iron links cutting into her wrists. He dragged her toward the door, ignoring her thrashing, ignoring the way her voice cracked into sobs."
    hide abomination with dissolve
    "Behind them the thing shifted in the shadows, its low growl rising like a farewell hymn. The hinges groaned. For one moment the chamber filled with the storm's distant rumble, the echo of bells, and Janet's terrified gasps."
    play sound sfx_thud
    scene black with fade
    "Then the door slammed shut, sealing the sound away."

    jump ch13
