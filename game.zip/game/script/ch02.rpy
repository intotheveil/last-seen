## Chapter 2 — "The Drained Lake"
## Source: docs/manuscript/ch02.txt l.3–106. Amanda's evening (her POV: no amanda sprite), then Janet at the old
## bar (her POV: no janet sprite), then Markus leaving his city flat (his POV). No violence beats.
## Three choices, all converging within a few lines. Three note() entries (what Amanda keeps).
label ch02:
    call chapter_card(2, "The city — an autumn evening")

    scene bg city_park_dusk with fade_slow
    play ambient sfx_wind fadein 2.0
    play music m_records fadein 2.0
    call place("The city — autumn, dusk")

    "The park had always been there, tucked between apartment blocks and the main avenue, but it looked as though time had forgotten it."
    "A handful of thin, weary trees leaned under the autumn sky, their leaves brittle and spotted with yellow. Beneath them the grass had thinned into patches of dirt and weeds."
    "At the center lay what had once been a lake — a shallow basin of cracked stone and dried mud. Children no longer came here. The silence of the lake spread outward, weighing on everything around it."
    "An old wooden bridge bent across the hollow basin, its spine warped and silvered by years of sun and rain. One board had already broken clean in half, leaving a dark gap to step over."
    "Autumn had grown harsher in recent years. The winds no longer arrived as a whisper but as a force that stripped branches bare in a single night."
    "The air smelled of wet earth and rust, as though the season itself was corroding everything it touched."

    scene cg bridge with dissolve_slow
    window hide
    pause 2.0
    window auto
    "Amanda crossed with the certainty of someone who had no time for hesitation. Her heels clicked against the warped boards, forcing the bridge to answer with its own brittle complaints."
    "The wind caught her coat — dark blue wool, cut straight at the shoulders — and whipped strands of dark hair across her face. She brushed them back impatiently, eyes fixed ahead."

    menu:
        "Step over the gap without slowing.":
            "She lengthened her stride and took the broken board in one step, the way she took everything: measured, unbroken, her jaw set."
            "Below the gap, in the dry basin, lay what the water had left behind — scattered bottles, a rusted shopping cart, a film of dust the wind pushed in lazy spirals."
        "Stop at the rail for one breath.":
            "She stopped — one breath, no more — and the bridge trembled and groaned under her even in that stillness, its voice a tired echo over the silence of the park."
            "Once it had carried families across a lake that glittered in the evenings. Now it clung stubbornly to its place, as if unwilling to surrender."
            "One breath. Then she stepped over the gap and walked on."

    "She was tall enough to command presence, but carried herself with the controlled economy of someone accustomed to boardrooms and deadlines."
    "Yet her face betrayed her — faint shadows under the eyes, lips held too tightly, the subtle tension of a woman who hadn't rested in weeks."
    "Her fingertips paused a moment too long at her temple before tucking the strands behind her ear. The gesture was careful, practiced, but not quite steady."
    "Her lips parted, catching the faint trace of red that still clung there. The color had thinned; she worried at it unconsciously, a small bite as her eyes measured the distance ahead."
    "When the wind surged again she drew her shoulders square and lengthened her step — the look of someone who would not allow the world to see the weight pressing inside."

    scene bg city_corner_pizzeria with dissolve_slow
    "A few moments later she reached the corner, where the park bled into the city. A traffic light pulsed red against the deepening dusk, its glow reflected faintly on the wet asphalt."
    "Across the street stood a small, old pizzeria — Thomas Pizza. Its neon sign flickered weakly, humming as if struggling to stay alive, casting uneven patches of red and green across the façade."
    "Once, perhaps, it had been a warm corner for families and late-night laughter. Now it looked more like a survivor, clinging to routine in a neighborhood that had stopped caring."
    "Thomas was sixty-five and still worked every day behind that counter: a large man filling the narrow kitchen doorway, apron always marked with tomato sauce, the smell of basil following him more faithfully than any cologne."
    ath "As long as I prepare the food, the quality will remain the same. That was his line. He wasn't wrong."
    "Amanda often ordered from his place, not because she craved pizza, but because her schedule rarely gave her the luxury of cooking."
    "The warmth of his food, the small familiarity of his smile at the counter, had become a quiet fixture in her life — a comfort she barely noticed until now, standing at the light with the neon flickering in the distance."
    "The light changed, and Amanda crossed. A faint warmth of oregano and baked dough slipped through the doorway when someone exited, but she barely slowed."

    scene bg apt_building_door with dissolve
    stop ambient fadeout 2.0
    "At the next corner she stopped before a tall metal security door, its surface dented and scarred with scratches. She pressed the handle; it resisted for a moment before giving way with a reluctant creak."

    scene bg apt_foyer with dissolve
    "Inside, the air was stale, faintly metallic, and the fluorescent tube overhead buzzed with a dull, uneven light."
    "Paint peeled in narrow strips along the stairwell, the tiles dulled with age, the elevator doors bruised by countless careless hands. The building hadn't seen a single renovation since the day it was built."
    "The tenants liked it that way. Every monthly assembly dissolved into bickering: whether the cleaning lady's modest salary could be cut further, whether someone's bicycle had been chained too long in the hall."
    "Amanda had attended once, to raise the matter of her radiator sputtering cold air in winter. It had ended, as always, in sighs and shrugs. Nothing was fixed. She rarely went anymore."
    "A few steps before she reached the elevator, the metal doors creaked open with their familiar complaint. Out stepped Tania, her next-door neighbor."
    "Tania cracked a smile — one of those quick, glossy things that never reached the eyes. Amanda returned it with the same measured politeness, two actors repeating a scene they both knew too well."
    "Twenty-four, maybe twenty-five, though she dressed younger. Hair teased, lipstick precise, eyeliner sharp — and the longer Amanda looked, the more the polish thinned: a strand sprayed loose, lipstick bled at one corner, a fingernail chipped."
    "She was undeniably pretty. But the effort was obvious, the execution hurried, and to Amanda that made it worse."
    "Tania worked nights, most likely as a hostess or PR girl in one of the clubs downtown, and came home late, heels louder than the elevator, her voice spilling into the corridor long after midnight."
    "Amanda kept her polite smile in place until Tania passed. Then she let it fade, pressing it back into the silence of her own thoughts."
    "The perfume lingered in the hallway after her — sweet, with a faint woody depth. Yves Saint Laurent, Amanda thought, though she couldn't be certain."
    "Amanda herself rarely used perfume, never had the patience for it. But Janet did."
    "Her younger sister filled every room with it, one bottle after another, an arsenal of scents lined across the dresser they had once shared."
    "Each one clung to memory: a laugh in their old kitchen, a late-night argument, the slam of a bedroom door followed by the waft of some new floral brand."
    "Now, in the dim corridor, Amanda caught herself inhaling more deeply than she meant to. The smell wasn't Janet's, but it tugged her mind toward her anyway, a reminder carried on someone else's careless excess."

    scene bg apt_elevator with dissolve
    "Stepping into the elevator was like walking into a gas chamber: perfume, sweat, the faint sourness of damp metal. Strong scents made her chest tighten, her breath feel borrowed."
    "Yet when she had lived with Janet it hadn't bothered her. She had adapted; the scents had become part of the texture of their life together. Familiar, irritating, comforting all at once."
    "She drew in a long, steady breath and pressed the button for the fourth floor. The doors, groaning as though exhausted by years of reluctant service, slid together inch by inch until they sealed her in."

    scene bg apt_corridor with dissolve
    "The corridor stretched ahead in its usual state of neglect. Half the ceiling bulbs were dead; the others buzzed or flickered in uneven rhythm."
    "At the far end a potted plant clung to its last leaves, its twisted shadow thrown tall against the wall. In the dimness it always looked like some gaunt figure waiting to lunge."
    "Amanda quickened her pace — not because she was afraid, but because the sight of it, day after day, irritated her. Another reminder of the building's disorder pressing against her need for control."

    scene bg amanda_living with dissolve
    play music m_grief fadein 3.0
    "A sharp click as the lock turned. Amanda stepped inside, slipped off her shoes with a practiced movement, and reached for the switch."
    "The overhead lights blinked to life all at once, flooding the space with a sterile white glare so intense it felt more like a surgery room than a home. She preferred it this way — clean, unyielding, without shadows."
    "The apartment was larger than most in the building, yet nearly empty. Minimalism had become her armor: two tall bookcases, a long sofa angled toward a seventy-two-inch screen, and in the far corner her desk, the design tablet waiting in silence."
    "By the entrance, two framed photographs broke the austerity."

    menu:
        "Look at Janet's graduation.":
            "Janet radiant, laughing with her diploma in hand; Amanda beside her, serious as ever, yet her eyes betraying quiet pride."
            ath "She made me stand for eleven takes. I'd have stood for a hundred."
        "Look at their parents' wedding.":
            "Their parents — both smiling, both alive, both frozen in a joy that time had stolen."
            "Amanda had always loved that photograph. That was how she wanted to remember them: beautiful, happy, untouched by the weight that had since fallen on their daughters."
        "Keys down. Don't look tonight.":
            "She set her keys down without looking, the sound sharp against the silence. The two frames waited by the door the way they waited every night: Janet laughing with her diploma; their parents, both smiling, both alive."
            "She knew them without looking. That was the point of not looking."

    "The living room opened into a kitchen of gleaming steel, every appliance showroom-new, arranged with the same precision as everything else. Almost never used."
    "Almost."
    "The exception sat in the corner: the espresso machine, its shell smudged with fingerprints, the drip tray faintly stained, a small clutter of capsules stacked carelessly beside it."
    "It was the one object Amanda allowed to fall out of alignment, the single thing she touched every day without worrying if it fit the image of control she maintained everywhere else."
    "She let the apartment settle around her — a space filled more with echoes of memory than with life."

    scene bg amanda_bedroom with dissolve
    "In the bedroom she reached for the comfort of simplicity: a plain white T-shirt and a pair of loose blue shorts. The black jeans and the grey shirt went into a neat pile across the bed. Even in small habits, order was her instinct."

    scene bg amanda_bathroom with dissolve
    "The tap squeaked. Cold water splashed against her face and ran down in quick rivulets that left her skin tingling. She lifted her head, drops clinging to her jawline, and faced the mirror."
    "Her hair was uneven from the wind, dark strands clinging to her cheeks. Her lips carried only the faintest trace of the morning's soft red, mostly bitten away, the color broken and uneven."
    "Her eyes — sharp, intelligent, a gray-blue that could appear almost cold — revealed more than she wanted them to. Tiredness sat beneath them in soft shadows, and in the depths a quiet unrest that work and discipline never seemed to erase."
    "She was three months away from her thirty-second birthday, yet past the tiredness she appeared much younger. Her skin was smooth, unmarked, carrying a clarity that drew attention even under the unforgiving light."
    ath "I like to think it's the bare face. No layers, no powders. Discipline."
    ath "But Janet has been painting hers since her early teens and it's just as flawless. It isn't discipline. It's blood. Mother's genes — neither of us earned them."

    scene bg amanda_kitchen with dissolve
    "Back in the kitchen she slipped a capsule into the machine with the same precision she used every evening. The hum and hiss of water filled the silence as she scrolled through a flood of unread emails."
    play sound sfx_beep
    "A notification blinked at the top of the screen. A calendar reminder."
    note_voice "Tomorrow: Strategic Planning Meeting — 9:00 AM"
    "Her chest tightened. For a moment her heartbeat drummed faster, each thud echoing in her ribs — a table of expectant faces, lines polished yet hollow, the familiar edge of anxiety clawing back to the surface."
    "She set the phone down, exhaled slowly, and opened the fridge. Bottles turned forward, containers stacked. She reached for a plastic-wrapped tray of lasagna — her usual dinner when work stole the hours — and let the microwave hum to life."
    "The coffee machine clicked as it finished, the smell of roasted beans filling the sterile room. Amanda wrapped her hands around the warm cup, trying to smooth the rising knot in her chest. Then she pulled the phone closer."
    play music m_emily fadein 3.0
    "She typed a quick message to her sister, thumb moving almost without thought."
    note_voice "Hey, how are you doing? You're really going away for the next few days, right?"
    "The screen lit almost instantly."
    note_voice "Yes, all set. Don't worry. It'll be good for me."
    "A smiling face after it, the way Janet signed everything."
    $ note("Yes, all set. Don't worry. It'll be good for me.")
    "Amanda's lips softened into a small smile — the kind that came naturally only with her sister. She let the words sit there a moment longer than necessary, her thumb hovering in hesitation."

    menu:
        "Ask where, exactly.":
            ath "She's a grown woman. She can go where she likes."
            ath "Where, exactly?"
        "Let it go. She's a grown woman.":
            ath "Let it go. She's a grown woman. She doesn't have to file a route with you."
            "Her thumb hovered. Then it moved anyway, the way it always did."

    note_voice "Where exactly are you two going?"
    "For a few seconds the screen stayed blank. Amanda's brow tightened, her jaw setting in that familiar line of impatience she could never quite hide. Then the bubbles appeared."
    note_voice "Markus wants to take me to his village — Driftwood Bay."
    $ note("Markus wants to take me to his village — Driftwood Bay.")
    "Her smile thinned. The name felt strange on her tongue even as she read it silently, a faint crease forming at her forehead."
    "She thumbed the name into the map before she could stop herself. A speck on the coast, three hours down. Nothing else. She closed it."
    $ note("Driftwood Bay. Three hours down the coast.")
    note_voice "If you need anything — money, clothes, whatever — just let me know."
    "The answer came fast: a wink. Amanda exhaled through her nose, half amused, half unsettled."
    "Her mouth curved at the corner, but her eyes had that sharper look — the protective flicker that always betrayed her, the quiet parent's worry she couldn't switch off no matter how grown Janet claimed to be."
    play sound sfx_beep
    "Then, sharp and sudden, the microwave beeped. The sound tore through her thoughts, snapping the spiral of worry in two."
    "For an instant she just stood there, the reminder of tomorrow still echoing faintly in her mind, before she turned toward the machine and pulled open the door."

    scene bg amanda_living with dissolve
    stop music fadeout 2.0
    play music m_records fadein 3.0
    "Amanda carried the plate to her desk and took her first bite as the computer came to life with its usual low hum. Headphones over her ears. Another bite. The design software, always slower to load than she liked."
    "Layers and lines, grids and palettes: the tools of her order, the structure she understood."
    "For a moment she let herself sink into the rhythm — the taste of food, the pulse of music, the soft glow of the screen promising another night of work."
    "Her playlist rolled forward to one of her favorites. She closed her eyes briefly and let the steady build of the song carry her while she finished the last of her meal."
    "But her thoughts had already drifted toward tomorrow. A potential client with the power to assign her firm a major project — the design and construction of a new data center."
    "It wasn't just another contract. It was the kind of undertaking that could mark her name in bold inside the company, the kind people remembered."
    ath "The presentation has been ready for a week. Every slide rehearsed, every number checked. I don't need more practice. I need this weight off my chest."
    ath "And there's no better cure than work. Plans, models, designs — the order I can control. Unlike tomorrow's boardroom."
    "The final refrain echoed in her ears like a mantra she wanted to believe: trade this life for something new. Amanda straightened in her chair, hands already moving across the keyboard, ready to lose herself in the clean geometry of her work."

    scene bg old_bar_ext with dissolve_slow
    show vignette
    play music m_night_drive fadein 3.0
    "Outside, the city stretched on — streets branching like veins, lights flickering against the dusk."
    "Somewhere beyond that web of concrete and glass, across the slow crawl of traffic and the scattered hum of late-night lives, her sister Janet moved through a different silence."
    "Where Amanda sought order, Janet carried the weight of disarray. And while Amanda steadied her thoughts with numbers and designs, Janet's heart was already racing for reasons that had nothing to do with meetings or clients."

    scene bg old_bar_int with dissolve_slow
    show vignette
    play ambient2 sfx_crowd fadein 2.0
    call place("The old bar near the coast — the same night")
    jn "You know what's been driving me mad lately? At work, they treat me like I'm just… decoration. Like I'm some plant in the corner, or a piece of meat they trot out when they want clients to smile."
    jn "Nobody asks what I actually think, or lets me do more than nod and fetch numbers. It's exhausting."
    "She paused, rolling her eyes, then smirked a little."
    jn "Well… I suppose I can't entirely blame them. I mean, look at me."
    "A small laugh, light but edged, as though mocking herself before anyone else could."

    scene cg janet_bar with dissolve_slow
    window hide
    pause 2.0
    window auto
    "The words rolled off the lips of a brunette young woman, her voice low but edged with certainty. Janet."
    "She sat at the far end of a crowded bar, her university friends leaning in around her, drinks sweating on the table. She held the center of attention without effort."
    "Dark hair framed her face in soft waves, catching the dim glow of the lamps. Her eyeliner, bold and precise, gave her the kind of eyes that seemed to look through people rather than at them."
    "Her lips curved into a knowing half-smile, the kind that made every word sound both playful and dangerous. One arm draped over the chair, the other hand tracing lazy circles around the rim of her glass."
    "The bar was one of the oldest in the area, its wood darkened by decades of nights. Unlike the beach bars along the coast it had never surrendered to loud music or tourists: low jazz, faint rock classics, or nothing but the hum of voices."
    "Janet was as luminous as the bar was muted, her intensity a counterpoint to the stillness that surrounded her."

    scene bg old_bar_int with dissolve
    show vignette
    show myriam grin at center with dissolve
    my "I think you secretly love it. All that attention — you'd miss it if they stopped staring."
    "Teasing, not cruel: the kind of jab only close friends could get away with. Myriam, a couple of years younger than Janet, and one of her closest companions."
    "Janet narrowed her eyes into a mock glare, chin tilted, lips pressed into a line as if about to issue some cutting retort. Then her face broke into laughter — low, warm, with that subtle, inviting edge that always clung to her."
    jn "Oh, you got me there."
    fr "Told you. Told you she'd cave."
    "The table broke into an easy chorus of amusement. Glasses clinked, shoulders brushed, and for a few moments the old bar echoed with the uncomplicated sound of friends laughing together."
    play sound sfx_phone
    "Janet's comfort was broken by the faint buzz of her phone against the table. She glanced down."
    note_voice "Markus"
    jn "Excuse me, one second."
    hide myriam with dissolve

    scene bg old_bar_ext with dissolve
    show vignette
    stop ambient2 fadeout 1.5
    play ambient sfx_wind fadein 2.0
    "She slipped through the press of tables and out the door, where the air was cooler and quieter. With her back against the wall of the bar, she answered."
    show screen phone_call("Markus")
    jn "Hey you."
    "Her tone warmed instantly."
    mk "Just checking in — everything still good for tomorrow? Bags packed? I don't want you bailing on me last minute."
    "His voice carried through the line, steady and familiar. Janet let out a small laugh, rolling her eyes though he couldn't see it."
    jn "As if. We've been planning this for weeks, Markus. I'm not backing out now."
    mk "Good."
    "She could hear the smile in his voice."
    mk "It'll be an early start. I'll pick you up first thing, same as we said. Coffee, and the road."
    "The excitement she'd been trying to hide from her friends spilled into her voice."
    jn "I can't wait. It'll be nice to escape the city for a bit."
    mk "Then it's settled."
    "His voice softened."
    mk "Sleep well, Janet."
    jn "You too. Goodnight."
    hide screen phone_call
    "The line clicked off. Janet tucked her phone back into her bag, her smile still hovering as she turned and walked inside, where laughter and voices waited to swallow her up again."

    scene bg markus_city_flat at night with fade_slow
    show vignette
    stop ambient fadeout 2.0
    stop music fadeout 2.0
    call place("Miles away")
    "Miles away, Markus ended the call with a quiet smile lingering on his lips."
    "He stood for a moment in the dim half-light of his apartment, the glow from a single lamp stretching long shadows across the bare walls."
    play music m_long_road fadein 4.0
    "Reaching for his coat, he slid it over his shoulders with a practiced ease. The silence of the room clung to him, heavy, as though it resented being disturbed."
    play sound sfx_thud
    "Without a backward glance, Markus pulled the door shut behind him, his footsteps fading into the corridor as the lock clicked into place."
    scene black with fade_slow
    pause 1.5

    jump ch03
