## Chapter 5 — "The Project Is Yours"  (ch04.txt l.134–232; Amanda POV)
label ch05:
    call chapter_card(5, "The office — the meeting moved up")

    scene bg office_tower_ext with fade_slow
    play music m_markou fadein 2.0
    call place("The office tower — morning")

    "The tower rose clean and sharp against the skyline, its glass face holding the pale autumn light. Modern without being ostentatious: steel and glass that spoke of function, not extravagance."
    "Revolving doors, a lobby of polished stone, security guards in dark suits with the same professional nod for everyone. Amanda passed through the gates with the practiced ease of someone who belonged."

    scene bg office_corridor with dissolve
    "Fourth floor. By the time the doors parted her expression had already shifted — outwardly composed, inwardly focused. White walls, dark-framed doors, potted greenery."

    scene bg amanda_office with dissolve
    "Her office sat midway down the hall behind a frosted glass nameplate. A wide desk facing the window, shelves stacked with binders, the personal touches kept to a minimum."
    "She set the laptop in its place, pulled the slim folder free and opened it. For a moment she stood there holding her proposal in both hands, her eyes tracing the cover sheet."
    "A small smile tugged at her lips — satisfied, confident. Beneath it, a current of anxiety, insistent, never fully silenced. She closed the folder and set it down flat."
    "The clock ticked softly in the corner. Two full hours until the meeting. Time to prepare again, if she wished. Time to relax, if she could."
    ath "But first, coffee."

    scene bg office_kitchen with dissolve
    "The quiet hum of the refrigerator. A mug beneath the sleek machine, the soft gurgle of water through the grounds, the sharp, earthy aroma rising around her like a familiar blanket."
    "She cradled the mug in both hands and savored the first sip. Hot, bitter, grounding. The door opened behind her."
    show helen smile at right with dissolve
    "Helen, head of the commercial department. Impeccably dressed, lipstick perfect even at this early hour, carrying herself with the relaxed confidence of someone who thrived in corporate halls."
    "She offered Amanda a quick smile, one that didn't quite reach her eyes, and moved to the machine. The hiss of steam filled the pause. Sugar stirred in; the spoon tapped lightly against the rim."
    he "Oh, Amanda. Good that I ran into you. I forgot to email you, but the meeting today has been moved up. One hour earlier."
    am "Earlier?"
    he "And their CEO will be present too. He arrived yesterday afternoon by plane."
    "Amanda froze, the mug halfway to her lips. Her pulse spiked, thudding in her chest, each beat faster than the last."
    am "Their CEO will be here too?"
    "The words came out quieter than she intended. Helen shrugged and sipped without concern."
    he "Oh, yes. The project's too big for him not to be. He wants to make sure we know what we're doing."
    "She stepped closer. Her perfume was faintly sweet, edged with something metallic. She leaned in just enough for her words to drop low."
    he "Don't screw this up."
    "Then she pulled back, her voice rising cheerfully, as if nothing had been said."
    he "You'll be fine."
    "A bright, performative grin. She turned on her heel and walked out, her heels tapping briskly down the hall."
    hide helen with dissolve
    $ note("The meeting — moved up an hour. Their CEO flew in yesterday.")
    $ note("Don't screw this up.")

    stop music fadeout 2.0
    "The door clicked shut and silence rushed back into the kitchen. Amanda stood motionless, her hand trembling slightly around the mug. The warmth no longer comforted her; it seemed to burn against her skin."
    ath "This bitch."
    ath "Helen surely did it on purpose, not telling me. She wanted me blindsided. Cornered."
    "Her jaw clenched, her breath quickened. Her heart pounded against her ribs, heavy, insistent, as if each beat were a reminder of time slipping away. Thirty minutes. That was all she had."

    menu:
        "Change the pitch. Adjust the flow.":
            ath "Change the pitch? Adjust the flow? No — there isn't time. God, there isn't time."
        "Hold the line. The slides are the slides.":
            ath "The slides are the slides. Weeks of them. Built for directors, for managers — not for him. And there isn't time to make them his. God, there isn't time."

    "Her mind ran in circles through her slides, her script, her careful preparation. Everything she had built over weeks now felt flimsy, inadequate, not tailored for the presence of someone like him."
    "The CEO. The word alone pressed on her chest. Directors, managers, decision-makers — important, yes, but manageable. The CEO was another world, another scale of scrutiny entirely."
    "She pressed the mug down onto the counter hard enough that the ceramic clinked. Her reflection wavered faintly in the dark surface of the coffee."
    ath "If he's here, everything changes. He won't care about the details, the flowcharts, the projections. He'll look for weakness. He'll test me. And if I falter—"
    "Her palms had gone damp, her body stiff with the sudden surge of adrenaline. She pressed her fingers to the counter and forced a breath in, then another out."
    "Then something shifted. A faint lightness rose in her head, as if the ground had tilted ever so slightly. She blinked hard, but the dizziness clung. Her pulse throbbed at her temples. The coffee sat heavy in her stomach, sour."

    scene bg office_corridor with dissolve
    play sound sfx_heartbeat
    "She pushed away from the counter, one hand gripping the strap of her bag, the other brushing the edge of the cupboards to guide her balance. Her heels clicked too loudly, uneven, betraying her."
    "The hallway stretched longer than usual, sterile white walls pressing in, fluorescent bulbs humming faintly, almost mockingly."
    ath "Not here. Not now."
    "Her vision swam as she passed the office doors; the names on the plaques blurred together. She focused only on the familiar blue sign at the far end: Restrooms."
    "A pair of colleagues passed her, their conversation low and casual. She kept her head down, jaw clenched, praying they didn't notice the sheen of sweat beading at her brow."

    scene bg office_restroom with dissolve
    "The cool air inside hit her like a slap. The room was empty, mercifully. She made her way to the sink and gripped its edge, her reflection swimming in the mirror."
    "Her chest rose and fell too quickly, shallow breaths stacking on top of one another. She shut her eyes, fighting to slow them, but the dizziness persisted, threatening to pull her down into the tiled floor."
    ath "Get it together."
    "Her knuckles whitened against the porcelain, but her grip couldn't hold back the wave rising inside her. A sour churn climbed her throat with a violent insistence. Her breath hitched."
    play sound sfx_tinnitus
    "She turned abruptly, stumbling toward the nearest stall. The metal door swung inward with a hollow creak, and she dropped to her knees just as the nausea broke free."
    "Her body convulsed, the sound harsh in the sterile emptiness. Bile seared her mouth. She gripped the cold edge of the bowl, her forehead pressed against the chill of the porcelain as if the contact might ground her."
    "Her ears buzzed — a faint vibration at first, then louder, until it filled her head like the echo of some distant machinery. It dulled everything: the lights, the disinfectant, the metallic tang of the lip she had bitten."
    "The world narrowed. Just the ringing, the sour ache in her throat, the hollow thud of her pulse in her temples. Tears stung her eyes. She let her body sag, her cheek against the cold steel divider."
    ath "This is weakness, and you cannot afford weakness."
    "The words stung almost as much as the acid in her throat. The restroom was still empty, silent but for her ragged breathing. No witnesses. No one to see the crack in her armor."
    "Her stomach clenched again, a painful aftershock, but nothing came this time. Only the raw burn, the hollow ache in her chest. She wiped her mouth with the back of her hand and stared at the graffiti-scratched door."
    "For a long moment she stayed there, forehead pressed to her sleeve, eyes shut tight. Standing felt impossible, as if the floor itself were trying to pin her down. But the clock was still moving. Twenty minutes. Maybe less, now."
    "With a slow, reluctant groan she pressed her palms against the wall and pushed herself up. Her knees wobbled; she breathed through her nose until the dizziness dulled. Step by step, she left the stall."

    menu:
        "Don't look. Not yet.":
            "She meant to keep her eyes on the faucet. She looked anyway. The mirror caught her immediately."
        "Face it.":
            "The mirror caught her immediately."

    "Pale skin, damp hair clinging to her temples, eyeliner smudged faintly beneath her eyes. Her lipstick, already faint, had vanished entirely. She barely recognized the woman in front of her."
    "She twisted the faucet open and splashed cold water on her face. The shock was immediate, cutting through the buzzing, the fatigue, forcing her back into her body."
    "A paper towel. The small makeup kit from her purse. With practiced motions, almost mechanical, she reapplied foundation, smoothed the eyeliner, freshened her lips with that soft red she always wore."
    "Layer by layer, the mask returned, hiding the collapse behind clean lines and quiet polish. When she finally leaned back from the mirror, her reflection looked composed once more."

    scene bg boardroom with fade_slow
    play music m_markou fadein 2.0
    call place("The boardroom")
    "The CEO leaned forward, his gaze sweeping across the table before it returned to Amanda. The air seemed to tighten; every set of eyes shifted toward him, waiting."
    "He clasped his hands together. The silence held a fraction longer, and then he spoke with a measured calm."
    ceo "Our board has reviewed your proposal in depth. And after what I've seen here today, I am convinced. We will move forward with your company. The project is yours."

    scene cg project_yours with dissolve_slow
    window hide
    pause 2.0
    window auto
    "The room moved on — voices rising, chairs shifting, pens scratching paper. Amanda remained still, her face schooled into that mask of seriousness, as though she had never doubted this outcome for a second. Outwardly calm, inwardly aflame."
    "It was almost too much to contain. The sensation coursed through her in waves — electric, flooding, overwhelming. It wasn't relief; it wasn't just pride. It was sharper, hotter, a thrill rippling under her skin until she felt lightheaded."
    "The pleasure was physical, undeniable. Her chest swelled, her throat tightened, her skin tingled. She could feel the dopamine surge ripple through her like a secret climax, one she carried in silence among the highest tiers of power and wealth."
    ath "Here, in this room. With them. And I prevailed."
    "The thought itself was intoxicating. And then there was Helen."
    "Seated two places down, Helen wore her usual confident poise, but Amanda didn't need to look directly to see through it. The corner of her eye caught the fleeting smirks, the twitch at the edge of the mouth, the darting of the eyes."
    "Helen's performance was slipping. She had never truly believed Amanda could deliver flawlessly. That betrayal of doubt radiated louder than words. Helen was surprised. Helen was rattled."
    "Amanda didn't grant her the satisfaction of acknowledgment. She never turned her head, never gave her even a glance. But her peripheral vision caught every flicker, every attempt to keep the mask intact. And that — oh, that — was the sweetest part."
    "To succeed in front of them all was victory. To succeed while Helen faltered was ecstasy."
    "Her pulse thundered, her body alive with it. She felt taller, sharper, more vivid than anyone else in that room. Every breath tasted rich, sweet, charged with power. The voices blurred into static, the buzzing in her ears humming in rhythm with her heartbeat."
    "The room was hers. They were hers."
    "She imagined how she must look to them now: steady, professional, controlled. A woman who had delivered perfection not because of luck, not because of circumstance, but because she expected nothing less from herself."
    "They would never know what was happening beneath her surface — that her body trembled with a private rush so sharp it bordered on the erotic. And that secrecy only deepened the pleasure."
    "She wanted to close her eyes, to lean back, to let the wave crest and wash over her. She didn't. Spine straight, hands lightly touching the cool glass of the table, face calm, untouchable. She performed control while drowning in triumph."
    "Helen shifted again. Yes, she had seen it: the disbelief, the quiet humiliation, the seed of envy. Amanda's lips threatened to curl, and she stopped them. To remain expressionless was the greater strike. To look as though none of this surprised her — that was power."
    "And inside, she felt superior. More than Helen. More than any of them. Even as the CEO spoke on about next steps, even as directors busied themselves with logistics, Amanda sat in silence, knowing she had conquered the moment."
    "The pleasure spread deeper now, slower, like fire settling into her veins. It was more than a win; it was affirmation of what she always told herself in the quiet hours when doubt crept in."
    ath "You are stronger. You are better. You cannot be broken."
    "And in that truth, Amanda felt something close to rapture."
    $ note("The project is yours.")

    scene bg boardroom with dissolve_slow
    "The room thinned slowly, the swell of conversation drifting into the corridor as one executive after another collected their papers, exchanged polite handshakes and disappeared through the glass doors."
    "The long table emptied, leaving behind the faint smell of coffee, a scatter of notepads, and the low hum of the projector cooling down."
    "Amanda remained at her seat, deliberate and unhurried, sliding her laptop into its case, gathering her folder with precise motions. Each action part of a ritual, grounding her after the storm of adrenaline."
    "When she finally stood, the silence seemed heavier, echoing against the glass walls. She slung her bag over her shoulder just as the door opened again and her supervisor stepped back inside."
    extend " A man of few words, efficiency rather than warmth; a faint smile, small, professional, but genuine enough."
    sup "Well done. That went better than expected. Much better."
    sup "Take the rest of the day off. You've earned it. Tomorrow, start outlining the next steps — scheduling, mock-ups, preliminary designs. We'll need momentum right away."
    am "Of course."
    "Another brief nod of approval, and he was gone, leaving her alone once more."

    scene bg office_corridor with dissolve
    "She exhaled, slow and controlled, and walked down the corridor, her heels striking softly against the carpet, the sound somehow sharper in her ears than the buzz of voices she passed."
    "At the elevator she pressed the button, waited, and when the doors parted stepped inside without hesitation."
    "For a fleeting moment Janet's face flashed in her mind — her sister's smile, the quiet reminder of why she pushed so hard, why every success had to matter."
    ath "I have to keep moving. For her."
    "The thought lingered like a hook in her chest. She dismissed it quickly, jaw tightening, forcing her focus back to the present."
    ath "Not now. Later."
    $ note("I have to keep moving. For her.")

    scene bg office_tower_ext with dissolve
    "By the time she emerged into the lobby the building had shifted into its midday rhythm — employees carrying coffees, voices blending into a low hum, the scent of perfume and paper. Amanda moved through it all like a shadow, her face calm, unreadable."
    "But inside, the victory still pulsed quietly, feeding her every step as she pushed through the revolving doors and out into the open air."
    stop music fadeout 2.0
    "Taxis idled along the curb, yellow doors opening and closing as people came and went. Normally she would have taken the metro — routine, efficient, predictable."

    menu:
        "The metro. Routine.":
            "She turned toward the station steps and stopped. Crammed carriages, the noise, the push of strangers pressing into her. Not today. She couldn't bear the thought of it."
        "A cab. Just this once.":
            "Not today. Today she couldn't bear the thought of crammed carriages, the noise, the push of strangers pressing into her."

    "She lifted a hand, and within seconds a cab pulled to the curb."

    scene bg taxi_int with dissolve
    play music m_records fadein 2.0
    "The driver, a middle-aged man with a trimmed beard and sun-worn skin, leaned across to unlock the door. His accent, when he greeted her, was thick and foreign, though warm and unbothered by the chaos outside."
    "She gave him her address and sat back, letting the city pass beyond the windows — neon signs, shops, pedestrians in hurried lines. The driver hummed softly in a language she didn't recognize, and for once she didn't mind. Background. Neutral. Detached."
    "The ride was quick, direct, without unnecessary chatter. Within twenty minutes the car slowed in front of her building. She thanked him curtly, passed the fare through the divider, and stepped out into the calmer rhythm of her street."

    scene bg amanda_living with dissolve
    call place("Home — afternoon")
    "The door clicked shut with a familiar finality. The stillness was immediate, wrapping around her like a shield. She set down her bag, slipped off her shoes, and crossed to her bedroom."

    scene bg amanda_bedroom with dissolve
    "There she peeled away the armor of the day. The blazer slid from her shoulders, the blouse unbuttoned with deliberate motions, the slacks loosened and dropped into the waiting heap on the chair."
    "As the fabric slipped past her thigh, a dark bruise surfaced — deep black at the center, blurred violet at the edges. She glanced at it once, no more. Some desk corner, some careless knock. It didn't matter."
    "She neither winced nor lingered; pain was irrelevant, appearance more so. In the muted light her body showed the results of discipline — long legs, toned arms, a waistline kept lean by effort rather than indulgence. The bruise spoiled nothing."
    "A plain black tank top, soft cotton shorts. She smoothed the fabric absently across her frame and tied her hair back loosely, strands falling where they pleased."

    scene bg amanda_kitchen with dissolve
    "The familiar gurgle of the espresso machine broke the silence. The scent of brewing coffee filled the apartment, warm and grounding."

    scene bg amanda_living with dissolve
    "She carried her mug to the desk in its corner. The computer blinked awake, the glow of the screen filling the dim space. A flick of her hand queued her playlist — steady beats, soft vocals, a rhythm that threaded neatly into her pulse."
    "Work unfolded, screen by screen, slide by slide. To anyone else it might have felt like returning to labor after a long morning. To Amanda, it was ritual."
    "The music, the coffee, the hum of her computer — all of it was hers, controllable, steady. The city buzzed outside, and Amanda sank back into her world, where precision and discipline ruled, and where she thrived most of all."
    "The hours slipped away unnoticed. Her fingers moved quickly, decisively across the keyboard, lines of text and design overlays filling the screen. Her coffee cooled in its mug. She rode the momentum of focus as though nothing else existed."
    "Slide after slide, model after model, everything aligned, everything under her control. The anxiety of the morning, the collapse in the restroom, Helen's venomous smile — all of it dissolved beneath the sharp discipline of progress."
    stop music fadeout 1.0
    call place("Early afternoon")
    "Until the phone rang."
    play sound sfx_phone
    "The sound cut through her headphones, shrill and insistent. It startled her, pulled her out of the trance in a single beat. She froze, her hand hovering over the keyboard, the glow of the monitor flickering against her face."
    "The ringtone carried on, echoing in the room like an intrusion. The phone lit up on the desk beside her — a name flashing across it."
    note_voice "Janet"
    am "Janet?"

    jump ch06
