## Chapter 1 — "The Flame Burns"
## Source: docs/manuscript/ch01.txt l.3–85. Prologue, Winter 2003. Markus (a boy of ten) is the POV: no sprite.
## Sofia is a CHILD: voice only (`sf`), never drawn. Beats 1–6 of docs/horror_beats.md are NARRATION ONLY or
## BLACK FRAME + SOUND; nothing of the act is ever in frame, in any mode. No menu in this chapter.
label ch01:
    call chapter_card(1, "Driftwood Bay — Winter, 2003")

    play music m_funeral fadein 2.0

    scene bg village_square_snow at memory with fade_slow
    show snow light
    show vignette
    call place("Driftwood Bay — Winter, 2003")

    "The hand that yanked Markus forward belonged to his father, rough and calloused, smelling of smoke and earth. He stumbled to keep pace, boots scraping the cobblestones."
    "The village was swallowed in night, the houses shuttered tight, though here and there he caught pale faces peering from cracks in the windows."
    "No one stopped them. No one ever did on this night."

    scene bg church_ext_snow at memory with dissolve_slow
    show snow light
    show vignette
    "The church rose black against the snow-flecked sky, its steeple crooked like a finger pointing at heaven in accusation. Markus had never entered it at night."
    "Now the great doors groaned open before them, spilling out a gust of stale incense and damp stone."
    mfa "Faster."
    "His father pushed him inside."

    scene bg church_stair at memory with dissolve
    show vignette
    "Down they went — not into the nave but into the stairwell at the side, a spiral curling into the undercroft."
    "The air thickened as they descended: colder, wetter, carrying the iron sting of rust and blood. Markus's breath clouded in front of him."

    # Beat 1 — the child dragged to the ritual: NARRATION ONLY over the empty circle.
    scene bg undercroft_circle at memory with dissolve_slow
    show vignette
    play ambient2 sfx_crowd fadein 3.0
    "At the bottom the chamber stretched out low and wide, its stone walls sweating with moisture, its archways lit by dozens of guttering candles. Shadows swayed over the faces of the gathered."
    "More people than Markus had ever seen in one place — men, women, old villagers bent like roots, and children a little older than him, all hushed, all watching the circle drawn in ash and chalk at the center of the floor."
    "And there she was."
    "Sofia."
    "He knew her from the bakery — flour dusting her hair, the way she always slipped him the corner piece of bread still warm from the oven. She had smiled at him only yesterday."
    "Now she crouched in the circle, iron chains biting her wrists, her eyes swollen with crying."
    sf "Please. Please, I didn't—"
    "Her own mother stood in the front row, head bowed, lips pressed tight. Her father's jaw was clenched, hands folded stiffly as if in prayer. Neither looked at her."
    show father neutral at left with dissolve
    "Markus's stomach twisted. His feet rooted to the floor, but his father's hand shoved him forward until he stood at the ring's edge with the other children."
    "His heart pounded so hard he thought the whole room must hear it."
    show kalinos neutral at midright with dissolve
    "A figure in black stepped forward — the First. His robe was thick, heavy, embroidered with symbols Markus did not yet understand. His voice carried low but sharp."
    kal "Tonight the tree bore fruit. Tonight the vessel must be tested."
    "The congregation answered in one breath, words old and jagged. Markus flinched at their force, at the way the sound seemed to rattle the stones themselves."
    sf "I don't want this! Mama, please! Papa—"
    "Her voice broke into a scream, raw and frantic."
    "No one moved."
    "The First produced a small object — a piece of fruit, dark and slick, its skin glistening like it had been plucked from something alive."
    "He raised it high, then lowered it before Sofia, holding it inches from her lips."
    kal "Eat."

    # Beat 2 — the force-feeding: BLACK FRAME + SOUND (child victim). Final in every mode.
    stop music fadeout 3.0
    scene black with fade
    "She shook her head, sobbing. Two men stepped forward and seized her jaw."
    "The fruit was smeared with blood. Markus heard the wet sound of it pressed past her teeth; a gag, a cough, a swallow in shuddering spasms."
    stop ambient2 fadeout 2.0
    "Silence fell."
    "For a moment nothing happened. Just Sofia trembling, eyes squeezed shut, chest heaving. Markus almost dared to hope—"

    # Beat 3 — Sofia's death: BLACK FRAME + SOUND. No image, no anatomy, no mature slot, ever.
    play sound sfx_thud
    with vpunch
    "Then her body convulsed. A sound tore from her throat, guttural, inhuman."
    play sound sfx_tinnitus
    "A crack — and the chamber erupted in screams. Some of the villagers fell to their knees; others fled to the far walls, covering their faces."
    "His father's hand closed on his shoulder hard enough to bruise."
    mfa "Watch. See the proof. The flame burns."
    "But Markus could not move, could not breathe. Her mouth was still moving, as if some last word were caught inside and would never escape."
    "And then silence."
    "Only the drip of blood onto stone. The stink of iron and smoke. The flicker of candles swaying as if in a wind that did not exist."

    scene bg undercroft_circle_blood at memory with dissolve_slow
    show vignette
    show kalinos neutral at midright with dissolve
    "The First raised his arms."
    kal "Her ruin is proof. The vessel was too weak. But His flame remains. It waits."
    "Some nodded. Others lowered their eyes. Doubt hummed low among them, like flies circling carrion."
    "Markus tore his gaze from the circle at last, his chest heaving. His stomach churned with nausea, but deeper than that was something worse: the certainty that this was not the end."

    # Beat 4 — the father's grip and the abandonment: NARRATION ONLY.
    "When the screaming died down, the chamber emptied. The villagers drifted out in broken silence, some weeping, some muttering prayers, others with their eyes fixed on the floor."
    "The heavy doors groaned shut behind them, until at last only three figures remained: the priest, Markus's father, and Markus himself."
    "Blood pooled in the grooves of the circle, the chalk lines already drowned in crimson. The air reeked of copper and rot, thick enough to taste."
    show father neutral at left with dissolve
    "His father's hand pressed against Markus's back, firm, unyielding. He pushed him forward a step, closer to the still form. Markus's stomach lurched, but his legs moved anyway."
    mfa "You belong with him now."
    "His voice was flat, final. With that he turned and left, the sound of his boots fading into the stairwell until only silence remained."
    hide father with dissolve
    "Markus stood frozen, the stone floor icy through his shoes. Her face was turned toward him, lips parted as though she might still speak. But no words came. Only the echo of her cries lingered in his ears."
    mth "How could the human body be torn apart so quickly? How powerful was this deity — and what would happen if it truly returned?"
    "A wave of nausea surged up, dizzying him, but he swallowed it down."
    "The priest moved at last. He regarded Markus for a long, unreadable moment before stepping closer. His voice came low, even, as though what he asked were the most ordinary thing in the world."
    kal "Your first duties are to be executed now."
    "Markus swallowed, his throat dry, but no reply rose to his lips. He stood stiff, fists clenched at his sides."
    "The priest gestured toward the circle."
    kal "Clean it."
    play sound sfx_thud
    "A bucket clattered at Markus's feet, linen folded rough atop it."
    kal "Fresh water waits at the spring behind the church. Bring it. Wash away the blood. Gather what pieces remain. They are to be buried at the tree."
    "Markus's chest tightened, breath shallow."
    kal "The water you use will not be wasted. It returns to Him. You will pour it at the roots, as it was commanded."
    "He swept a hand toward the smeared circle, its lines broken, symbols muddied."
    kal "Repair what is ruined. His marks must remain."
    "For a moment he lingered, his presence filling the chamber like a shadow. Then he turned, robes whispering against the stones, and walked away."
    hide kalinos with dissolve
    "The doors shut behind him."
    "Markus was alone now — with the body, the bucket, the blood."
    "He did not move for a long time."

    # Beat 5 — the cleaning: NARRATION ONLY, condensed to the turn in the boy. No anatomy; the image is the empty, darkened circle.
    play music m_george fadein 4.0
    "The undercroft breathed around him — stone and wet lime, a weeping drip somewhere behind the apse, candle smoke coiling and flattening in the low air."
    "His eyes went to small, ordinary things because the big thing was too large: a scrap of linen wicking red at the edge; the grey crescent of dust left by a shoe where someone had stepped back too fast."
    "Time slid without edges. His legs trembled until they stopped trembling. The cold got into his hands, then his wrists, and sat there like a weight he could not shake off."
    "Hours later, when his body finally remembered itself, it did not do so with any plan. It reached. He picked up the bucket by its iron handle and carried it toward the rear door."

    scene bg spring_rear at memory with dissolve_slow
    show snow light
    show vignette
    "The night air that crept in through the cracks was cold enough to bite his teeth. He crouched and lowered the bucket, watched the water climb it in a shiver, watched the surface slap once against the rim and settle."
    "His hands were shaking now not from fear but from something like readiness, a hollow electricity in his arms."

    scene bg undercroft_circle_blood at memory with dissolve_slow
    show vignette
    "Back in the circle he knelt. He soaked the first cloth. It bled pink into the water immediately, the color curling like smoke through clear."
    "The first wipe was light, almost ceremonial. He pressed again and felt the stiffness beneath — cool, beginning to firm, the body withdrawing from the world millimeter by millimeter as he watched."
    "He did not look at her face. He avoided it not out of mercy but because it made the work harder. Faces claim you. Surfaces are simpler."
    "He found himself inventing an order — inner to outer, then back again, like handwriting on a page only he could read."
    "Then, at the border of what had been done to her, something in him shifted — an audible click in a room without sound."
    "The revulsion that had swamped him on arrival had not vanished; it had been swallowed by a greater sensation, one with more structure. Awe was not the word. Awe was for mountains and storms."
    "This was the cool appetite a boy feels when a mechanism finally yields its interior and the gears align under his eye."
    "The thing that had done this was not human. Whatever burned in her had not simply broken her — it had transformed her into a diagram of its passing."
    "He did not think of who she had been. He thought of how this had been accomplished."
    "He changed water. The task made a rhythm: soak, wring, wipe, fold, press, lift, soak. His hands warmed with repetition. His shoulders stopped shaking. The linen became an extension of his will."
    "He cleaned because the priest had said so, but more and more because the lines he uncovered pleased him."
    "This is how you take a thing the world says is unendurable and make it endurable: you break it down into tasks small enough to be done."
    "His father's voice sometimes drifted back to him in these moments, soft as if reciting scripture."
    mfa "Centuries ago, long before us, a blessed one walked here. A god among men. When He died, the earth did not close over Him — it blossomed."
    mfa "From His grave rose the Tree, the gift of His flesh. Every ten years it bears a fruit, one only, and through that fruit He chooses His vessel."
    "Markus had been very young when he first heard it, curled on his father's knee, lulled by the firelight and the certainty in that voice."
    "The tale had been told again and again until it was marrow-deep in him: the failed vessels, the creatures loosed into the forests, the proof that their village alone was chosen."
    "His father had looked at him then with pride, as though even the boy's small hands might one day help prepare the way."
    "A thought rose, uninvited and absolute."
    mth "If I can learn the pattern of this, I can stand where the priest stands. If I can stand there, I can be near whatever did this."
    "Nearness was all that mattered. The force did not disgust him now; it drew him like heat in winter. It had burned her apart, and in burning had left marks a mind could follow."
    mth "If there are marks, there are rules. If there are rules, they can be learned. And if learned—"
    "He did not finish the sentence even inside his skull. Finishing it would make it real."
    "He fetched a third bucket. He poured a little over the stone where the circle had blurred and watched red weld to grey and run in veins toward the groove that ringed the floor."
    "He thought of the tree behind the church, black and gnarled against the winter, its roots reaching under stone. Bloody water, to water the tree. He could do that. He would do that. The order consoled him."
    "By the time he looked up, the near candles had burned into bowls of their own wax, the wicks choking. His knees had gone numb. What lay before him was not whole — never that — but legible."

    # Beat 6 — burial and the roots: NARRATION ONLY. A composition without the body; the grave is a raw scar.
    scene bg tree_clearing_winter at memory with fade_slow
    show snow light
    show vignette
    play ambient sfx_wind fadein 3.0
    "Hours bled together. By the time Markus had finished scrubbing the stones and feeding the thirsty roots of the tree, his body felt hollowed out — hands raw from the cold water, stomach knotted with hunger."
    "Still, he took up the shovel. The earth was stubborn, the frozen crust clinging to its dead weight, and each stroke jarred through his arms and back until he thought his bones might split."
    "But he did not stop. The grave was his task, his initiation."
    "When it was finally deep enough he crawled out, chest heaving, and lowered the linen bundle into the pit, as though gentleness now might erase what had been done before."
    "He covered it with soil, handful after handful, then heavier shovelfuls, until only the ground remained — a raw scar under the tree's shadow."

    scene bg undercroft_circle at memory with dissolve_slow
    show vignette
    stop ambient fadeout 2.0
    "The undercroft was cold when he returned. The circle waited, broken. His head rang with exhaustion, but he knew it was not finished."
    "And then the priest's steps echoed, robes whispering as he reappeared, eyes sharp as flint."
    show kalinos neutral at midright with dissolve
    kal "Are you done?"
    "Markus straightened, lips pressed thin. He nodded."
    "The priest's gaze swept the chamber."
    kal "No. Not done. The circle is broken."
    "His voice cracked like a whip."
    kal "Do you think He listens through cracks? Precision matters, boy."
    "Markus flinched. Then something inside stiffened. He drew a breath, and his voice emerged not timid but steady."

    scene cg teach_me with dissolve_slow
    window hide
    pause 2.0
    window auto
    mky "Then teach me."
    mky "The sign — I know it. Everyone knows it. It's on our doors, on our robes, stitched into every house. But tell me what it means. How it works."
    "Kalinos's head tilted, surprise flickering. Then a slow, twisted smile spread across his face."
    stop music fadeout 3.0
    scene black with fade_slow
    pause 1.5

    jump ch02
